﻿namespace AnvizDemo
{
    partial class FrmMain
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.listViewDevice = new System.Windows.Forms.ListView();
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader6 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader8 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.newrecord = new System.Windows.Forms.Button();
            this.button_dl_all_record = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.button_restart = new System.Windows.Forms.Button();
            this.settime = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.listBoxLog = new System.Windows.Forms.ListBox();
            this.SAC_Dev02 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.label118 = new System.Windows.Forms.Label();
            this.msg_p_id = new System.Windows.Forms.TextBox();
            this.button5 = new System.Windows.Forms.Button();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.listViewMsg = new System.Windows.Forms.ListView();
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader21 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader7 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.basicconfig2 = new System.Windows.Forms.GroupBox();
            this.config2_52 = new System.Windows.Forms.TextBox();
            this.label67 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.config_l1 = new System.Windows.Forms.Label();
            this.config2_9 = new System.Windows.Forms.TextBox();
            this.config2_10 = new System.Windows.Forms.TextBox();
            this.config2_11 = new System.Windows.Forms.TextBox();
            this.config2_12 = new System.Windows.Forms.TextBox();
            this.config2_13 = new System.Windows.Forms.TextBox();
            this.config2_7 = new System.Windows.Forms.TextBox();
            this.config2_4 = new System.Windows.Forms.TextBox();
            this.config2_8 = new System.Windows.Forms.TextBox();
            this.config2_5 = new System.Windows.Forms.TextBox();
            this.config2_2 = new System.Windows.Forms.TextBox();
            this.config2_6 = new System.Windows.Forms.TextBox();
            this.config2_3 = new System.Windows.Forms.TextBox();
            this.getconfig2 = new System.Windows.Forms.Button();
            this.setconfig2 = new System.Windows.Forms.Button();
            this.config2_1 = new System.Windows.Forms.TextBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.gettime = new System.Windows.Forms.Button();
            this.Box6_sec = new System.Windows.Forms.TextBox();
            this.Box6_min = new System.Windows.Forms.TextBox();
            this.Box6_hour = new System.Windows.Forms.TextBox();
            this.Box6_day = new System.Windows.Forms.TextBox();
            this.Box6_month = new System.Windows.Forms.TextBox();
            this.Box6_year = new System.Windows.Forms.TextBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.textBox4_sleep_time = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.button_set_basic_cfg = new System.Windows.Forms.Button();
            this.button_get_basic_cfg = new System.Windows.Forms.Button();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.label17 = new System.Windows.Forms.Label();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label16 = new System.Windows.Forms.Label();
            this.textBox_pwd = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.button_get_sn = new System.Windows.Forms.Button();
            this.textBox_sn = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.textBoxMask = new System.Windows.Forms.TextBox();
            this.checkBoxDHCP = new System.Windows.Forms.CheckBox();
            this.textBoxPort = new System.Windows.Forms.TextBox();
            this.textBoxGw = new System.Windows.Forms.TextBox();
            this.textBoxIp = new System.Windows.Forms.TextBox();
            this.textBoxRemote = new System.Windows.Forms.TextBox();
            this.buttonGetNet = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.buttonSetNet = new System.Windows.Forms.Button();
            this.textBoxServIp = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.textBoxMode = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.textBoxMac = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.textBox_reserved2 = new System.Windows.Forms.TextBox();
            this.label172 = new System.Windows.Forms.Label();
            this.label122 = new System.Windows.Forms.Label();
            this.get_p_001 = new System.Windows.Forms.TextBox();
            this.button16 = new System.Windows.Forms.Button();
            this.label100 = new System.Windows.Forms.Label();
            this.label99 = new System.Windows.Forms.Label();
            this.drname02 = new System.Windows.Forms.TextBox();
            this.drname01 = new System.Windows.Forms.TextBox();
            this.addfp_person_id = new System.Windows.Forms.TextBox();
            this.label66 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.fptext_01 = new System.Windows.Forms.TextBox();
            this.add_fp = new System.Windows.Forms.Button();
            this.label49 = new System.Windows.Forms.Label();
            this.label181 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.text_time2 = new System.Windows.Forms.TextBox();
            this.text_time1 = new System.Windows.Forms.TextBox();
            this.button_put_fp_raw_data = new System.Windows.Forms.Button();
            this.button_get_fp_raw_data = new System.Windows.Forms.Button();
            this.button8_delete_person = new System.Windows.Forms.Button();
            this.button7_modify_person = new System.Windows.Forms.Button();
            this.textBox_special = new System.Windows.Forms.TextBox();
            this.textBox_fp_status = new System.Windows.Forms.TextBox();
            this.textBox_mode = new System.Windows.Forms.TextBox();
            this.textBox_group = new System.Windows.Forms.TextBox();
            this.textBox_dept = new System.Windows.Forms.TextBox();
            this.textBox_cardID = new System.Windows.Forms.TextBox();
            this.textBox_password = new System.Windows.Forms.TextBox();
            this.textBox_name = new System.Windows.Forms.TextBox();
            this.textBox_personID = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.button7_get_all_person = new System.Windows.Forms.Button();
            this.listView_person = new System.Windows.Forms.ListView();
            this.columnHeader9 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader10 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader11 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader12 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader13 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader14 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader15 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader16 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader17 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader32 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader18 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader19 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader20 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader33 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.button8 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.label65 = new System.Windows.Forms.Label();
            this.label64 = new System.Windows.Forms.Label();
            this.label63 = new System.Windows.Forms.Label();
            this.label62 = new System.Windows.Forms.Label();
            this.label61 = new System.Windows.Forms.Label();
            this.label60 = new System.Windows.Forms.Label();
            this.label59 = new System.Windows.Forms.Label();
            this.label58 = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.label55 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.udp_13 = new System.Windows.Forms.TextBox();
            this.udp_09 = new System.Windows.Forms.TextBox();
            this.udp_08 = new System.Windows.Forms.TextBox();
            this.udp_12 = new System.Windows.Forms.TextBox();
            this.udp_11 = new System.Windows.Forms.TextBox();
            this.udp_07 = new System.Windows.Forms.TextBox();
            this.udp_10 = new System.Windows.Forms.TextBox();
            this.udp_06 = new System.Windows.Forms.TextBox();
            this.udp_05 = new System.Windows.Forms.TextBox();
            this.udp_04 = new System.Windows.Forms.TextBox();
            this.udp_03 = new System.Windows.Forms.TextBox();
            this.udp_02 = new System.Windows.Forms.TextBox();
            this.udp_01 = new System.Windows.Forms.TextBox();
            this.listView1 = new System.Windows.Forms.ListView();
            this.listid = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.type = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.IP = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.MASK = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.GW = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.MAC = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.ServiceIP = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Port = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.NetMode = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Machineid = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Reserved = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Username = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Password = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.DNS = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.URL = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.label30 = new System.Windows.Forms.Label();
            this.but_disconnect = new System.Windows.Forms.Button();
            this.text_disconnect = new System.Windows.Forms.TextBox();
            this.Add_dev_port = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.Add_dev_Ip = new System.Windows.Forms.TextBox();
            this.button6 = new System.Windows.Forms.Button();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.getspecial = new System.Windows.Forms.GroupBox();
            this.label105 = new System.Windows.Forms.Label();
            this.label104 = new System.Windows.Forms.Label();
            this.special_relay = new System.Windows.Forms.TextBox();
            this.label98 = new System.Windows.Forms.Label();
            this.Special_07 = new System.Windows.Forms.TextBox();
            this.label97 = new System.Windows.Forms.Label();
            this.Special_06 = new System.Windows.Forms.TextBox();
            this.label96 = new System.Windows.Forms.Label();
            this.Special_05 = new System.Windows.Forms.TextBox();
            this.label95 = new System.Windows.Forms.Label();
            this.Special_01 = new System.Windows.Forms.TextBox();
            this.button12 = new System.Windows.Forms.Button();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.closeallalarm = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.label70 = new System.Windows.Forms.Label();
            this.label71 = new System.Windows.Forms.Label();
            this.devstatus_02 = new System.Windows.Forms.TextBox();
            this.devstatus_01 = new System.Windows.Forms.TextBox();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.card_01 = new System.Windows.Forms.TextBox();
            this.btn_getcard = new System.Windows.Forms.Button();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.open_u = new System.Windows.Forms.Button();
            this.close_u = new System.Windows.Forms.Button();
            this.btn_setconfig5 = new System.Windows.Forms.Button();
            this.btn_getconfig5 = new System.Windows.Forms.Button();
            this.label69 = new System.Windows.Forms.Label();
            this.label68 = new System.Windows.Forms.Label();
            this.config5_02 = new System.Windows.Forms.TextBox();
            this.config5_01 = new System.Windows.Forms.TextBox();
            this.forcedunlock = new System.Windows.Forms.Button();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.setteam = new System.Windows.Forms.Button();
            this.getteam = new System.Windows.Forms.Button();
            this.teamid = new System.Windows.Forms.TextBox();
            this.label52 = new System.Windows.Forms.Label();
            this.select_04 = new System.Windows.Forms.TextBox();
            this.select_01 = new System.Windows.Forms.TextBox();
            this.select_02 = new System.Windows.Forms.TextBox();
            this.select_03 = new System.Windows.Forms.TextBox();
            this.label51 = new System.Windows.Forms.Label();
            this.timepriodgroup = new System.Windows.Forms.GroupBox();
            this.label48 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.set_period_time = new System.Windows.Forms.Button();
            this.get_period_time = new System.Windows.Forms.Button();
            this.time_p74 = new System.Windows.Forms.TextBox();
            this.time_p73 = new System.Windows.Forms.TextBox();
            this.time_p72 = new System.Windows.Forms.TextBox();
            this.time_p71 = new System.Windows.Forms.TextBox();
            this.time_p64 = new System.Windows.Forms.TextBox();
            this.time_p63 = new System.Windows.Forms.TextBox();
            this.time_p62 = new System.Windows.Forms.TextBox();
            this.time_p61 = new System.Windows.Forms.TextBox();
            this.time_p54 = new System.Windows.Forms.TextBox();
            this.time_p53 = new System.Windows.Forms.TextBox();
            this.time_p52 = new System.Windows.Forms.TextBox();
            this.time_p51 = new System.Windows.Forms.TextBox();
            this.time_p44 = new System.Windows.Forms.TextBox();
            this.time_p43 = new System.Windows.Forms.TextBox();
            this.time_p42 = new System.Windows.Forms.TextBox();
            this.time_p41 = new System.Windows.Forms.TextBox();
            this.time_p34 = new System.Windows.Forms.TextBox();
            this.time_p33 = new System.Windows.Forms.TextBox();
            this.time_p32 = new System.Windows.Forms.TextBox();
            this.time_p31 = new System.Windows.Forms.TextBox();
            this.time_p24 = new System.Windows.Forms.TextBox();
            this.time_p23 = new System.Windows.Forms.TextBox();
            this.time_p22 = new System.Windows.Forms.TextBox();
            this.time_p21 = new System.Windows.Forms.TextBox();
            this.time_p14 = new System.Windows.Forms.TextBox();
            this.time_p13 = new System.Windows.Forms.TextBox();
            this.time_p12 = new System.Windows.Forms.TextBox();
            this.time_p11 = new System.Windows.Forms.TextBox();
            this.time_number = new System.Windows.Forms.TextBox();
            this.init_system = new System.Windows.Forms.Button();
            this.init_user_area = new System.Windows.Forms.Button();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.groupBox16 = new System.Windows.Forms.GroupBox();
            this.label93 = new System.Windows.Forms.Label();
            this.label92 = new System.Windows.Forms.Label();
            this.label91 = new System.Windows.Forms.Label();
            this.button11 = new System.Windows.Forms.Button();
            this.sdk_03 = new System.Windows.Forms.TextBox();
            this.sdk_01 = new System.Windows.Forms.TextBox();
            this.sdk_02 = new System.Windows.Forms.TextBox();
            this.groupBox14 = new System.Windows.Forms.GroupBox();
            this.baifenbi = new System.Windows.Forms.TextBox();
            this.update_status = new System.Windows.Forms.Button();
            this.update_file = new System.Windows.Forms.Button();
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.tgj_040 = new System.Windows.Forms.TextBox();
            this.tgj_039 = new System.Windows.Forms.TextBox();
            this.tgj_038 = new System.Windows.Forms.TextBox();
            this.tgj_037 = new System.Windows.Forms.TextBox();
            this.tgj_036 = new System.Windows.Forms.TextBox();
            this.tgj_035 = new System.Windows.Forms.TextBox();
            this.tgj_030 = new System.Windows.Forms.TextBox();
            this.tgj_025 = new System.Windows.Forms.TextBox();
            this.tgj_020 = new System.Windows.Forms.TextBox();
            this.tgj_015 = new System.Windows.Forms.TextBox();
            this.tgj_010 = new System.Windows.Forms.TextBox();
            this.tgj_005 = new System.Windows.Forms.TextBox();
            this.label77 = new System.Windows.Forms.Label();
            this.label78 = new System.Windows.Forms.Label();
            this.label79 = new System.Windows.Forms.Label();
            this.label80 = new System.Windows.Forms.Label();
            this.label81 = new System.Windows.Forms.Label();
            this.setstatus02 = new System.Windows.Forms.Button();
            this.getstatus02 = new System.Windows.Forms.Button();
            this.tgj_034 = new System.Windows.Forms.TextBox();
            this.tgj_033 = new System.Windows.Forms.TextBox();
            this.tgj_032 = new System.Windows.Forms.TextBox();
            this.tgj_031 = new System.Windows.Forms.TextBox();
            this.tgj_029 = new System.Windows.Forms.TextBox();
            this.tgj_028 = new System.Windows.Forms.TextBox();
            this.tgj_027 = new System.Windows.Forms.TextBox();
            this.tgj_026 = new System.Windows.Forms.TextBox();
            this.tgj_024 = new System.Windows.Forms.TextBox();
            this.tgj_023 = new System.Windows.Forms.TextBox();
            this.tgj_022 = new System.Windows.Forms.TextBox();
            this.tgj_021 = new System.Windows.Forms.TextBox();
            this.tgj_019 = new System.Windows.Forms.TextBox();
            this.tgj_018 = new System.Windows.Forms.TextBox();
            this.tgj_017 = new System.Windows.Forms.TextBox();
            this.tgj_016 = new System.Windows.Forms.TextBox();
            this.tgj_014 = new System.Windows.Forms.TextBox();
            this.tgj_013 = new System.Windows.Forms.TextBox();
            this.tgj_012 = new System.Windows.Forms.TextBox();
            this.tgj_011 = new System.Windows.Forms.TextBox();
            this.tgj_009 = new System.Windows.Forms.TextBox();
            this.tgj_008 = new System.Windows.Forms.TextBox();
            this.tgj_007 = new System.Windows.Forms.TextBox();
            this.tgj_006 = new System.Windows.Forms.TextBox();
            this.tgj_004 = new System.Windows.Forms.TextBox();
            this.tgj_003 = new System.Windows.Forms.TextBox();
            this.tgj_002 = new System.Windows.Forms.TextBox();
            this.tgj_001 = new System.Windows.Forms.TextBox();
            this.flagweek_01 = new System.Windows.Forms.TextBox();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.label82 = new System.Windows.Forms.Label();
            this.status00 = new System.Windows.Forms.TextBox();
            this.label72 = new System.Windows.Forms.Label();
            this.label73 = new System.Windows.Forms.Label();
            this.label74 = new System.Windows.Forms.Label();
            this.label75 = new System.Windows.Forms.Label();
            this.label76 = new System.Windows.Forms.Label();
            this.setstatus01 = new System.Windows.Forms.Button();
            this.getstatus01 = new System.Windows.Forms.Button();
            this.tg_028 = new System.Windows.Forms.TextBox();
            this.tg_027 = new System.Windows.Forms.TextBox();
            this.tg_026 = new System.Windows.Forms.TextBox();
            this.tg_025 = new System.Windows.Forms.TextBox();
            this.tg_024 = new System.Windows.Forms.TextBox();
            this.tg_023 = new System.Windows.Forms.TextBox();
            this.tg_022 = new System.Windows.Forms.TextBox();
            this.tg_021 = new System.Windows.Forms.TextBox();
            this.tg_020 = new System.Windows.Forms.TextBox();
            this.tg_019 = new System.Windows.Forms.TextBox();
            this.tg_018 = new System.Windows.Forms.TextBox();
            this.tg_017 = new System.Windows.Forms.TextBox();
            this.tg_016 = new System.Windows.Forms.TextBox();
            this.tg_015 = new System.Windows.Forms.TextBox();
            this.tg_014 = new System.Windows.Forms.TextBox();
            this.tg_013 = new System.Windows.Forms.TextBox();
            this.tg_012 = new System.Windows.Forms.TextBox();
            this.tg_011 = new System.Windows.Forms.TextBox();
            this.tg_010 = new System.Windows.Forms.TextBox();
            this.tg_009 = new System.Windows.Forms.TextBox();
            this.tg_008 = new System.Windows.Forms.TextBox();
            this.tg_007 = new System.Windows.Forms.TextBox();
            this.tg_006 = new System.Windows.Forms.TextBox();
            this.tg_005 = new System.Windows.Forms.TextBox();
            this.tg_004 = new System.Windows.Forms.TextBox();
            this.tg_003 = new System.Windows.Forms.TextBox();
            this.tg_002 = new System.Windows.Forms.TextBox();
            this.tg_001 = new System.Windows.Forms.TextBox();
            this.groupid01 = new System.Windows.Forms.TextBox();
            this.config3 = new System.Windows.Forms.GroupBox();
            this.SetConfig3_01 = new System.Windows.Forms.Button();
            this.GetConfig3_01 = new System.Windows.Forms.Button();
            this.c3_08 = new System.Windows.Forms.TextBox();
            this.c3_06 = new System.Windows.Forms.TextBox();
            this.c3_04 = new System.Windows.Forms.TextBox();
            this.c3_02 = new System.Windows.Forms.TextBox();
            this.c3_07 = new System.Windows.Forms.TextBox();
            this.c3_05 = new System.Windows.Forms.TextBox();
            this.c3_03 = new System.Windows.Forms.TextBox();
            this.c3_01 = new System.Windows.Forms.TextBox();
            this.label87 = new System.Windows.Forms.Label();
            this.label88 = new System.Windows.Forms.Label();
            this.label89 = new System.Windows.Forms.Label();
            this.label90 = new System.Windows.Forms.Label();
            this.label86 = new System.Windows.Forms.Label();
            this.label85 = new System.Windows.Forms.Label();
            this.label84 = new System.Windows.Forms.Label();
            this.label83 = new System.Windows.Forms.Label();
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.groupBox26 = new System.Windows.Forms.GroupBox();
            this.button_verifGet = new System.Windows.Forms.Button();
            this.button_verifSet = new System.Windows.Forms.Button();
            this.listBox_verifs = new System.Windows.Forms.ListBox();
            this.label180 = new System.Windows.Forms.Label();
            this.label179 = new System.Windows.Forms.Label();
            this.textBox_verfVer = new System.Windows.Forms.TextBox();
            this.textBox_verifmode = new System.Windows.Forms.TextBox();
            this.groupBox22 = new System.Windows.Forms.GroupBox();
            this.set_a = new System.Windows.Forms.Button();
            this.label109 = new System.Windows.Forms.Label();
            this.choose02 = new System.Windows.Forms.CheckBox();
            this.a_name_02 = new System.Windows.Forms.TextBox();
            this.a_password_02 = new System.Windows.Forms.TextBox();
            this.label111 = new System.Windows.Forms.Label();
            this.groupBox20 = new System.Windows.Forms.GroupBox();
            this.devidx_z = new System.Windows.Forms.TextBox();
            this.label106 = new System.Windows.Forms.Label();
            this.button13 = new System.Windows.Forms.Button();
            this.machine_z = new System.Windows.Forms.TextBox();
            this.label107 = new System.Windows.Forms.Label();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.label94 = new System.Windows.Forms.Label();
            this.url_dns = new System.Windows.Forms.TextBox();
            this.seturl = new System.Windows.Forms.Button();
            this.geturl = new System.Windows.Forms.Button();
            this.url_01 = new System.Windows.Forms.TextBox();
            this.groupBox19 = new System.Windows.Forms.GroupBox();
            this.clearadmin = new System.Windows.Forms.Button();
            this.groupBox18 = new System.Windows.Forms.GroupBox();
            this.c_password = new System.Windows.Forms.TextBox();
            this.label103 = new System.Windows.Forms.Label();
            this.authentication = new System.Windows.Forms.Button();
            this.c_username = new System.Windows.Forms.TextBox();
            this.label102 = new System.Windows.Forms.Label();
            this.groupBox17 = new System.Windows.Forms.GroupBox();
            this.setmachi01 = new System.Windows.Forms.Button();
            this.getmachineid = new System.Windows.Forms.Button();
            this.machineid_01 = new System.Windows.Forms.TextBox();
            this.label101 = new System.Windows.Forms.Label();
            this.tabPage8 = new System.Windows.Forms.TabPage();
            this.button19 = new System.Windows.Forms.Button();
            this.button18 = new System.Windows.Forms.Button();
            this.button17 = new System.Windows.Forms.Button();
            this.button_del_flag_count = new System.Windows.Forms.Button();
            this.textBox_del_flag_count = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.button_del_all_record = new System.Windows.Forms.Button();
            this.groupBox24 = new System.Windows.Forms.GroupBox();
            this.label117 = new System.Windows.Forms.Label();
            this.p_record_004 = new System.Windows.Forms.TextBox();
            this.button15 = new System.Windows.Forms.Button();
            this.label119 = new System.Windows.Forms.Label();
            this.label120 = new System.Windows.Forms.Label();
            this.label121 = new System.Windows.Forms.Label();
            this.button14 = new System.Windows.Forms.Button();
            this.p_record_003 = new System.Windows.Forms.TextBox();
            this.p_record_002 = new System.Windows.Forms.TextBox();
            this.p_record_001 = new System.Windows.Forms.TextBox();
            this.groupBox23 = new System.Windows.Forms.GroupBox();
            this.label116 = new System.Windows.Forms.Label();
            this.label115 = new System.Windows.Forms.Label();
            this.label114 = new System.Windows.Forms.Label();
            this.label113 = new System.Windows.Forms.Label();
            this.label112 = new System.Windows.Forms.Label();
            this.upload_record = new System.Windows.Forms.Button();
            this.upload_005 = new System.Windows.Forms.TextBox();
            this.upload_004 = new System.Windows.Forms.TextBox();
            this.upload_003 = new System.Windows.Forms.TextBox();
            this.upload_002 = new System.Windows.Forms.TextBox();
            this.upload_001 = new System.Windows.Forms.TextBox();
            this.tabPage9 = new System.Windows.Forms.TabPage();
            this.sac_getevent = new System.Windows.Forms.Button();
            this.sac_delete01 = new System.Windows.Forms.TextBox();
            this.sac_delete02 = new System.Windows.Forms.TextBox();
            this.label173 = new System.Windows.Forms.Label();
            this.sac_init_people = new System.Windows.Forms.Button();
            this.sac_delete_people = new System.Windows.Forms.Button();
            this.label138 = new System.Windows.Forms.Label();
            this.label139 = new System.Windows.Forms.Label();
            this.p_g_02 = new System.Windows.Forms.TextBox();
            this.p_g_01 = new System.Windows.Forms.TextBox();
            this.p_g_btn2 = new System.Windows.Forms.Button();
            this.p_g_btn1 = new System.Windows.Forms.Button();
            this.label137 = new System.Windows.Forms.Label();
            this.label136 = new System.Windows.Forms.Label();
            this.sac_up_02 = new System.Windows.Forms.TextBox();
            this.sac_up_01 = new System.Windows.Forms.TextBox();
            this.sac_upload_group = new System.Windows.Forms.Button();
            this.sac_get_group = new System.Windows.Forms.Button();
            this.button20 = new System.Windows.Forms.Button();
            this.sac_e_09 = new System.Windows.Forms.TextBox();
            this.label135 = new System.Windows.Forms.Label();
            this.sac_e_10 = new System.Windows.Forms.TextBox();
            this.sac_e_08 = new System.Windows.Forms.TextBox();
            this.sac_e_07 = new System.Windows.Forms.TextBox();
            this.sac_e_06 = new System.Windows.Forms.TextBox();
            this.sac_e_05 = new System.Windows.Forms.TextBox();
            this.sac_e_04 = new System.Windows.Forms.TextBox();
            this.sac_e_03 = new System.Windows.Forms.TextBox();
            this.sac_e_02 = new System.Windows.Forms.TextBox();
            this.sac_e_01 = new System.Windows.Forms.TextBox();
            this.label126 = new System.Windows.Forms.Label();
            this.label127 = new System.Windows.Forms.Label();
            this.label128 = new System.Windows.Forms.Label();
            this.label129 = new System.Windows.Forms.Label();
            this.label130 = new System.Windows.Forms.Label();
            this.label131 = new System.Windows.Forms.Label();
            this.label132 = new System.Windows.Forms.Label();
            this.label133 = new System.Windows.Forms.Label();
            this.label134 = new System.Windows.Forms.Label();
            this.sac_get_employee = new System.Windows.Forms.Button();
            this.listsac_employee = new System.Windows.Forms.ListView();
            this.columnHeader22 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader23 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader24 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader25 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader26 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader27 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader28 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader29 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader30 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader31 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader34 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Bolid_Log = new System.Windows.Forms.TabPage();
            this.groupBox25 = new System.Windows.Forms.GroupBox();
            this.label163 = new System.Windows.Forms.Label();
            this.log_auto_01 = new System.Windows.Forms.TextBox();
            this.log_auto_btn1 = new System.Windows.Forms.Button();
            this.log_auto_btn3 = new System.Windows.Forms.Button();
            this.log_auto_btn2 = new System.Windows.Forms.Button();
            this.log_manage_03 = new System.Windows.Forms.Button();
            this.log_manage_02 = new System.Windows.Forms.Button();
            this.log_manage_01 = new System.Windows.Forms.Button();
            this.label123 = new System.Windows.Forms.Label();
            this.log_number = new System.Windows.Forms.TextBox();
            this.label124 = new System.Windows.Forms.Label();
            this.label125 = new System.Windows.Forms.Label();
            this.log_endtime = new System.Windows.Forms.TextBox();
            this.log_begintime = new System.Windows.Forms.TextBox();
            this.tabPage10 = new System.Windows.Forms.TabPage();
            this.gettimeframe = new System.Windows.Forms.Button();
            this.sac_set = new System.Windows.Forms.Button();
            this.sac_get = new System.Windows.Forms.Button();
            this.sac_sac05 = new System.Windows.Forms.TextBox();
            this.label162 = new System.Windows.Forms.Label();
            this.sac_sac04 = new System.Windows.Forms.TextBox();
            this.label161 = new System.Windows.Forms.Label();
            this.sac_sac03 = new System.Windows.Forms.TextBox();
            this.label160 = new System.Windows.Forms.Label();
            this.sac_sac02 = new System.Windows.Forms.TextBox();
            this.label159 = new System.Windows.Forms.Label();
            this.sac_sac01 = new System.Windows.Forms.TextBox();
            this.label158 = new System.Windows.Forms.Label();
            this.label156 = new System.Windows.Forms.Label();
            this.label157 = new System.Windows.Forms.Label();
            this.time_g_02 = new System.Windows.Forms.TextBox();
            this.time_g_01 = new System.Windows.Forms.TextBox();
            this.uptimegroup = new System.Windows.Forms.Button();
            this.downtimegroup = new System.Windows.Forms.Button();
            this.updoorgroup = new System.Windows.Forms.Button();
            this.downdoorgroup = new System.Windows.Forms.Button();
            this.label154 = new System.Windows.Forms.Label();
            this.label155 = new System.Windows.Forms.Label();
            this.door_g_02 = new System.Windows.Forms.TextBox();
            this.door_g_01 = new System.Windows.Forms.TextBox();
            this.button26 = new System.Windows.Forms.Button();
            this.button25 = new System.Windows.Forms.Button();
            this.updoor_group = new System.Windows.Forms.Button();
            this.button23 = new System.Windows.Forms.Button();
            this.door_group = new System.Windows.Forms.Button();
            this.time03 = new System.Windows.Forms.TextBox();
            this.label153 = new System.Windows.Forms.Label();
            this.time02 = new System.Windows.Forms.TextBox();
            this.label152 = new System.Windows.Forms.Label();
            this.time01 = new System.Windows.Forms.TextBox();
            this.label151 = new System.Windows.Forms.Label();
            this.door03 = new System.Windows.Forms.TextBox();
            this.label150 = new System.Windows.Forms.Label();
            this.door02 = new System.Windows.Forms.TextBox();
            this.label149 = new System.Windows.Forms.Label();
            this.door01 = new System.Windows.Forms.TextBox();
            this.label148 = new System.Windows.Forms.Label();
            this.sac_time00 = new System.Windows.Forms.TextBox();
            this.settimeframe = new System.Windows.Forms.Button();
            this.label147 = new System.Windows.Forms.Label();
            this.sac_time01 = new System.Windows.Forms.TextBox();
            this.sac_door = new System.Windows.Forms.Button();
            this.sac_1006 = new System.Windows.Forms.TextBox();
            this.label146 = new System.Windows.Forms.Label();
            this.sac_1007 = new System.Windows.Forms.TextBox();
            this.label145 = new System.Windows.Forms.Label();
            this.sac_1005 = new System.Windows.Forms.TextBox();
            this.label144 = new System.Windows.Forms.Label();
            this.sac_1004 = new System.Windows.Forms.TextBox();
            this.label143 = new System.Windows.Forms.Label();
            this.sac_1003 = new System.Windows.Forms.TextBox();
            this.label142 = new System.Windows.Forms.Label();
            this.sac_1002 = new System.Windows.Forms.TextBox();
            this.label141 = new System.Windows.Forms.Label();
            this.sac_1001 = new System.Windows.Forms.TextBox();
            this.label140 = new System.Windows.Forms.Label();
            this.tabPage11 = new System.Windows.Forms.TabPage();
            this.label167 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label166 = new System.Windows.Forms.Label();
            this.label165 = new System.Windows.Forms.Label();
            this.pic_delpic = new System.Windows.Forms.Button();
            this.pic_getpic = new System.Windows.Forms.Button();
            this.pic_time = new System.Windows.Forms.TextBox();
            this.pic_eid = new System.Windows.Forms.TextBox();
            this.pic_gethead = new System.Windows.Forms.Button();
            this.label164 = new System.Windows.Forms.Label();
            this.pic_num = new System.Windows.Forms.TextBox();
            this.pic_getnum = new System.Windows.Forms.Button();
            this.Test_page12 = new System.Windows.Forms.TabPage();
            this.label171 = new System.Windows.Forms.Label();
            this.label170 = new System.Windows.Forms.Label();
            this.label169 = new System.Windows.Forms.Label();
            this.label168 = new System.Windows.Forms.Label();
            this.bell3 = new System.Windows.Forms.TextBox();
            this.bell2 = new System.Windows.Forms.TextBox();
            this.bell1 = new System.Windows.Forms.TextBox();
            this.bell0 = new System.Windows.Forms.TextBox();
            this.button21 = new System.Windows.Forms.Button();
            this.Test_Bell = new System.Windows.Forms.Button();
            this.FACE7TM = new System.Windows.Forms.TabPage();
            this.label176 = new System.Windows.Forms.Label();
            this.label177 = new System.Windows.Forms.Label();
            this.label178 = new System.Windows.Forms.Label();
            this.tm_stop_time = new System.Windows.Forms.TextBox();
            this.tm_start_time = new System.Windows.Forms.TextBox();
            this.tm_employee_id = new System.Windows.Forms.TextBox();
            this.label175 = new System.Windows.Forms.Label();
            this.upload_face_PId = new System.Windows.Forms.TextBox();
            this.e_add_fp_pic = new System.Windows.Forms.TextBox();
            this.label174 = new System.Windows.Forms.Label();
            this.button29 = new System.Windows.Forms.Button();
            this.pic_face_fp_btn_ul = new System.Windows.Forms.Button();
            this.pic_face_btn_ul = new System.Windows.Forms.Button();
            this.pic_face_btn_dl = new System.Windows.Forms.Button();
            this.employee_face_lab = new System.Windows.Forms.Label();
            this.employee_face_PId = new System.Windows.Forms.TextBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.button32 = new System.Windows.Forms.Button();
            this.button31 = new System.Windows.Forms.Button();
            this.button30 = new System.Windows.Forms.Button();
            this.t_p_n01 = new System.Windows.Forms.Button();
            this.t_p_04 = new System.Windows.Forms.TextBox();
            this.t_p_03 = new System.Windows.Forms.TextBox();
            this.t_p_02 = new System.Windows.Forms.TextBox();
            this.t_p_01 = new System.Windows.Forms.TextBox();
            this.button28 = new System.Windows.Forms.Button();
            this.button27 = new System.Windows.Forms.Button();
            this.button24 = new System.Windows.Forms.Button();
            this.button22 = new System.Windows.Forms.Button();
            this.groupBox15 = new System.Windows.Forms.GroupBox();
            this.groupBox21 = new System.Windows.Forms.GroupBox();
            this.label108 = new System.Windows.Forms.Label();
            this.choose = new System.Windows.Forms.CheckBox();
            this.a_name = new System.Windows.Forms.TextBox();
            this.a_password = new System.Windows.Forms.TextBox();
            this.label110 = new System.Windows.Forms.Label();
            this.label_closesevice = new System.Windows.Forms.Label();
            this.label_serviceport = new System.Windows.Forms.Label();
            this.button10 = new System.Windows.Forms.Button();
            this.iscloseservice = new System.Windows.Forms.TextBox();
            this.service_port = new System.Windows.Forms.TextBox();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SAC_Dev02.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.basicconfig2.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.getspecial.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.timepriodgroup.SuspendLayout();
            this.tabPage6.SuspendLayout();
            this.groupBox16.SuspendLayout();
            this.groupBox14.SuspendLayout();
            this.groupBox13.SuspendLayout();
            this.groupBox12.SuspendLayout();
            this.config3.SuspendLayout();
            this.tabPage7.SuspendLayout();
            this.groupBox26.SuspendLayout();
            this.groupBox22.SuspendLayout();
            this.groupBox20.SuspendLayout();
            this.groupBox11.SuspendLayout();
            this.groupBox19.SuspendLayout();
            this.groupBox18.SuspendLayout();
            this.groupBox17.SuspendLayout();
            this.tabPage8.SuspendLayout();
            this.groupBox24.SuspendLayout();
            this.groupBox23.SuspendLayout();
            this.tabPage9.SuspendLayout();
            this.Bolid_Log.SuspendLayout();
            this.groupBox25.SuspendLayout();
            this.tabPage10.SuspendLayout();
            this.tabPage11.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.Test_page12.SuspendLayout();
            this.FACE7TM.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.groupBox15.SuspendLayout();
            this.groupBox21.SuspendLayout();
            this.SuspendLayout();
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // listViewDevice
            // 
            this.listViewDevice.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.listViewDevice.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader2,
            this.columnHeader6,
            this.columnHeader1,
            this.columnHeader8});
            this.listViewDevice.FullRowSelect = true;
            this.listViewDevice.GridLines = true;
            this.listViewDevice.HideSelection = false;
            this.listViewDevice.Location = new System.Drawing.Point(9, 28);
            this.listViewDevice.Margin = new System.Windows.Forms.Padding(4);
            this.listViewDevice.Name = "listViewDevice";
            this.listViewDevice.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.listViewDevice.Size = new System.Drawing.Size(521, 456);
            this.listViewDevice.TabIndex = 9;
            this.listViewDevice.UseCompatibleStateImageBehavior = false;
            this.listViewDevice.View = System.Windows.Forms.View.Details;
            this.listViewDevice.SelectedIndexChanged += new System.EventHandler(this.listViewDevice_SelectedIndexChanged);
            this.listViewDevice.MouseDown += new System.Windows.Forms.MouseEventHandler(this.listViewDevice_MouseDown);
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "MachineId";
            this.columnHeader2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader2.Width = 70;
            // 
            // columnHeader6
            // 
            this.columnHeader6.Text = "DevIdx";
            this.columnHeader6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader6.Width = 50;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Addr";
            this.columnHeader1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader1.Width = 160;
            // 
            // columnHeader8
            // 
            this.columnHeader8.Text = "Version";
            this.columnHeader8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader8.Width = 70;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.newrecord);
            this.groupBox2.Controls.Add(this.button_dl_all_record);
            this.groupBox2.Controls.Add(this.button1);
            this.groupBox2.Controls.Add(this.listViewDevice);
            this.groupBox2.Controls.Add(this.button_restart);
            this.groupBox2.Location = new System.Drawing.Point(930, 18);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox2.Size = new System.Drawing.Size(540, 554);
            this.groupBox2.TabIndex = 11;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = " Device List";
            // 
            // newrecord
            // 
            this.newrecord.Location = new System.Drawing.Point(363, 492);
            this.newrecord.Margin = new System.Windows.Forms.Padding(4);
            this.newrecord.Name = "newrecord";
            this.newrecord.Size = new System.Drawing.Size(168, 46);
            this.newrecord.TabIndex = 47;
            this.newrecord.Text = "DL New Record";
            this.newrecord.UseVisualStyleBackColor = true;
            this.newrecord.Click += new System.EventHandler(this.newrecord_Click);
            // 
            // button_dl_all_record
            // 
            this.button_dl_all_record.Location = new System.Drawing.Point(192, 492);
            this.button_dl_all_record.Margin = new System.Windows.Forms.Padding(4);
            this.button_dl_all_record.Name = "button_dl_all_record";
            this.button_dl_all_record.Size = new System.Drawing.Size(162, 46);
            this.button_dl_all_record.TabIndex = 45;
            this.button_dl_all_record.Text = "DL All Record";
            this.button_dl_all_record.UseVisualStyleBackColor = true;
            this.button_dl_all_record.Click += new System.EventHandler(this.button_dl_all_record_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(9, 492);
            this.button1.Margin = new System.Windows.Forms.Padding(4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(177, 45);
            this.button1.TabIndex = 43;
            this.button1.Text = "RebootDevice";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.reboot_Click);
            // 
            // button_restart
            // 
            this.button_restart.Enabled = false;
            this.button_restart.Location = new System.Drawing.Point(436, 494);
            this.button_restart.Margin = new System.Windows.Forms.Padding(4);
            this.button_restart.Name = "button_restart";
            this.button_restart.Size = new System.Drawing.Size(94, 45);
            this.button_restart.TabIndex = 46;
            this.button_restart.Text = "Restart";
            this.button_restart.UseVisualStyleBackColor = true;
            this.button_restart.Click += new System.EventHandler(this.button_restart_Click);
            // 
            // settime
            // 
            this.settime.Location = new System.Drawing.Point(9, 117);
            this.settime.Margin = new System.Windows.Forms.Padding(4);
            this.settime.Name = "settime";
            this.settime.Size = new System.Drawing.Size(140, 45);
            this.settime.TabIndex = 44;
            this.settime.Text = "Set Time";
            this.settime.UseVisualStyleBackColor = true;
            this.settime.Click += new System.EventHandler(this.settime_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.listBoxLog);
            this.groupBox1.Location = new System.Drawing.Point(18, 18);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox1.Size = new System.Drawing.Size(903, 554);
            this.groupBox1.TabIndex = 12;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Log List";
            // 
            // listBoxLog
            // 
            this.listBoxLog.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.listBoxLog.FormattingEnabled = true;
            this.listBoxLog.HorizontalScrollbar = true;
            this.listBoxLog.ItemHeight = 12;
            this.listBoxLog.Location = new System.Drawing.Point(9, 28);
            this.listBoxLog.Margin = new System.Windows.Forms.Padding(4);
            this.listBoxLog.Name = "listBoxLog";
            this.listBoxLog.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
            this.listBoxLog.Size = new System.Drawing.Size(883, 508);
            this.listBoxLog.TabIndex = 9;
            this.listBoxLog.DrawItem += new System.Windows.Forms.DrawItemEventHandler(this.listBoxLog_DrawItem);
            this.listBoxLog.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.listBoxLog_KeyPress);
            // 
            // SAC_Dev02
            // 
            this.SAC_Dev02.Controls.Add(this.tabPage1);
            this.SAC_Dev02.Controls.Add(this.tabPage2);
            this.SAC_Dev02.Controls.Add(this.tabPage4);
            this.SAC_Dev02.Controls.Add(this.tabPage5);
            this.SAC_Dev02.Controls.Add(this.tabPage3);
            this.SAC_Dev02.Controls.Add(this.tabPage6);
            this.SAC_Dev02.Controls.Add(this.tabPage7);
            this.SAC_Dev02.Controls.Add(this.tabPage8);
            this.SAC_Dev02.Controls.Add(this.tabPage9);
            this.SAC_Dev02.Controls.Add(this.Bolid_Log);
            this.SAC_Dev02.Controls.Add(this.tabPage10);
            this.SAC_Dev02.Controls.Add(this.tabPage11);
            this.SAC_Dev02.Controls.Add(this.Test_page12);
            this.SAC_Dev02.Controls.Add(this.FACE7TM);
            this.SAC_Dev02.Location = new System.Drawing.Point(18, 580);
            this.SAC_Dev02.Margin = new System.Windows.Forms.Padding(4);
            this.SAC_Dev02.Name = "SAC_Dev02";
            this.SAC_Dev02.SelectedIndex = 0;
            this.SAC_Dev02.Size = new System.Drawing.Size(1452, 533);
            this.SAC_Dev02.TabIndex = 29;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.label118);
            this.tabPage1.Controls.Add(this.msg_p_id);
            this.tabPage1.Controls.Add(this.button5);
            this.tabPage1.Controls.Add(this.textBox3);
            this.tabPage1.Controls.Add(this.dateTimePicker2);
            this.tabPage1.Controls.Add(this.dateTimePicker1);
            this.tabPage1.Controls.Add(this.label4);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Controls.Add(this.textBox1);
            this.tabPage1.Controls.Add(this.button4);
            this.tabPage1.Controls.Add(this.button3);
            this.tabPage1.Controls.Add(this.button2);
            this.tabPage1.Controls.Add(this.listViewMsg);
            this.tabPage1.Location = new System.Drawing.Point(4, 28);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage1.Size = new System.Drawing.Size(1444, 501);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Message";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // label118
            // 
            this.label118.AutoSize = true;
            this.label118.Location = new System.Drawing.Point(1082, 212);
            this.label118.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label118.Name = "label118";
            this.label118.Size = new System.Drawing.Size(98, 18);
            this.label118.TabIndex = 43;
            this.label118.Text = "Person Id:";
            // 
            // msg_p_id
            // 
            this.msg_p_id.Location = new System.Drawing.Point(1198, 207);
            this.msg_p_id.Margin = new System.Windows.Forms.Padding(4);
            this.msg_p_id.Name = "msg_p_id";
            this.msg_p_id.Size = new System.Drawing.Size(236, 28);
            this.msg_p_id.TabIndex = 42;
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(1362, 352);
            this.button5.Margin = new System.Windows.Forms.Padding(4);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(69, 78);
            this.button5.TabIndex = 41;
            this.button5.Text = "Add Msg";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.addmsg_Click);
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(1083, 352);
            this.textBox3.Margin = new System.Windows.Forms.Padding(4);
            this.textBox3.MaxLength = 200;
            this.textBox3.Multiline = true;
            this.textBox3.Name = "textBox3";
            this.textBox3.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox3.Size = new System.Drawing.Size(258, 78);
            this.textBox3.TabIndex = 40;
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.CustomFormat = "yyyy-MM-dd HH:mm:ss";
            this.dateTimePicker2.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker2.Location = new System.Drawing.Point(1198, 308);
            this.dateTimePicker2.Margin = new System.Windows.Forms.Padding(4);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(236, 28);
            this.dateTimePicker2.TabIndex = 37;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.CustomFormat = "yyyy-MM-dd HH:mm:ss";
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker1.Location = new System.Drawing.Point(1198, 255);
            this.dateTimePicker1.Margin = new System.Windows.Forms.Padding(4);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(236, 28);
            this.dateTimePicker1.TabIndex = 36;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(1082, 316);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(89, 18);
            this.label4.TabIndex = 39;
            this.label4.Text = "End Time:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(1082, 264);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(107, 18);
            this.label3.TabIndex = 38;
            this.label3.Text = "Start Time:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(1082, 106);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(80, 18);
            this.label1.TabIndex = 35;
            this.label1.Text = "Msg Idx:";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(1170, 102);
            this.textBox1.Margin = new System.Windows.Forms.Padding(4);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(242, 28);
            this.textBox1.TabIndex = 34;
            this.textBox1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox1_KeyPress);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(1083, 9);
            this.button4.Margin = new System.Windows.Forms.Padding(4);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(332, 63);
            this.button4.TabIndex = 33;
            this.button4.Text = "Get All Msg";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.getallmsghead_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(1084, 144);
            this.button3.Margin = new System.Windows.Forms.Padding(4);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(160, 45);
            this.button3.TabIndex = 32;
            this.button3.Text = "Get Msg";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.getmsg_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(1254, 144);
            this.button2.Margin = new System.Windows.Forms.Padding(4);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(160, 45);
            this.button2.TabIndex = 31;
            this.button2.Text = "Delete Msg";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.delmsg_Click);
            // 
            // listViewMsg
            // 
            this.listViewMsg.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.listViewMsg.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader3,
            this.columnHeader21,
            this.columnHeader4,
            this.columnHeader5,
            this.columnHeader7});
            this.listViewMsg.FullRowSelect = true;
            this.listViewMsg.GridLines = true;
            this.listViewMsg.HideSelection = false;
            this.listViewMsg.Location = new System.Drawing.Point(0, 0);
            this.listViewMsg.Margin = new System.Windows.Forms.Padding(4);
            this.listViewMsg.Name = "listViewMsg";
            this.listViewMsg.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.listViewMsg.Size = new System.Drawing.Size(1058, 422);
            this.listViewMsg.TabIndex = 29;
            this.listViewMsg.UseCompatibleStateImageBehavior = false;
            this.listViewMsg.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "ListIdx";
            this.columnHeader3.Width = 56;
            // 
            // columnHeader21
            // 
            this.columnHeader21.Text = "PersonID";
            this.columnHeader21.Width = 120;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Start Time";
            this.columnHeader4.Width = 165;
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "End Time";
            this.columnHeader5.Width = 176;
            // 
            // columnHeader7
            // 
            this.columnHeader7.Text = "Msg Content";
            this.columnHeader7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader7.Width = 340;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.basicconfig2);
            this.tabPage2.Controls.Add(this.groupBox6);
            this.tabPage2.Controls.Add(this.groupBox5);
            this.tabPage2.Controls.Add(this.groupBox4);
            this.tabPage2.Controls.Add(this.groupBox3);
            this.tabPage2.Location = new System.Drawing.Point(4, 28);
            this.tabPage2.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage2.Size = new System.Drawing.Size(1444, 501);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Preferences";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // basicconfig2
            // 
            this.basicconfig2.Controls.Add(this.config2_52);
            this.basicconfig2.Controls.Add(this.label67);
            this.basicconfig2.Controls.Add(this.label42);
            this.basicconfig2.Controls.Add(this.label41);
            this.basicconfig2.Controls.Add(this.label40);
            this.basicconfig2.Controls.Add(this.label39);
            this.basicconfig2.Controls.Add(this.label38);
            this.basicconfig2.Controls.Add(this.label37);
            this.basicconfig2.Controls.Add(this.label36);
            this.basicconfig2.Controls.Add(this.label35);
            this.basicconfig2.Controls.Add(this.label34);
            this.basicconfig2.Controls.Add(this.label33);
            this.basicconfig2.Controls.Add(this.label32);
            this.basicconfig2.Controls.Add(this.label31);
            this.basicconfig2.Controls.Add(this.config_l1);
            this.basicconfig2.Controls.Add(this.config2_9);
            this.basicconfig2.Controls.Add(this.config2_10);
            this.basicconfig2.Controls.Add(this.config2_11);
            this.basicconfig2.Controls.Add(this.config2_12);
            this.basicconfig2.Controls.Add(this.config2_13);
            this.basicconfig2.Controls.Add(this.config2_7);
            this.basicconfig2.Controls.Add(this.config2_4);
            this.basicconfig2.Controls.Add(this.config2_8);
            this.basicconfig2.Controls.Add(this.config2_5);
            this.basicconfig2.Controls.Add(this.config2_2);
            this.basicconfig2.Controls.Add(this.config2_6);
            this.basicconfig2.Controls.Add(this.config2_3);
            this.basicconfig2.Controls.Add(this.getconfig2);
            this.basicconfig2.Controls.Add(this.setconfig2);
            this.basicconfig2.Controls.Add(this.config2_1);
            this.basicconfig2.Location = new System.Drawing.Point(942, 132);
            this.basicconfig2.Margin = new System.Windows.Forms.Padding(4);
            this.basicconfig2.Name = "basicconfig2";
            this.basicconfig2.Padding = new System.Windows.Forms.Padding(4);
            this.basicconfig2.Size = new System.Drawing.Size(489, 303);
            this.basicconfig2.TabIndex = 24;
            this.basicconfig2.TabStop = false;
            this.basicconfig2.Text = "Basic config2";
            // 
            // config2_52
            // 
            this.config2_52.Location = new System.Drawing.Point(420, 86);
            this.config2_52.Margin = new System.Windows.Forms.Padding(4);
            this.config2_52.Name = "config2_52";
            this.config2_52.Size = new System.Drawing.Size(34, 28);
            this.config2_52.TabIndex = 74;
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Location = new System.Drawing.Point(242, 90);
            this.label67.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(188, 18);
            this.label67.TabIndex = 73;
            this.label67.Text = "unauthorized record:";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(242, 222);
            this.label42.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(125, 18);
            this.label42.TabIndex = 72;
            this.label42.Text = "correct time:";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(45, 222);
            this.label41.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(107, 18);
            this.label41.TabIndex = 71;
            this.label41.Text = "bell delay:";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(242, 188);
            this.label40.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(125, 18);
            this.label40.TabIndex = 70;
            this.label40.Text = "sensor_alarm:";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(44, 190);
            this.label39.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(116, 18);
            this.label39.TabIndex = 69;
            this.label39.Text = "atten delay:";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(242, 160);
            this.label38.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(170, 18);
            this.label38.TabIndex = 68;
            this.label38.Text = "record over alarm:";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(45, 160);
            this.label37.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(98, 18);
            this.label37.TabIndex = 67;
            this.label37.Text = "lock delay";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(242, 124);
            this.label36.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(89, 18);
            this.label36.TabIndex = 66;
            this.label36.Text = "bell lock";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(45, 58);
            this.label35.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(125, 18);
            this.label35.TabIndex = 65;
            this.label35.Text = "wiegand type:";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(242, 58);
            this.label34.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(98, 18);
            this.label34.TabIndex = 64;
            this.label34.Text = "work code:";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(44, 90);
            this.label33.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(98, 18);
            this.label33.TabIndex = 63;
            this.label33.Text = "time send:";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(44, 129);
            this.label32.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(116, 18);
            this.label32.TabIndex = 62;
            this.label32.Text = "auto update:";
            this.label32.Click += new System.EventHandler(this.label32_Click);
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(242, 26);
            this.label31.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(134, 18);
            this.label31.TabIndex = 61;
            this.label31.Text = "wiegand range:";
            // 
            // config_l1
            // 
            this.config_l1.AutoSize = true;
            this.config_l1.Location = new System.Drawing.Point(44, 26);
            this.config_l1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.config_l1.Name = "config_l1";
            this.config_l1.Size = new System.Drawing.Size(134, 18);
            this.config_l1.TabIndex = 60;
            this.config_l1.Text = "compare level:";
            this.config_l1.Click += new System.EventHandler(this.label30_Click);
            // 
            // config2_9
            // 
            this.config2_9.Location = new System.Drawing.Point(420, 150);
            this.config2_9.Margin = new System.Windows.Forms.Padding(4);
            this.config2_9.Name = "config2_9";
            this.config2_9.Size = new System.Drawing.Size(34, 28);
            this.config2_9.TabIndex = 59;
            // 
            // config2_10
            // 
            this.config2_10.Location = new System.Drawing.Point(178, 183);
            this.config2_10.Margin = new System.Windows.Forms.Padding(4);
            this.config2_10.Name = "config2_10";
            this.config2_10.Size = new System.Drawing.Size(34, 28);
            this.config2_10.TabIndex = 58;
            // 
            // config2_11
            // 
            this.config2_11.Location = new System.Drawing.Point(420, 188);
            this.config2_11.Margin = new System.Windows.Forms.Padding(4);
            this.config2_11.Name = "config2_11";
            this.config2_11.Size = new System.Drawing.Size(34, 28);
            this.config2_11.TabIndex = 57;
            // 
            // config2_12
            // 
            this.config2_12.Location = new System.Drawing.Point(178, 218);
            this.config2_12.Margin = new System.Windows.Forms.Padding(4);
            this.config2_12.Name = "config2_12";
            this.config2_12.Size = new System.Drawing.Size(34, 28);
            this.config2_12.TabIndex = 56;
            // 
            // config2_13
            // 
            this.config2_13.Location = new System.Drawing.Point(420, 222);
            this.config2_13.Margin = new System.Windows.Forms.Padding(4);
            this.config2_13.Name = "config2_13";
            this.config2_13.Size = new System.Drawing.Size(34, 28);
            this.config2_13.TabIndex = 55;
            // 
            // config2_7
            // 
            this.config2_7.Location = new System.Drawing.Point(420, 116);
            this.config2_7.Margin = new System.Windows.Forms.Padding(4);
            this.config2_7.Name = "config2_7";
            this.config2_7.Size = new System.Drawing.Size(34, 28);
            this.config2_7.TabIndex = 54;
            // 
            // config2_4
            // 
            this.config2_4.Location = new System.Drawing.Point(420, 54);
            this.config2_4.Margin = new System.Windows.Forms.Padding(4);
            this.config2_4.Name = "config2_4";
            this.config2_4.Size = new System.Drawing.Size(34, 28);
            this.config2_4.TabIndex = 53;
            // 
            // config2_8
            // 
            this.config2_8.Location = new System.Drawing.Point(178, 150);
            this.config2_8.Margin = new System.Windows.Forms.Padding(4);
            this.config2_8.Name = "config2_8";
            this.config2_8.Size = new System.Drawing.Size(34, 28);
            this.config2_8.TabIndex = 52;
            // 
            // config2_5
            // 
            this.config2_5.Location = new System.Drawing.Point(178, 76);
            this.config2_5.Margin = new System.Windows.Forms.Padding(4);
            this.config2_5.Name = "config2_5";
            this.config2_5.Size = new System.Drawing.Size(34, 28);
            this.config2_5.TabIndex = 51;
            // 
            // config2_2
            // 
            this.config2_2.Location = new System.Drawing.Point(420, 26);
            this.config2_2.Margin = new System.Windows.Forms.Padding(4);
            this.config2_2.Name = "config2_2";
            this.config2_2.Size = new System.Drawing.Size(34, 28);
            this.config2_2.TabIndex = 50;
            // 
            // config2_6
            // 
            this.config2_6.Location = new System.Drawing.Point(178, 116);
            this.config2_6.Margin = new System.Windows.Forms.Padding(4);
            this.config2_6.Name = "config2_6";
            this.config2_6.Size = new System.Drawing.Size(34, 28);
            this.config2_6.TabIndex = 49;
            // 
            // config2_3
            // 
            this.config2_3.Location = new System.Drawing.Point(178, 50);
            this.config2_3.Margin = new System.Windows.Forms.Padding(4);
            this.config2_3.Name = "config2_3";
            this.config2_3.Size = new System.Drawing.Size(34, 28);
            this.config2_3.TabIndex = 48;
            this.config2_3.TextChanged += new System.EventHandler(this.textBox2_TextChanged_1);
            // 
            // getconfig2
            // 
            this.getconfig2.Location = new System.Drawing.Point(0, 258);
            this.getconfig2.Margin = new System.Windows.Forms.Padding(4);
            this.getconfig2.Name = "getconfig2";
            this.getconfig2.Size = new System.Drawing.Size(168, 45);
            this.getconfig2.TabIndex = 47;
            this.getconfig2.Text = "Get Basic cfg2";
            this.getconfig2.UseVisualStyleBackColor = true;
            this.getconfig2.Click += new System.EventHandler(this.getconfig2_Click);
            // 
            // setconfig2
            // 
            this.setconfig2.Location = new System.Drawing.Point(212, 258);
            this.setconfig2.Margin = new System.Windows.Forms.Padding(4);
            this.setconfig2.Name = "setconfig2";
            this.setconfig2.Size = new System.Drawing.Size(162, 45);
            this.setconfig2.TabIndex = 46;
            this.setconfig2.Text = "Set Basic cfg2";
            this.setconfig2.UseVisualStyleBackColor = true;
            this.setconfig2.Click += new System.EventHandler(this.setconfig2_Click);
            // 
            // config2_1
            // 
            this.config2_1.Location = new System.Drawing.Point(178, 24);
            this.config2_1.Margin = new System.Windows.Forms.Padding(4);
            this.config2_1.Name = "config2_1";
            this.config2_1.Size = new System.Drawing.Size(34, 28);
            this.config2_1.TabIndex = 1;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.gettime);
            this.groupBox6.Controls.Add(this.Box6_sec);
            this.groupBox6.Controls.Add(this.Box6_min);
            this.groupBox6.Controls.Add(this.settime);
            this.groupBox6.Controls.Add(this.Box6_hour);
            this.groupBox6.Controls.Add(this.Box6_day);
            this.groupBox6.Controls.Add(this.Box6_month);
            this.groupBox6.Controls.Add(this.Box6_year);
            this.groupBox6.Location = new System.Drawing.Point(642, 256);
            this.groupBox6.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox6.Size = new System.Drawing.Size(300, 178);
            this.groupBox6.TabIndex = 23;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Time";
            // 
            // gettime
            // 
            this.gettime.Location = new System.Drawing.Point(9, 68);
            this.gettime.Margin = new System.Windows.Forms.Padding(4);
            this.gettime.Name = "gettime";
            this.gettime.Size = new System.Drawing.Size(140, 45);
            this.gettime.TabIndex = 45;
            this.gettime.Text = "Get Time";
            this.gettime.UseVisualStyleBackColor = true;
            this.gettime.Click += new System.EventHandler(this.gettime_Click);
            // 
            // Box6_sec
            // 
            this.Box6_sec.Location = new System.Drawing.Point(256, 22);
            this.Box6_sec.Margin = new System.Windows.Forms.Padding(4);
            this.Box6_sec.Name = "Box6_sec";
            this.Box6_sec.Size = new System.Drawing.Size(32, 28);
            this.Box6_sec.TabIndex = 5;
            // 
            // Box6_min
            // 
            this.Box6_min.Location = new System.Drawing.Point(212, 22);
            this.Box6_min.Margin = new System.Windows.Forms.Padding(4);
            this.Box6_min.Name = "Box6_min";
            this.Box6_min.Size = new System.Drawing.Size(32, 28);
            this.Box6_min.TabIndex = 4;
            // 
            // Box6_hour
            // 
            this.Box6_hour.Location = new System.Drawing.Point(168, 22);
            this.Box6_hour.Margin = new System.Windows.Forms.Padding(4);
            this.Box6_hour.Name = "Box6_hour";
            this.Box6_hour.Size = new System.Drawing.Size(32, 28);
            this.Box6_hour.TabIndex = 3;
            // 
            // Box6_day
            // 
            this.Box6_day.Location = new System.Drawing.Point(124, 22);
            this.Box6_day.Margin = new System.Windows.Forms.Padding(4);
            this.Box6_day.Name = "Box6_day";
            this.Box6_day.Size = new System.Drawing.Size(32, 28);
            this.Box6_day.TabIndex = 2;
            // 
            // Box6_month
            // 
            this.Box6_month.Location = new System.Drawing.Point(81, 22);
            this.Box6_month.Margin = new System.Windows.Forms.Padding(4);
            this.Box6_month.Name = "Box6_month";
            this.Box6_month.Size = new System.Drawing.Size(32, 28);
            this.Box6_month.TabIndex = 1;
            // 
            // Box6_year
            // 
            this.Box6_year.Location = new System.Drawing.Point(9, 22);
            this.Box6_year.Margin = new System.Windows.Forms.Padding(4);
            this.Box6_year.Name = "Box6_year";
            this.Box6_year.Size = new System.Drawing.Size(61, 28);
            this.Box6_year.TabIndex = 0;
            this.Box6_year.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.textBox4_sleep_time);
            this.groupBox5.Controls.Add(this.label18);
            this.groupBox5.Controls.Add(this.button_set_basic_cfg);
            this.groupBox5.Controls.Add(this.button_get_basic_cfg);
            this.groupBox5.Controls.Add(this.comboBox3);
            this.groupBox5.Controls.Add(this.label17);
            this.groupBox5.Controls.Add(this.comboBox2);
            this.groupBox5.Controls.Add(this.comboBox1);
            this.groupBox5.Controls.Add(this.label16);
            this.groupBox5.Controls.Add(this.textBox_pwd);
            this.groupBox5.Controls.Add(this.label15);
            this.groupBox5.Controls.Add(this.label14);
            this.groupBox5.Location = new System.Drawing.Point(14, 254);
            this.groupBox5.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox5.Size = new System.Drawing.Size(609, 182);
            this.groupBox5.TabIndex = 22;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Basic config";
            // 
            // textBox4_sleep_time
            // 
            this.textBox4_sleep_time.Location = new System.Drawing.Point(504, 74);
            this.textBox4_sleep_time.Margin = new System.Windows.Forms.Padding(4);
            this.textBox4_sleep_time.MaxLength = 3;
            this.textBox4_sleep_time.Name = "textBox4_sleep_time";
            this.textBox4_sleep_time.Size = new System.Drawing.Size(90, 28);
            this.textBox4_sleep_time.TabIndex = 13;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(320, 81);
            this.label18.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(170, 18);
            this.label18.TabIndex = 12;
            this.label18.Text = "Sleep time(0~250):";
            // 
            // button_set_basic_cfg
            // 
            this.button_set_basic_cfg.Location = new System.Drawing.Point(454, 132);
            this.button_set_basic_cfg.Margin = new System.Windows.Forms.Padding(4);
            this.button_set_basic_cfg.Name = "button_set_basic_cfg";
            this.button_set_basic_cfg.Size = new System.Drawing.Size(146, 39);
            this.button_set_basic_cfg.TabIndex = 11;
            this.button_set_basic_cfg.Text = "Set Basic cfg";
            this.button_set_basic_cfg.UseVisualStyleBackColor = true;
            this.button_set_basic_cfg.Click += new System.EventHandler(this.button_set_basic_cfg_Click);
            // 
            // button_get_basic_cfg
            // 
            this.button_get_basic_cfg.Location = new System.Drawing.Point(310, 132);
            this.button_get_basic_cfg.Margin = new System.Windows.Forms.Padding(4);
            this.button_get_basic_cfg.Name = "button_get_basic_cfg";
            this.button_get_basic_cfg.Size = new System.Drawing.Size(144, 38);
            this.button_get_basic_cfg.TabIndex = 10;
            this.button_get_basic_cfg.Text = "Get Basic cfg";
            this.button_get_basic_cfg.UseVisualStyleBackColor = true;
            this.button_get_basic_cfg.Click += new System.EventHandler(this.button_get_basic_cfg_Click);
            // 
            // comboBox3
            // 
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Items.AddRange(new object[] {
            "0-24 hours",
            "1-12 hours"});
            this.comboBox3.Location = new System.Drawing.Point(468, 34);
            this.comboBox3.Margin = new System.Windows.Forms.Padding(4);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(130, 26);
            this.comboBox3.TabIndex = 9;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(344, 39);
            this.label17.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(116, 18);
            this.label17.TabIndex = 8;
            this.label17.Text = "Time format:";
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Items.AddRange(new object[] {
            "0-China",
            "1-US",
            "2-UK"});
            this.comboBox2.Location = new System.Drawing.Point(168, 123);
            this.comboBox2.Margin = new System.Windows.Forms.Padding(4);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(132, 26);
            this.comboBox2.TabIndex = 7;
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5"});
            this.comboBox1.Location = new System.Drawing.Point(168, 34);
            this.comboBox1.Margin = new System.Windows.Forms.Padding(4);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(118, 26);
            this.comboBox1.TabIndex = 6;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(40, 134);
            this.label16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(116, 18);
            this.label16.TabIndex = 5;
            this.label16.Text = "Date format:";
            // 
            // textBox_pwd
            // 
            this.textBox_pwd.Location = new System.Drawing.Point(168, 81);
            this.textBox_pwd.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_pwd.MaxLength = 6;
            this.textBox_pwd.Name = "textBox_pwd";
            this.textBox_pwd.Size = new System.Drawing.Size(118, 28);
            this.textBox_pwd.TabIndex = 3;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(21, 84);
            this.label15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(125, 18);
            this.label15.TabIndex = 2;
            this.label15.Text = "Admin pwd(6):";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(38, 39);
            this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(116, 18);
            this.label14.TabIndex = 0;
            this.label14.Text = "Volume(0-5):";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.button_get_sn);
            this.groupBox4.Controls.Add(this.textBox_sn);
            this.groupBox4.Controls.Add(this.label13);
            this.groupBox4.Location = new System.Drawing.Point(876, 12);
            this.groupBox4.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox4.Size = new System.Drawing.Size(561, 122);
            this.groupBox4.TabIndex = 21;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Serial Number";
            // 
            // button_get_sn
            // 
            this.button_get_sn.Location = new System.Drawing.Point(76, 72);
            this.button_get_sn.Margin = new System.Windows.Forms.Padding(4);
            this.button_get_sn.Name = "button_get_sn";
            this.button_get_sn.Size = new System.Drawing.Size(166, 39);
            this.button_get_sn.TabIndex = 2;
            this.button_get_sn.Text = "Get SN";
            this.button_get_sn.UseVisualStyleBackColor = true;
            this.button_get_sn.Click += new System.EventHandler(this.button_get_sn_Click);
            // 
            // textBox_sn
            // 
            this.textBox_sn.Location = new System.Drawing.Point(75, 22);
            this.textBox_sn.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_sn.Name = "textBox_sn";
            this.textBox_sn.Size = new System.Drawing.Size(348, 28);
            this.textBox_sn.TabIndex = 1;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(32, 30);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(35, 18);
            this.label13.TabIndex = 0;
            this.label13.Text = "SN:";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.textBoxMask);
            this.groupBox3.Controls.Add(this.checkBoxDHCP);
            this.groupBox3.Controls.Add(this.textBoxPort);
            this.groupBox3.Controls.Add(this.textBoxGw);
            this.groupBox3.Controls.Add(this.textBoxIp);
            this.groupBox3.Controls.Add(this.textBoxRemote);
            this.groupBox3.Controls.Add(this.buttonGetNet);
            this.groupBox3.Controls.Add(this.label11);
            this.groupBox3.Controls.Add(this.buttonSetNet);
            this.groupBox3.Controls.Add(this.textBoxServIp);
            this.groupBox3.Controls.Add(this.label2);
            this.groupBox3.Controls.Add(this.label10);
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Controls.Add(this.textBoxMode);
            this.groupBox3.Controls.Add(this.label9);
            this.groupBox3.Controls.Add(this.label8);
            this.groupBox3.Controls.Add(this.textBoxMac);
            this.groupBox3.Controls.Add(this.label7);
            this.groupBox3.Location = new System.Drawing.Point(9, 9);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox3.Size = new System.Drawing.Size(838, 234);
            this.groupBox3.TabIndex = 20;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Network";
            // 
            // textBoxMask
            // 
            this.textBoxMask.Location = new System.Drawing.Point(92, 75);
            this.textBoxMask.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxMask.Name = "textBoxMask";
            this.textBoxMask.Size = new System.Drawing.Size(212, 28);
            this.textBoxMask.TabIndex = 4;
            this.textBoxMask.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // checkBoxDHCP
            // 
            this.checkBoxDHCP.AutoSize = true;
            this.checkBoxDHCP.Location = new System.Drawing.Point(662, 38);
            this.checkBoxDHCP.Margin = new System.Windows.Forms.Padding(4);
            this.checkBoxDHCP.Name = "checkBoxDHCP";
            this.checkBoxDHCP.Size = new System.Drawing.Size(70, 22);
            this.checkBoxDHCP.TabIndex = 15;
            this.checkBoxDHCP.Text = "DHCP";
            this.checkBoxDHCP.UseVisualStyleBackColor = true;
            // 
            // textBoxPort
            // 
            this.textBoxPort.Location = new System.Drawing.Point(92, 156);
            this.textBoxPort.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxPort.Name = "textBoxPort";
            this.textBoxPort.Size = new System.Drawing.Size(212, 28);
            this.textBoxPort.TabIndex = 10;
            this.textBoxPort.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxGw
            // 
            this.textBoxGw.Location = new System.Drawing.Point(92, 116);
            this.textBoxGw.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxGw.Name = "textBoxGw";
            this.textBoxGw.Size = new System.Drawing.Size(212, 28);
            this.textBoxGw.TabIndex = 6;
            this.textBoxGw.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxIp
            // 
            this.textBoxIp.Location = new System.Drawing.Point(92, 34);
            this.textBoxIp.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxIp.Name = "textBoxIp";
            this.textBoxIp.Size = new System.Drawing.Size(212, 28);
            this.textBoxIp.TabIndex = 0;
            this.textBoxIp.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBoxIp.TextChanged += new System.EventHandler(this.textBoxIp_TextChanged);
            // 
            // textBoxRemote
            // 
            this.textBoxRemote.Enabled = false;
            this.textBoxRemote.Location = new System.Drawing.Point(399, 156);
            this.textBoxRemote.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxRemote.MaxLength = 1;
            this.textBoxRemote.Name = "textBoxRemote";
            this.textBoxRemote.Size = new System.Drawing.Size(212, 28);
            this.textBoxRemote.TabIndex = 18;
            this.textBoxRemote.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // buttonGetNet
            // 
            this.buttonGetNet.Location = new System.Drawing.Point(658, 74);
            this.buttonGetNet.Margin = new System.Windows.Forms.Padding(4);
            this.buttonGetNet.Name = "buttonGetNet";
            this.buttonGetNet.Size = new System.Drawing.Size(162, 52);
            this.buttonGetNet.TabIndex = 1;
            this.buttonGetNet.Text = "Get Net Config";
            this.buttonGetNet.UseVisualStyleBackColor = true;
            this.buttonGetNet.Click += new System.EventHandler(this.buttonGetNet_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(330, 160);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(71, 18);
            this.label11.TabIndex = 19;
            this.label11.Text = "Remote:";
            // 
            // buttonSetNet
            // 
            this.buttonSetNet.Location = new System.Drawing.Point(660, 134);
            this.buttonSetNet.Margin = new System.Windows.Forms.Padding(4);
            this.buttonSetNet.Name = "buttonSetNet";
            this.buttonSetNet.Size = new System.Drawing.Size(160, 52);
            this.buttonSetNet.TabIndex = 2;
            this.buttonSetNet.Text = "Set Net Config";
            this.buttonSetNet.UseVisualStyleBackColor = true;
            this.buttonSetNet.Click += new System.EventHandler(this.buttonSetNet_Click);
            // 
            // textBoxServIp
            // 
            this.textBoxServIp.Location = new System.Drawing.Point(399, 75);
            this.textBoxServIp.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxServIp.Name = "textBoxServIp";
            this.textBoxServIp.Size = new System.Drawing.Size(212, 28);
            this.textBoxServIp.TabIndex = 16;
            this.textBoxServIp.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(58, 39);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 18);
            this.label2.TabIndex = 3;
            this.label2.Text = "IP:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(330, 80);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(71, 18);
            this.label10.TabIndex = 17;
            this.label10.Text = "ServIp:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(40, 80);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(53, 18);
            this.label5.TabIndex = 5;
            this.label5.Text = "Mask:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(14, 120);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(80, 18);
            this.label6.TabIndex = 7;
            this.label6.Text = "Gateway:";
            // 
            // textBoxMode
            // 
            this.textBoxMode.Enabled = false;
            this.textBoxMode.Location = new System.Drawing.Point(399, 116);
            this.textBoxMode.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxMode.MaxLength = 1;
            this.textBoxMode.Name = "textBoxMode";
            this.textBoxMode.Size = new System.Drawing.Size(212, 28);
            this.textBoxMode.TabIndex = 12;
            this.textBoxMode.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBoxMode.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxMode_KeyPress);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(357, 39);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(44, 18);
            this.label9.TabIndex = 9;
            this.label9.Text = "Mac:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(40, 160);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(53, 18);
            this.label8.TabIndex = 11;
            this.label8.Text = "Port:";
            // 
            // textBoxMac
            // 
            this.textBoxMac.Enabled = false;
            this.textBoxMac.Location = new System.Drawing.Point(400, 34);
            this.textBoxMac.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxMac.Name = "textBoxMac";
            this.textBoxMac.Size = new System.Drawing.Size(212, 28);
            this.textBoxMac.TabIndex = 8;
            this.textBoxMac.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(348, 120);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(53, 18);
            this.label7.TabIndex = 13;
            this.label7.Text = "Mode:";
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.textBox2);
            this.tabPage4.Controls.Add(this.checkBox1);
            this.tabPage4.Controls.Add(this.textBox_reserved2);
            this.tabPage4.Controls.Add(this.label172);
            this.tabPage4.Controls.Add(this.label122);
            this.tabPage4.Controls.Add(this.get_p_001);
            this.tabPage4.Controls.Add(this.button16);
            this.tabPage4.Controls.Add(this.label100);
            this.tabPage4.Controls.Add(this.label99);
            this.tabPage4.Controls.Add(this.drname02);
            this.tabPage4.Controls.Add(this.drname01);
            this.tabPage4.Controls.Add(this.addfp_person_id);
            this.tabPage4.Controls.Add(this.label66);
            this.tabPage4.Controls.Add(this.label50);
            this.tabPage4.Controls.Add(this.fptext_01);
            this.tabPage4.Controls.Add(this.add_fp);
            this.tabPage4.Controls.Add(this.label49);
            this.tabPage4.Controls.Add(this.label181);
            this.tabPage4.Controls.Add(this.label45);
            this.tabPage4.Controls.Add(this.text_time2);
            this.tabPage4.Controls.Add(this.text_time1);
            this.tabPage4.Controls.Add(this.button_put_fp_raw_data);
            this.tabPage4.Controls.Add(this.button_get_fp_raw_data);
            this.tabPage4.Controls.Add(this.button8_delete_person);
            this.tabPage4.Controls.Add(this.button7_modify_person);
            this.tabPage4.Controls.Add(this.textBox_special);
            this.tabPage4.Controls.Add(this.textBox_fp_status);
            this.tabPage4.Controls.Add(this.textBox_mode);
            this.tabPage4.Controls.Add(this.textBox_group);
            this.tabPage4.Controls.Add(this.textBox_dept);
            this.tabPage4.Controls.Add(this.textBox_cardID);
            this.tabPage4.Controls.Add(this.textBox_password);
            this.tabPage4.Controls.Add(this.textBox_name);
            this.tabPage4.Controls.Add(this.textBox_personID);
            this.tabPage4.Controls.Add(this.label27);
            this.tabPage4.Controls.Add(this.label26);
            this.tabPage4.Controls.Add(this.label25);
            this.tabPage4.Controls.Add(this.label24);
            this.tabPage4.Controls.Add(this.label23);
            this.tabPage4.Controls.Add(this.label22);
            this.tabPage4.Controls.Add(this.label21);
            this.tabPage4.Controls.Add(this.label20);
            this.tabPage4.Controls.Add(this.label19);
            this.tabPage4.Controls.Add(this.button7_get_all_person);
            this.tabPage4.Controls.Add(this.listView_person);
            this.tabPage4.Location = new System.Drawing.Point(4, 28);
            this.tabPage4.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage4.Size = new System.Drawing.Size(1444, 501);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Person";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(423, 138);
            this.textBox2.Margin = new System.Windows.Forms.Padding(4);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(85, 28);
            this.textBox2.TabIndex = 48;
            this.textBox2.Text = "0";
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(604, 22);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(160, 22);
            this.checkBox1.TabIndex = 47;
            this.checkBox1.Text = "Has Scheduling";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // textBox_reserved2
            // 
            this.textBox_reserved2.Location = new System.Drawing.Point(946, 86);
            this.textBox_reserved2.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_reserved2.Name = "textBox_reserved2";
            this.textBox_reserved2.Size = new System.Drawing.Size(82, 28);
            this.textBox_reserved2.TabIndex = 45;
            this.textBox_reserved2.Text = "0";
            // 
            // label172
            // 
            this.label172.AutoSize = true;
            this.label172.Location = new System.Drawing.Point(942, 64);
            this.label172.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label172.Name = "label172";
            this.label172.Size = new System.Drawing.Size(89, 18);
            this.label172.TabIndex = 44;
            this.label172.Text = "Reserved2";
            this.label172.Click += new System.EventHandler(this.label172_Click);
            // 
            // label122
            // 
            this.label122.AutoSize = true;
            this.label122.Location = new System.Drawing.Point(174, 21);
            this.label122.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label122.Name = "label122";
            this.label122.Size = new System.Drawing.Size(98, 18);
            this.label122.TabIndex = 43;
            this.label122.Text = "Person ID:";
            // 
            // get_p_001
            // 
            this.get_p_001.Location = new System.Drawing.Point(281, 16);
            this.get_p_001.Margin = new System.Windows.Forms.Padding(4);
            this.get_p_001.Name = "get_p_001";
            this.get_p_001.Size = new System.Drawing.Size(113, 28);
            this.get_p_001.TabIndex = 42;
            this.get_p_001.Text = "1";
            // 
            // button16
            // 
            this.button16.Location = new System.Drawing.Point(402, 12);
            this.button16.Margin = new System.Windows.Forms.Padding(4);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(166, 41);
            this.button16.TabIndex = 41;
            this.button16.Text = "Get Person By ID";
            this.button16.UseVisualStyleBackColor = true;
            this.button16.Click += new System.EventHandler(this.button16_Click);
            // 
            // label100
            // 
            this.label100.AutoSize = true;
            this.label100.Location = new System.Drawing.Point(1065, 141);
            this.label100.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label100.Name = "label100";
            this.label100.Size = new System.Drawing.Size(89, 18);
            this.label100.TabIndex = 40;
            this.label100.Text = "DR::Name2";
            // 
            // label99
            // 
            this.label99.AutoSize = true;
            this.label99.Location = new System.Drawing.Point(664, 141);
            this.label99.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label99.Name = "label99";
            this.label99.Size = new System.Drawing.Size(89, 18);
            this.label99.TabIndex = 39;
            this.label99.Text = "DR::Name1";
            // 
            // drname02
            // 
            this.drname02.Location = new System.Drawing.Point(1157, 137);
            this.drname02.Margin = new System.Windows.Forms.Padding(4);
            this.drname02.Name = "drname02";
            this.drname02.Size = new System.Drawing.Size(270, 28);
            this.drname02.TabIndex = 38;
            // 
            // drname01
            // 
            this.drname01.Location = new System.Drawing.Point(761, 137);
            this.drname01.Margin = new System.Windows.Forms.Padding(4);
            this.drname01.Name = "drname01";
            this.drname01.Size = new System.Drawing.Size(292, 28);
            this.drname01.TabIndex = 37;
            // 
            // addfp_person_id
            // 
            this.addfp_person_id.Location = new System.Drawing.Point(1099, 3);
            this.addfp_person_id.Margin = new System.Windows.Forms.Padding(4);
            this.addfp_person_id.Name = "addfp_person_id";
            this.addfp_person_id.Size = new System.Drawing.Size(98, 28);
            this.addfp_person_id.TabIndex = 36;
            this.addfp_person_id.Text = "123321";
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Location = new System.Drawing.Point(925, 9);
            this.label66.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(170, 18);
            this.label66.TabIndex = 35;
            this.label66.Text = "New Temp PersonID:";
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Location = new System.Drawing.Point(1005, 39);
            this.label50.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(152, 18);
            this.label50.TabIndex = 34;
            this.label50.Text = "PF Backup(1-10):";
            // 
            // fptext_01
            // 
            this.fptext_01.Location = new System.Drawing.Point(1165, 34);
            this.fptext_01.Margin = new System.Windows.Forms.Padding(4);
            this.fptext_01.Name = "fptext_01";
            this.fptext_01.Size = new System.Drawing.Size(32, 28);
            this.fptext_01.TabIndex = 33;
            this.fptext_01.Text = "1";
            // 
            // add_fp
            // 
            this.add_fp.Location = new System.Drawing.Point(1199, 0);
            this.add_fp.Margin = new System.Windows.Forms.Padding(4);
            this.add_fp.Name = "add_fp";
            this.add_fp.Size = new System.Drawing.Size(240, 34);
            this.add_fp.TabIndex = 32;
            this.add_fp.Text = "Add FP Online";
            this.add_fp.UseVisualStyleBackColor = true;
            this.add_fp.Click += new System.EventHandler(this.add_fp_Click);
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(207, 145);
            this.label49.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(17, 18);
            this.label49.TabIndex = 31;
            this.label49.Text = "-";
            // 
            // label181
            // 
            this.label181.AutoSize = true;
            this.label181.Location = new System.Drawing.Point(420, 116);
            this.label181.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label181.Name = "label181";
            this.label181.Size = new System.Drawing.Size(62, 18);
            this.label181.TabIndex = 30;
            this.label181.Text = "SCH ID";
            this.label181.Click += new System.EventHandler(this.label45_Click);
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(10, 116);
            this.label45.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(71, 18);
            this.label45.TabIndex = 30;
            this.label45.Text = "Valid T";
            this.label45.Click += new System.EventHandler(this.label45_Click);
            // 
            // text_time2
            // 
            this.text_time2.Location = new System.Drawing.Point(227, 141);
            this.text_time2.Margin = new System.Windows.Forms.Padding(4);
            this.text_time2.Name = "text_time2";
            this.text_time2.Size = new System.Drawing.Size(184, 28);
            this.text_time2.TabIndex = 29;
            this.text_time2.Text = "2028-01-01 00:00:00";
            // 
            // text_time1
            // 
            this.text_time1.Location = new System.Drawing.Point(13, 141);
            this.text_time1.Margin = new System.Windows.Forms.Padding(4);
            this.text_time1.Name = "text_time1";
            this.text_time1.Size = new System.Drawing.Size(187, 28);
            this.text_time1.TabIndex = 28;
            this.text_time1.Text = "2018-01-01 00:00:00";
            // 
            // button_put_fp_raw_data
            // 
            this.button_put_fp_raw_data.Enabled = false;
            this.button_put_fp_raw_data.Location = new System.Drawing.Point(1327, 32);
            this.button_put_fp_raw_data.Margin = new System.Windows.Forms.Padding(4);
            this.button_put_fp_raw_data.Name = "button_put_fp_raw_data";
            this.button_put_fp_raw_data.Size = new System.Drawing.Size(112, 34);
            this.button_put_fp_raw_data.TabIndex = 23;
            this.button_put_fp_raw_data.Text = "Put_FPRaw";
            this.button_put_fp_raw_data.UseVisualStyleBackColor = true;
            this.button_put_fp_raw_data.Click += new System.EventHandler(this.button_put_fp_raw_data_Click);
            // 
            // button_get_fp_raw_data
            // 
            this.button_get_fp_raw_data.Enabled = false;
            this.button_get_fp_raw_data.Location = new System.Drawing.Point(1199, 32);
            this.button_get_fp_raw_data.Margin = new System.Windows.Forms.Padding(4);
            this.button_get_fp_raw_data.Name = "button_get_fp_raw_data";
            this.button_get_fp_raw_data.Size = new System.Drawing.Size(118, 34);
            this.button_get_fp_raw_data.TabIndex = 22;
            this.button_get_fp_raw_data.Text = "Get_FPRaw";
            this.button_get_fp_raw_data.UseVisualStyleBackColor = true;
            this.button_get_fp_raw_data.Click += new System.EventHandler(this.button_get_fp_raw_data_Click);
            // 
            // button8_delete_person
            // 
            this.button8_delete_person.Enabled = false;
            this.button8_delete_person.Location = new System.Drawing.Point(1312, 95);
            this.button8_delete_person.Margin = new System.Windows.Forms.Padding(4);
            this.button8_delete_person.Name = "button8_delete_person";
            this.button8_delete_person.Size = new System.Drawing.Size(118, 33);
            this.button8_delete_person.TabIndex = 21;
            this.button8_delete_person.Text = "Delete";
            this.button8_delete_person.UseVisualStyleBackColor = true;
            this.button8_delete_person.Click += new System.EventHandler(this.button8_delete_person_Click);
            // 
            // button7_modify_person
            // 
            this.button7_modify_person.Location = new System.Drawing.Point(1184, 95);
            this.button7_modify_person.Margin = new System.Windows.Forms.Padding(4);
            this.button7_modify_person.Name = "button7_modify_person";
            this.button7_modify_person.Size = new System.Drawing.Size(118, 33);
            this.button7_modify_person.TabIndex = 20;
            this.button7_modify_person.Text = "Add/Modify";
            this.button7_modify_person.UseVisualStyleBackColor = true;
            this.button7_modify_person.Click += new System.EventHandler(this.button7_modify_person_Click);
            // 
            // textBox_special
            // 
            this.textBox_special.Location = new System.Drawing.Point(1058, 86);
            this.textBox_special.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_special.Name = "textBox_special";
            this.textBox_special.Size = new System.Drawing.Size(82, 28);
            this.textBox_special.TabIndex = 19;
            this.textBox_special.Text = "64";
            // 
            // textBox_fp_status
            // 
            this.textBox_fp_status.Location = new System.Drawing.Point(836, 84);
            this.textBox_fp_status.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_fp_status.Name = "textBox_fp_status";
            this.textBox_fp_status.Size = new System.Drawing.Size(82, 28);
            this.textBox_fp_status.TabIndex = 18;
            this.textBox_fp_status.Text = "0";
            // 
            // textBox_mode
            // 
            this.textBox_mode.Location = new System.Drawing.Point(743, 84);
            this.textBox_mode.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_mode.Name = "textBox_mode";
            this.textBox_mode.Size = new System.Drawing.Size(82, 28);
            this.textBox_mode.TabIndex = 17;
            this.textBox_mode.Text = "6";
            // 
            // textBox_group
            // 
            this.textBox_group.Location = new System.Drawing.Point(653, 84);
            this.textBox_group.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_group.Name = "textBox_group";
            this.textBox_group.Size = new System.Drawing.Size(82, 28);
            this.textBox_group.TabIndex = 16;
            this.textBox_group.Text = "2";
            // 
            // textBox_dept
            // 
            this.textBox_dept.Location = new System.Drawing.Point(575, 83);
            this.textBox_dept.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_dept.Name = "textBox_dept";
            this.textBox_dept.Size = new System.Drawing.Size(67, 28);
            this.textBox_dept.TabIndex = 15;
            this.textBox_dept.Text = "0";
            // 
            // textBox_cardID
            // 
            this.textBox_cardID.Location = new System.Drawing.Point(423, 84);
            this.textBox_cardID.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_cardID.Name = "textBox_cardID";
            this.textBox_cardID.Size = new System.Drawing.Size(142, 28);
            this.textBox_cardID.TabIndex = 14;
            this.textBox_cardID.Text = "1";
            // 
            // textBox_password
            // 
            this.textBox_password.Location = new System.Drawing.Point(295, 83);
            this.textBox_password.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_password.Name = "textBox_password";
            this.textBox_password.Size = new System.Drawing.Size(116, 28);
            this.textBox_password.TabIndex = 13;
            this.textBox_password.Text = "1";
            // 
            // textBox_name
            // 
            this.textBox_name.Location = new System.Drawing.Point(161, 84);
            this.textBox_name.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_name.Name = "textBox_name";
            this.textBox_name.Size = new System.Drawing.Size(108, 28);
            this.textBox_name.TabIndex = 12;
            this.textBox_name.Text = "1";
            // 
            // textBox_personID
            // 
            this.textBox_personID.Location = new System.Drawing.Point(13, 84);
            this.textBox_personID.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_personID.Name = "textBox_personID";
            this.textBox_personID.Size = new System.Drawing.Size(138, 28);
            this.textBox_personID.TabIndex = 11;
            this.textBox_personID.Text = "1";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(1072, 64);
            this.label27.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(71, 18);
            this.label27.TabIndex = 10;
            this.label27.Text = "Special";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(834, 62);
            this.label26.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(89, 18);
            this.label26.TabIndex = 9;
            this.label26.Text = "Fp status";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(741, 60);
            this.label25.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(44, 18);
            this.label25.TabIndex = 8;
            this.label25.Text = "Mode";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(651, 58);
            this.label24.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(53, 18);
            this.label24.TabIndex = 7;
            this.label24.Text = "Group";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(575, 62);
            this.label23.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(44, 18);
            this.label23.TabIndex = 6;
            this.label23.Text = "Dept";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(433, 64);
            this.label22.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(71, 18);
            this.label22.TabIndex = 5;
            this.label22.Text = "Card ID";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(291, 62);
            this.label21.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(80, 18);
            this.label21.TabIndex = 4;
            this.label21.Text = "Password";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(173, 59);
            this.label20.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(44, 18);
            this.label20.TabIndex = 3;
            this.label20.Text = "Name";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(10, 59);
            this.label19.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(89, 18);
            this.label19.TabIndex = 2;
            this.label19.Text = "Person ID";
            // 
            // button7_get_all_person
            // 
            this.button7_get_all_person.Location = new System.Drawing.Point(12, 8);
            this.button7_get_all_person.Margin = new System.Windows.Forms.Padding(4);
            this.button7_get_all_person.Name = "button7_get_all_person";
            this.button7_get_all_person.Size = new System.Drawing.Size(145, 45);
            this.button7_get_all_person.TabIndex = 1;
            this.button7_get_all_person.Text = "Get_all_person";
            this.button7_get_all_person.UseVisualStyleBackColor = true;
            this.button7_get_all_person.Click += new System.EventHandler(this.button7_get_all_person_Click);
            // 
            // listView_person
            // 
            this.listView_person.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader9,
            this.columnHeader10,
            this.columnHeader11,
            this.columnHeader12,
            this.columnHeader13,
            this.columnHeader14,
            this.columnHeader15,
            this.columnHeader16,
            this.columnHeader17,
            this.columnHeader32,
            this.columnHeader18,
            this.columnHeader19,
            this.columnHeader20,
            this.columnHeader33});
            this.listView_person.FullRowSelect = true;
            this.listView_person.GridLines = true;
            this.listView_person.Location = new System.Drawing.Point(9, 173);
            this.listView_person.Margin = new System.Windows.Forms.Padding(4);
            this.listView_person.Name = "listView_person";
            this.listView_person.Size = new System.Drawing.Size(1420, 324);
            this.listView_person.TabIndex = 0;
            this.listView_person.UseCompatibleStateImageBehavior = false;
            this.listView_person.View = System.Windows.Forms.View.Details;
            this.listView_person.SelectedIndexChanged += new System.EventHandler(this.listView_person_Click);
            // 
            // columnHeader9
            // 
            this.columnHeader9.Text = "No";
            // 
            // columnHeader10
            // 
            this.columnHeader10.Text = "Person ID";
            this.columnHeader10.Width = 80;
            // 
            // columnHeader11
            // 
            this.columnHeader11.Text = "Name";
            this.columnHeader11.Width = 69;
            // 
            // columnHeader12
            // 
            this.columnHeader12.Text = "Password";
            this.columnHeader12.Width = 83;
            // 
            // columnHeader13
            // 
            this.columnHeader13.Text = "Card ID";
            this.columnHeader13.Width = 101;
            // 
            // columnHeader14
            // 
            this.columnHeader14.Text = "Dept";
            this.columnHeader14.Width = 53;
            // 
            // columnHeader15
            // 
            this.columnHeader15.Text = "Group";
            // 
            // columnHeader16
            // 
            this.columnHeader16.Text = "Other";
            // 
            // columnHeader17
            // 
            this.columnHeader17.Text = "Fp status";
            this.columnHeader17.Width = 71;
            // 
            // columnHeader32
            // 
            this.columnHeader32.Text = "reserve2";
            // 
            // columnHeader18
            // 
            this.columnHeader18.Text = "Special";
            this.columnHeader18.Width = 58;
            // 
            // columnHeader19
            // 
            this.columnHeader19.Text = "start time";
            this.columnHeader19.Width = 81;
            // 
            // columnHeader20
            // 
            this.columnHeader20.Text = "end time";
            this.columnHeader20.Width = 72;
            // 
            // columnHeader33
            // 
            this.columnHeader33.Text = "schedule ID";
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.button8);
            this.tabPage5.Controls.Add(this.button7);
            this.tabPage5.Controls.Add(this.label65);
            this.tabPage5.Controls.Add(this.label64);
            this.tabPage5.Controls.Add(this.label63);
            this.tabPage5.Controls.Add(this.label62);
            this.tabPage5.Controls.Add(this.label61);
            this.tabPage5.Controls.Add(this.label60);
            this.tabPage5.Controls.Add(this.label59);
            this.tabPage5.Controls.Add(this.label58);
            this.tabPage5.Controls.Add(this.label57);
            this.tabPage5.Controls.Add(this.label56);
            this.tabPage5.Controls.Add(this.label55);
            this.tabPage5.Controls.Add(this.label54);
            this.tabPage5.Controls.Add(this.label53);
            this.tabPage5.Controls.Add(this.udp_13);
            this.tabPage5.Controls.Add(this.udp_09);
            this.tabPage5.Controls.Add(this.udp_08);
            this.tabPage5.Controls.Add(this.udp_12);
            this.tabPage5.Controls.Add(this.udp_11);
            this.tabPage5.Controls.Add(this.udp_07);
            this.tabPage5.Controls.Add(this.udp_10);
            this.tabPage5.Controls.Add(this.udp_06);
            this.tabPage5.Controls.Add(this.udp_05);
            this.tabPage5.Controls.Add(this.udp_04);
            this.tabPage5.Controls.Add(this.udp_03);
            this.tabPage5.Controls.Add(this.udp_02);
            this.tabPage5.Controls.Add(this.udp_01);
            this.tabPage5.Controls.Add(this.listView1);
            this.tabPage5.Controls.Add(this.label30);
            this.tabPage5.Controls.Add(this.but_disconnect);
            this.tabPage5.Controls.Add(this.text_disconnect);
            this.tabPage5.Controls.Add(this.Add_dev_port);
            this.tabPage5.Controls.Add(this.label29);
            this.tabPage5.Controls.Add(this.label12);
            this.tabPage5.Controls.Add(this.Add_dev_Ip);
            this.tabPage5.Controls.Add(this.button6);
            this.tabPage5.Location = new System.Drawing.Point(4, 28);
            this.tabPage5.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage5.Size = new System.Drawing.Size(1444, 501);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "Add dev";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(1106, 39);
            this.button8.Margin = new System.Windows.Forms.Padding(4);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(206, 34);
            this.button8.TabIndex = 37;
            this.button8.Text = "UDP Set Dev";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(884, 39);
            this.button7.Margin = new System.Windows.Forms.Padding(4);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(194, 34);
            this.button7.TabIndex = 36;
            this.button7.Text = "UDP Search Dev";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Location = new System.Drawing.Point(9, 164);
            this.label65.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(44, 18);
            this.label65.TabIndex = 35;
            this.label65.Text = "URL:";
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Location = new System.Drawing.Point(1146, 128);
            this.label64.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(53, 18);
            this.label64.TabIndex = 34;
            this.label64.Text = "Type:";
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Location = new System.Drawing.Point(880, 128);
            this.label63.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(98, 18);
            this.label63.TabIndex = 33;
            this.label63.Text = "MachineId:";
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Location = new System.Drawing.Point(660, 128);
            this.label62.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(44, 18);
            this.label62.TabIndex = 32;
            this.label62.Text = "DNS:";
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Location = new System.Drawing.Point(422, 128);
            this.label61.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(89, 18);
            this.label61.TabIndex = 31;
            this.label61.Text = "Password:";
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Location = new System.Drawing.Point(216, 132);
            this.label60.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(53, 18);
            this.label60.TabIndex = 30;
            this.label60.Text = "User:";
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Location = new System.Drawing.Point(9, 128);
            this.label59.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(53, 18);
            this.label59.TabIndex = 29;
            this.label59.Text = "Mode:";
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Location = new System.Drawing.Point(1146, 87);
            this.label58.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(53, 18);
            this.label58.TabIndex = 28;
            this.label58.Text = "Port:";
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Location = new System.Drawing.Point(880, 87);
            this.label57.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(98, 18);
            this.label57.TabIndex = 27;
            this.label57.Text = "ServiceIP:";
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Location = new System.Drawing.Point(660, 87);
            this.label56.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(44, 18);
            this.label56.TabIndex = 26;
            this.label56.Text = "MAC:";
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Location = new System.Drawing.Point(422, 87);
            this.label55.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(35, 18);
            this.label55.TabIndex = 25;
            this.label55.Text = "GW:";
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Location = new System.Drawing.Point(216, 87);
            this.label54.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(53, 18);
            this.label54.TabIndex = 24;
            this.label54.Text = "MASK:";
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Location = new System.Drawing.Point(9, 87);
            this.label53.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(35, 18);
            this.label53.TabIndex = 23;
            this.label53.Text = "IP:";
            // 
            // udp_13
            // 
            this.udp_13.Location = new System.Drawing.Point(72, 159);
            this.udp_13.Margin = new System.Windows.Forms.Padding(4);
            this.udp_13.Name = "udp_13";
            this.udp_13.Size = new System.Drawing.Size(1237, 28);
            this.udp_13.TabIndex = 22;
            // 
            // udp_09
            // 
            this.udp_09.Location = new System.Drawing.Point(1244, 123);
            this.udp_09.Margin = new System.Windows.Forms.Padding(4);
            this.udp_09.Name = "udp_09";
            this.udp_09.Size = new System.Drawing.Size(66, 28);
            this.udp_09.TabIndex = 21;
            this.udp_09.Text = "0";
            // 
            // udp_08
            // 
            this.udp_08.Location = new System.Drawing.Point(994, 123);
            this.udp_08.Margin = new System.Windows.Forms.Padding(4);
            this.udp_08.Name = "udp_08";
            this.udp_08.Size = new System.Drawing.Size(133, 28);
            this.udp_08.TabIndex = 20;
            // 
            // udp_12
            // 
            this.udp_12.Location = new System.Drawing.Point(720, 123);
            this.udp_12.Margin = new System.Windows.Forms.Padding(4);
            this.udp_12.Name = "udp_12";
            this.udp_12.Size = new System.Drawing.Size(133, 28);
            this.udp_12.TabIndex = 19;
            // 
            // udp_11
            // 
            this.udp_11.Location = new System.Drawing.Point(516, 118);
            this.udp_11.Margin = new System.Windows.Forms.Padding(4);
            this.udp_11.Name = "udp_11";
            this.udp_11.Size = new System.Drawing.Size(133, 28);
            this.udp_11.TabIndex = 18;
            // 
            // udp_07
            // 
            this.udp_07.Location = new System.Drawing.Point(72, 123);
            this.udp_07.Margin = new System.Windows.Forms.Padding(4);
            this.udp_07.Name = "udp_07";
            this.udp_07.Size = new System.Drawing.Size(133, 28);
            this.udp_07.TabIndex = 17;
            // 
            // udp_10
            // 
            this.udp_10.Location = new System.Drawing.Point(278, 123);
            this.udp_10.Margin = new System.Windows.Forms.Padding(4);
            this.udp_10.Name = "udp_10";
            this.udp_10.Size = new System.Drawing.Size(133, 28);
            this.udp_10.TabIndex = 16;
            // 
            // udp_06
            // 
            this.udp_06.Location = new System.Drawing.Point(1244, 82);
            this.udp_06.Margin = new System.Windows.Forms.Padding(4);
            this.udp_06.Name = "udp_06";
            this.udp_06.Size = new System.Drawing.Size(66, 28);
            this.udp_06.TabIndex = 14;
            this.udp_06.Text = "5010";
            // 
            // udp_05
            // 
            this.udp_05.Location = new System.Drawing.Point(994, 82);
            this.udp_05.Margin = new System.Windows.Forms.Padding(4);
            this.udp_05.Name = "udp_05";
            this.udp_05.Size = new System.Drawing.Size(133, 28);
            this.udp_05.TabIndex = 13;
            // 
            // udp_04
            // 
            this.udp_04.Location = new System.Drawing.Point(720, 82);
            this.udp_04.Margin = new System.Windows.Forms.Padding(4);
            this.udp_04.Name = "udp_04";
            this.udp_04.Size = new System.Drawing.Size(133, 28);
            this.udp_04.TabIndex = 12;
            // 
            // udp_03
            // 
            this.udp_03.Location = new System.Drawing.Point(516, 78);
            this.udp_03.Margin = new System.Windows.Forms.Padding(4);
            this.udp_03.Name = "udp_03";
            this.udp_03.Size = new System.Drawing.Size(133, 28);
            this.udp_03.TabIndex = 11;
            // 
            // udp_02
            // 
            this.udp_02.Location = new System.Drawing.Point(278, 82);
            this.udp_02.Margin = new System.Windows.Forms.Padding(4);
            this.udp_02.Name = "udp_02";
            this.udp_02.Size = new System.Drawing.Size(133, 28);
            this.udp_02.TabIndex = 10;
            this.udp_02.TextChanged += new System.EventHandler(this.textBox4_TextChanged);
            // 
            // udp_01
            // 
            this.udp_01.Location = new System.Drawing.Point(72, 82);
            this.udp_01.Margin = new System.Windows.Forms.Padding(4);
            this.udp_01.Name = "udp_01";
            this.udp_01.Size = new System.Drawing.Size(133, 28);
            this.udp_01.TabIndex = 9;
            // 
            // listView1
            // 
            this.listView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.listid,
            this.type,
            this.IP,
            this.MASK,
            this.GW,
            this.MAC,
            this.ServiceIP,
            this.Port,
            this.NetMode,
            this.Machineid,
            this.Reserved,
            this.Username,
            this.Password,
            this.DNS,
            this.URL});
            this.listView1.FullRowSelect = true;
            this.listView1.GridLines = true;
            this.listView1.Location = new System.Drawing.Point(-6, 200);
            this.listView1.Margin = new System.Windows.Forms.Padding(4);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(1424, 248);
            this.listView1.TabIndex = 8;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.View = System.Windows.Forms.View.Details;
            this.listView1.SelectedIndexChanged += new System.EventHandler(this.listView1_SelectedIndexChanged);
            // 
            // listid
            // 
            this.listid.Text = "id";
            this.listid.Width = 25;
            // 
            // type
            // 
            this.type.Text = "Type";
            this.type.Width = 40;
            // 
            // IP
            // 
            this.IP.Text = "IP";
            this.IP.Width = 98;
            // 
            // MASK
            // 
            this.MASK.Text = "MASK";
            this.MASK.Width = 98;
            // 
            // GW
            // 
            this.GW.Text = "GW";
            this.GW.Width = 98;
            // 
            // MAC
            // 
            this.MAC.Text = "MAC";
            this.MAC.Width = 102;
            // 
            // ServiceIP
            // 
            this.ServiceIP.Text = "ServiceIP";
            this.ServiceIP.Width = 111;
            // 
            // Port
            // 
            this.Port.Text = "Port";
            this.Port.Width = 41;
            // 
            // NetMode
            // 
            this.NetMode.Text = "NetMode";
            this.NetMode.Width = 50;
            // 
            // Machineid
            // 
            this.Machineid.Text = "Machineid";
            this.Machineid.Width = 68;
            // 
            // Reserved
            // 
            this.Reserved.Text = "Reserved";
            this.Reserved.Width = 50;
            // 
            // Username
            // 
            this.Username.Text = "DevType";
            // 
            // Password
            // 
            this.Password.Text = "SerialNum";
            this.Password.Width = 76;
            // 
            // DNS
            // 
            this.DNS.Text = "DNS";
            this.DNS.Width = 38;
            // 
            // URL
            // 
            this.URL.Text = "URL";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(558, 46);
            this.label30.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(71, 18);
            this.label30.TabIndex = 7;
            this.label30.Text = "DevIdx:";
            // 
            // but_disconnect
            // 
            this.but_disconnect.Location = new System.Drawing.Point(742, 39);
            this.but_disconnect.Margin = new System.Windows.Forms.Padding(4);
            this.but_disconnect.Name = "but_disconnect";
            this.but_disconnect.Size = new System.Drawing.Size(112, 34);
            this.but_disconnect.TabIndex = 6;
            this.but_disconnect.Text = "Disconnect";
            this.but_disconnect.UseVisualStyleBackColor = true;
            this.but_disconnect.Click += new System.EventHandler(this.but_disconnect_Click);
            // 
            // text_disconnect
            // 
            this.text_disconnect.Location = new System.Drawing.Point(638, 42);
            this.text_disconnect.Margin = new System.Windows.Forms.Padding(4);
            this.text_disconnect.Name = "text_disconnect";
            this.text_disconnect.Size = new System.Drawing.Size(64, 28);
            this.text_disconnect.TabIndex = 5;
            // 
            // Add_dev_port
            // 
            this.Add_dev_port.Location = new System.Drawing.Point(298, 42);
            this.Add_dev_port.Margin = new System.Windows.Forms.Padding(4);
            this.Add_dev_port.Name = "Add_dev_port";
            this.Add_dev_port.Size = new System.Drawing.Size(66, 28);
            this.Add_dev_port.TabIndex = 4;
            this.Add_dev_port.Text = "5010";
            this.Add_dev_port.TextChanged += new System.EventHandler(this.Add_dev_port_TextChanged);
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(237, 46);
            this.label29.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(53, 18);
            this.label29.TabIndex = 3;
            this.label29.Text = "Port:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(9, 50);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(35, 18);
            this.label12.TabIndex = 2;
            this.label12.Text = "IP:";
            this.label12.Click += new System.EventHandler(this.label12_Click);
            // 
            // Add_dev_Ip
            // 
            this.Add_dev_Ip.Location = new System.Drawing.Point(52, 42);
            this.Add_dev_Ip.Margin = new System.Windows.Forms.Padding(4);
            this.Add_dev_Ip.Name = "Add_dev_Ip";
            this.Add_dev_Ip.Size = new System.Drawing.Size(148, 28);
            this.Add_dev_Ip.TabIndex = 1;
            this.Add_dev_Ip.Text = "192.168.20.231";
            this.Add_dev_Ip.TextChanged += new System.EventHandler(this.Add_dev_Ip_TextChanged);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(411, 39);
            this.button6.Margin = new System.Windows.Forms.Padding(4);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(112, 34);
            this.button6.TabIndex = 0;
            this.button6.Text = "Connect";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.getspecial);
            this.tabPage3.Controls.Add(this.groupBox10);
            this.tabPage3.Controls.Add(this.groupBox9);
            this.tabPage3.Controls.Add(this.groupBox8);
            this.tabPage3.Controls.Add(this.forcedunlock);
            this.tabPage3.Controls.Add(this.groupBox7);
            this.tabPage3.Controls.Add(this.timepriodgroup);
            this.tabPage3.Controls.Add(this.init_system);
            this.tabPage3.Controls.Add(this.init_user_area);
            this.tabPage3.Location = new System.Drawing.Point(4, 28);
            this.tabPage3.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage3.Size = new System.Drawing.Size(1444, 501);
            this.tabPage3.TabIndex = 5;
            this.tabPage3.Text = "Test Page1";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // getspecial
            // 
            this.getspecial.Controls.Add(this.label105);
            this.getspecial.Controls.Add(this.label104);
            this.getspecial.Controls.Add(this.special_relay);
            this.getspecial.Controls.Add(this.label98);
            this.getspecial.Controls.Add(this.Special_07);
            this.getspecial.Controls.Add(this.label97);
            this.getspecial.Controls.Add(this.Special_06);
            this.getspecial.Controls.Add(this.label96);
            this.getspecial.Controls.Add(this.Special_05);
            this.getspecial.Controls.Add(this.label95);
            this.getspecial.Controls.Add(this.Special_01);
            this.getspecial.Controls.Add(this.button12);
            this.getspecial.Location = new System.Drawing.Point(726, 52);
            this.getspecial.Margin = new System.Windows.Forms.Padding(4);
            this.getspecial.Name = "getspecial";
            this.getspecial.Padding = new System.Windows.Forms.Padding(4);
            this.getspecial.Size = new System.Drawing.Size(324, 386);
            this.getspecial.TabIndex = 14;
            this.getspecial.TabStop = false;
            this.getspecial.Text = "Special Status";
            // 
            // label105
            // 
            this.label105.AutoSize = true;
            this.label105.Location = new System.Drawing.Point(9, 218);
            this.label105.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label105.Name = "label105";
            this.label105.Size = new System.Drawing.Size(179, 18);
            this.label105.TabIndex = 18;
            this.label105.Text = "\"Relay set status\" ";
            // 
            // label104
            // 
            this.label104.AutoSize = true;
            this.label104.Location = new System.Drawing.Point(9, 258);
            this.label104.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label104.Name = "label104";
            this.label104.Size = new System.Drawing.Size(161, 18);
            this.label104.TabIndex = 17;
            this.label104.Text = "relay set status:";
            // 
            // special_relay
            // 
            this.special_relay.Location = new System.Drawing.Point(200, 249);
            this.special_relay.Margin = new System.Windows.Forms.Padding(4);
            this.special_relay.Name = "special_relay";
            this.special_relay.Size = new System.Drawing.Size(38, 28);
            this.special_relay.TabIndex = 16;
            this.special_relay.Text = "0";
            // 
            // label98
            // 
            this.label98.AutoSize = true;
            this.label98.Location = new System.Drawing.Point(9, 172);
            this.label98.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label98.Name = "label98";
            this.label98.Size = new System.Drawing.Size(116, 18);
            this.label98.TabIndex = 15;
            this.label98.Text = "lock status:";
            // 
            // Special_07
            // 
            this.Special_07.Location = new System.Drawing.Point(200, 168);
            this.Special_07.Margin = new System.Windows.Forms.Padding(4);
            this.Special_07.Name = "Special_07";
            this.Special_07.Size = new System.Drawing.Size(38, 28);
            this.Special_07.TabIndex = 14;
            this.Special_07.Text = "0";
            // 
            // label97
            // 
            this.label97.AutoSize = true;
            this.label97.Location = new System.Drawing.Point(9, 132);
            this.label97.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label97.Name = "label97";
            this.label97.Size = new System.Drawing.Size(179, 18);
            this.label97.TabIndex = 13;
            this.label97.Text = "door sensor status:";
            // 
            // Special_06
            // 
            this.Special_06.Location = new System.Drawing.Point(200, 128);
            this.Special_06.Margin = new System.Windows.Forms.Padding(4);
            this.Special_06.Name = "Special_06";
            this.Special_06.Size = new System.Drawing.Size(38, 28);
            this.Special_06.TabIndex = 12;
            this.Special_06.Text = "0";
            // 
            // label96
            // 
            this.label96.AutoSize = true;
            this.label96.Location = new System.Drawing.Point(9, 90);
            this.label96.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label96.Name = "label96";
            this.label96.Size = new System.Drawing.Size(161, 18);
            this.label96.TabIndex = 11;
            this.label96.Text = "relay cur status:";
            // 
            // Special_05
            // 
            this.Special_05.Location = new System.Drawing.Point(200, 86);
            this.Special_05.Margin = new System.Windows.Forms.Padding(4);
            this.Special_05.Name = "Special_05";
            this.Special_05.Size = new System.Drawing.Size(38, 28);
            this.Special_05.TabIndex = 10;
            this.Special_05.Text = "0";
            // 
            // label95
            // 
            this.label95.AutoSize = true;
            this.label95.Location = new System.Drawing.Point(9, 48);
            this.label95.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label95.Name = "label95";
            this.label95.Size = new System.Drawing.Size(170, 18);
            this.label95.TabIndex = 9;
            this.label95.Text = "door alarm status:";
            // 
            // Special_01
            // 
            this.Special_01.Location = new System.Drawing.Point(200, 44);
            this.Special_01.Margin = new System.Windows.Forms.Padding(4);
            this.Special_01.Name = "Special_01";
            this.Special_01.Size = new System.Drawing.Size(38, 28);
            this.Special_01.TabIndex = 8;
            this.Special_01.Text = "0";
            // 
            // button12
            // 
            this.button12.Location = new System.Drawing.Point(12, 298);
            this.button12.Margin = new System.Windows.Forms.Padding(4);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(231, 34);
            this.button12.TabIndex = 7;
            this.button12.Text = "Get Special Status";
            this.button12.UseVisualStyleBackColor = true;
            this.button12.Click += new System.EventHandler(this.button12_Click_2);
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.closeallalarm);
            this.groupBox10.Controls.Add(this.button9);
            this.groupBox10.Controls.Add(this.label70);
            this.groupBox10.Controls.Add(this.label71);
            this.groupBox10.Controls.Add(this.devstatus_02);
            this.groupBox10.Controls.Add(this.devstatus_01);
            this.groupBox10.Location = new System.Drawing.Point(368, 240);
            this.groupBox10.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox10.Size = new System.Drawing.Size(300, 204);
            this.groupBox10.TabIndex = 9;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "SetDevStatus";
            // 
            // closeallalarm
            // 
            this.closeallalarm.Location = new System.Drawing.Point(33, 154);
            this.closeallalarm.Margin = new System.Windows.Forms.Padding(4);
            this.closeallalarm.Name = "closeallalarm";
            this.closeallalarm.Size = new System.Drawing.Size(207, 34);
            this.closeallalarm.TabIndex = 40;
            this.closeallalarm.Text = "Close All Alram";
            this.closeallalarm.UseVisualStyleBackColor = true;
            this.closeallalarm.Click += new System.EventHandler(this.closeallalarm_Click);
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(33, 111);
            this.button9.Margin = new System.Windows.Forms.Padding(4);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(207, 34);
            this.button9.TabIndex = 39;
            this.button9.Text = "Set Dev Status";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click_1);
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.Location = new System.Drawing.Point(18, 75);
            this.label70.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(161, 18);
            this.label70.TabIndex = 38;
            this.label70.Text = "relay set status:";
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.Location = new System.Drawing.Point(18, 34);
            this.label71.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(107, 18);
            this.label71.TabIndex = 37;
            this.label71.Text = "alarm stop:";
            // 
            // devstatus_02
            // 
            this.devstatus_02.Location = new System.Drawing.Point(188, 70);
            this.devstatus_02.Margin = new System.Windows.Forms.Padding(4);
            this.devstatus_02.Name = "devstatus_02";
            this.devstatus_02.Size = new System.Drawing.Size(66, 28);
            this.devstatus_02.TabIndex = 7;
            this.devstatus_02.Text = "0";
            // 
            // devstatus_01
            // 
            this.devstatus_01.Location = new System.Drawing.Point(188, 30);
            this.devstatus_01.Margin = new System.Windows.Forms.Padding(4);
            this.devstatus_01.Name = "devstatus_01";
            this.devstatus_01.Size = new System.Drawing.Size(66, 28);
            this.devstatus_01.TabIndex = 6;
            this.devstatus_01.Text = "0";
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.card_01);
            this.groupBox9.Controls.Add(this.btn_getcard);
            this.groupBox9.Location = new System.Drawing.Point(1098, 320);
            this.groupBox9.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox9.Size = new System.Drawing.Size(300, 116);
            this.groupBox9.TabIndex = 8;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "Get card Id";
            // 
            // card_01
            // 
            this.card_01.Location = new System.Drawing.Point(33, 30);
            this.card_01.Margin = new System.Windows.Forms.Padding(4);
            this.card_01.Name = "card_01";
            this.card_01.Size = new System.Drawing.Size(236, 28);
            this.card_01.TabIndex = 8;
            this.card_01.Text = "0";
            // 
            // btn_getcard
            // 
            this.btn_getcard.Location = new System.Drawing.Point(32, 70);
            this.btn_getcard.Margin = new System.Windows.Forms.Padding(4);
            this.btn_getcard.Name = "btn_getcard";
            this.btn_getcard.Size = new System.Drawing.Size(243, 34);
            this.btn_getcard.TabIndex = 7;
            this.btn_getcard.Text = "Get Card Id";
            this.btn_getcard.UseVisualStyleBackColor = true;
            this.btn_getcard.Click += new System.EventHandler(this.btn_getcard_Click);
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.open_u);
            this.groupBox8.Controls.Add(this.close_u);
            this.groupBox8.Controls.Add(this.btn_setconfig5);
            this.groupBox8.Controls.Add(this.btn_getconfig5);
            this.groupBox8.Controls.Add(this.label69);
            this.groupBox8.Controls.Add(this.label68);
            this.groupBox8.Controls.Add(this.config5_02);
            this.groupBox8.Controls.Add(this.config5_01);
            this.groupBox8.Location = new System.Drawing.Point(1098, 52);
            this.groupBox8.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox8.Size = new System.Drawing.Size(300, 240);
            this.groupBox8.TabIndex = 6;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = " BasiConfig5";
            // 
            // open_u
            // 
            this.open_u.Location = new System.Drawing.Point(32, 144);
            this.open_u.Margin = new System.Windows.Forms.Padding(4);
            this.open_u.Name = "open_u";
            this.open_u.Size = new System.Drawing.Size(240, 34);
            this.open_u.TabIndex = 48;
            this.open_u.Text = "OpenUnauthorizedRecord";
            this.open_u.UseVisualStyleBackColor = true;
            this.open_u.Click += new System.EventHandler(this.button12_Click);
            // 
            // close_u
            // 
            this.close_u.Location = new System.Drawing.Point(32, 184);
            this.close_u.Margin = new System.Windows.Forms.Padding(4);
            this.close_u.Name = "close_u";
            this.close_u.Size = new System.Drawing.Size(240, 34);
            this.close_u.TabIndex = 47;
            this.close_u.Text = "CloseUnauthorizedRecord";
            this.close_u.UseVisualStyleBackColor = true;
            this.close_u.Click += new System.EventHandler(this.button11_Click);
            // 
            // btn_setconfig5
            // 
            this.btn_setconfig5.Location = new System.Drawing.Point(153, 106);
            this.btn_setconfig5.Margin = new System.Windows.Forms.Padding(4);
            this.btn_setconfig5.Name = "btn_setconfig5";
            this.btn_setconfig5.Size = new System.Drawing.Size(118, 34);
            this.btn_setconfig5.TabIndex = 46;
            this.btn_setconfig5.Text = "SetConfig5";
            this.btn_setconfig5.UseVisualStyleBackColor = true;
            this.btn_setconfig5.Click += new System.EventHandler(this.button10_Click);
            // 
            // btn_getconfig5
            // 
            this.btn_getconfig5.Location = new System.Drawing.Point(32, 106);
            this.btn_getconfig5.Margin = new System.Windows.Forms.Padding(4);
            this.btn_getconfig5.Name = "btn_getconfig5";
            this.btn_getconfig5.Size = new System.Drawing.Size(112, 34);
            this.btn_getconfig5.TabIndex = 45;
            this.btn_getconfig5.Text = "GetConfig5";
            this.btn_getconfig5.UseVisualStyleBackColor = true;
            this.btn_getconfig5.Click += new System.EventHandler(this.button9_Click);
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.Location = new System.Drawing.Point(30, 75);
            this.label69.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(125, 18);
            this.label69.TabIndex = 38;
            this.label69.Text = "tamper alarm:";
            this.label69.Click += new System.EventHandler(this.label69_Click);
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Location = new System.Drawing.Point(30, 34);
            this.label68.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(107, 18);
            this.label68.TabIndex = 37;
            this.label68.Text = "fail alarm:";
            // 
            // config5_02
            // 
            this.config5_02.Location = new System.Drawing.Point(172, 70);
            this.config5_02.Margin = new System.Windows.Forms.Padding(4);
            this.config5_02.Name = "config5_02";
            this.config5_02.Size = new System.Drawing.Size(66, 28);
            this.config5_02.TabIndex = 7;
            this.config5_02.Text = "0";
            // 
            // config5_01
            // 
            this.config5_01.Location = new System.Drawing.Point(172, 30);
            this.config5_01.Margin = new System.Windows.Forms.Padding(4);
            this.config5_01.Name = "config5_01";
            this.config5_01.Size = new System.Drawing.Size(66, 28);
            this.config5_01.TabIndex = 6;
            this.config5_01.Text = "0";
            // 
            // forcedunlock
            // 
            this.forcedunlock.Location = new System.Drawing.Point(386, 9);
            this.forcedunlock.Margin = new System.Windows.Forms.Padding(4);
            this.forcedunlock.Name = "forcedunlock";
            this.forcedunlock.Size = new System.Drawing.Size(160, 34);
            this.forcedunlock.TabIndex = 5;
            this.forcedunlock.Text = "Forced Unlock";
            this.forcedunlock.UseVisualStyleBackColor = true;
            this.forcedunlock.Click += new System.EventHandler(this.forcedunlock_Click);
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.setteam);
            this.groupBox7.Controls.Add(this.getteam);
            this.groupBox7.Controls.Add(this.teamid);
            this.groupBox7.Controls.Add(this.label52);
            this.groupBox7.Controls.Add(this.select_04);
            this.groupBox7.Controls.Add(this.select_01);
            this.groupBox7.Controls.Add(this.select_02);
            this.groupBox7.Controls.Add(this.select_03);
            this.groupBox7.Controls.Add(this.label51);
            this.groupBox7.Location = new System.Drawing.Point(368, 52);
            this.groupBox7.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox7.Size = new System.Drawing.Size(300, 178);
            this.groupBox7.TabIndex = 4;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "TeamInfo";
            // 
            // setteam
            // 
            this.setteam.Location = new System.Drawing.Point(154, 134);
            this.setteam.Margin = new System.Windows.Forms.Padding(4);
            this.setteam.Name = "setteam";
            this.setteam.Size = new System.Drawing.Size(100, 34);
            this.setteam.TabIndex = 45;
            this.setteam.Text = "SetTeam";
            this.setteam.UseVisualStyleBackColor = true;
            this.setteam.Click += new System.EventHandler(this.setteam_Click);
            // 
            // getteam
            // 
            this.getteam.Location = new System.Drawing.Point(28, 135);
            this.getteam.Margin = new System.Windows.Forms.Padding(4);
            this.getteam.Name = "getteam";
            this.getteam.Size = new System.Drawing.Size(100, 34);
            this.getteam.TabIndex = 44;
            this.getteam.Text = "GetTeam";
            this.getteam.UseVisualStyleBackColor = true;
            this.getteam.Click += new System.EventHandler(this.getteam_Click);
            // 
            // teamid
            // 
            this.teamid.Location = new System.Drawing.Point(154, 93);
            this.teamid.Margin = new System.Windows.Forms.Padding(4);
            this.teamid.Name = "teamid";
            this.teamid.Size = new System.Drawing.Size(34, 28);
            this.teamid.TabIndex = 43;
            this.teamid.Text = "2";
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Location = new System.Drawing.Point(26, 98);
            this.label52.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(134, 18);
            this.label52.TabIndex = 42;
            this.label52.Text = "Team Id(2-16):";
            // 
            // select_04
            // 
            this.select_04.Location = new System.Drawing.Point(219, 48);
            this.select_04.Margin = new System.Windows.Forms.Padding(4);
            this.select_04.Name = "select_04";
            this.select_04.Size = new System.Drawing.Size(34, 28);
            this.select_04.TabIndex = 41;
            // 
            // select_01
            // 
            this.select_01.Location = new System.Drawing.Point(28, 48);
            this.select_01.Margin = new System.Windows.Forms.Padding(4);
            this.select_01.Name = "select_01";
            this.select_01.Size = new System.Drawing.Size(34, 28);
            this.select_01.TabIndex = 40;
            // 
            // select_02
            // 
            this.select_02.Location = new System.Drawing.Point(93, 48);
            this.select_02.Margin = new System.Windows.Forms.Padding(4);
            this.select_02.Name = "select_02";
            this.select_02.Size = new System.Drawing.Size(34, 28);
            this.select_02.TabIndex = 39;
            // 
            // select_03
            // 
            this.select_03.Location = new System.Drawing.Point(154, 48);
            this.select_03.Margin = new System.Windows.Forms.Padding(4);
            this.select_03.Name = "select_03";
            this.select_03.Size = new System.Drawing.Size(34, 28);
            this.select_03.TabIndex = 38;
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Location = new System.Drawing.Point(26, 26);
            this.label51.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(233, 18);
            this.label51.TabIndex = 37;
            this.label51.Text = "Period time Select(0-32):";
            // 
            // timepriodgroup
            // 
            this.timepriodgroup.Controls.Add(this.label48);
            this.timepriodgroup.Controls.Add(this.label47);
            this.timepriodgroup.Controls.Add(this.label46);
            this.timepriodgroup.Controls.Add(this.label44);
            this.timepriodgroup.Controls.Add(this.label43);
            this.timepriodgroup.Controls.Add(this.set_period_time);
            this.timepriodgroup.Controls.Add(this.get_period_time);
            this.timepriodgroup.Controls.Add(this.time_p74);
            this.timepriodgroup.Controls.Add(this.time_p73);
            this.timepriodgroup.Controls.Add(this.time_p72);
            this.timepriodgroup.Controls.Add(this.time_p71);
            this.timepriodgroup.Controls.Add(this.time_p64);
            this.timepriodgroup.Controls.Add(this.time_p63);
            this.timepriodgroup.Controls.Add(this.time_p62);
            this.timepriodgroup.Controls.Add(this.time_p61);
            this.timepriodgroup.Controls.Add(this.time_p54);
            this.timepriodgroup.Controls.Add(this.time_p53);
            this.timepriodgroup.Controls.Add(this.time_p52);
            this.timepriodgroup.Controls.Add(this.time_p51);
            this.timepriodgroup.Controls.Add(this.time_p44);
            this.timepriodgroup.Controls.Add(this.time_p43);
            this.timepriodgroup.Controls.Add(this.time_p42);
            this.timepriodgroup.Controls.Add(this.time_p41);
            this.timepriodgroup.Controls.Add(this.time_p34);
            this.timepriodgroup.Controls.Add(this.time_p33);
            this.timepriodgroup.Controls.Add(this.time_p32);
            this.timepriodgroup.Controls.Add(this.time_p31);
            this.timepriodgroup.Controls.Add(this.time_p24);
            this.timepriodgroup.Controls.Add(this.time_p23);
            this.timepriodgroup.Controls.Add(this.time_p22);
            this.timepriodgroup.Controls.Add(this.time_p21);
            this.timepriodgroup.Controls.Add(this.time_p14);
            this.timepriodgroup.Controls.Add(this.time_p13);
            this.timepriodgroup.Controls.Add(this.time_p12);
            this.timepriodgroup.Controls.Add(this.time_p11);
            this.timepriodgroup.Controls.Add(this.time_number);
            this.timepriodgroup.Location = new System.Drawing.Point(9, 52);
            this.timepriodgroup.Margin = new System.Windows.Forms.Padding(4);
            this.timepriodgroup.Name = "timepriodgroup";
            this.timepriodgroup.Padding = new System.Windows.Forms.Padding(4);
            this.timepriodgroup.Size = new System.Drawing.Size(300, 398);
            this.timepriodgroup.TabIndex = 3;
            this.timepriodgroup.TabStop = false;
            this.timepriodgroup.Text = "Period time";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(86, 70);
            this.label48.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(26, 18);
            this.label48.TabIndex = 41;
            this.label48.Text = "m:";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(232, 70);
            this.label47.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(26, 18);
            this.label47.TabIndex = 40;
            this.label47.Text = "m:";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(158, 70);
            this.label46.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(26, 18);
            this.label46.TabIndex = 39;
            this.label46.Text = "h:";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(0, 70);
            this.label44.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(26, 18);
            this.label44.TabIndex = 37;
            this.label44.Text = "h:";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(32, 26);
            this.label43.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(116, 18);
            this.label43.TabIndex = 36;
            this.label43.Text = "SerialNumbe:";
            // 
            // set_period_time
            // 
            this.set_period_time.Location = new System.Drawing.Point(165, 348);
            this.set_period_time.Margin = new System.Windows.Forms.Padding(4);
            this.set_period_time.Name = "set_period_time";
            this.set_period_time.Size = new System.Drawing.Size(135, 34);
            this.set_period_time.TabIndex = 35;
            this.set_period_time.Text = "SetPeriodTime";
            this.set_period_time.UseVisualStyleBackColor = true;
            this.set_period_time.Click += new System.EventHandler(this.set_period_time_Click);
            // 
            // get_period_time
            // 
            this.get_period_time.Location = new System.Drawing.Point(0, 348);
            this.get_period_time.Margin = new System.Windows.Forms.Padding(4);
            this.get_period_time.Name = "get_period_time";
            this.get_period_time.Size = new System.Drawing.Size(134, 34);
            this.get_period_time.TabIndex = 34;
            this.get_period_time.Text = "GetPeriodTime";
            this.get_period_time.UseVisualStyleBackColor = true;
            this.get_period_time.Click += new System.EventHandler(this.get_period_time_Click);
            // 
            // time_p74
            // 
            this.time_p74.Location = new System.Drawing.Point(258, 309);
            this.time_p74.Margin = new System.Windows.Forms.Padding(4);
            this.time_p74.Name = "time_p74";
            this.time_p74.Size = new System.Drawing.Size(34, 28);
            this.time_p74.TabIndex = 33;
            // 
            // time_p73
            // 
            this.time_p73.Location = new System.Drawing.Point(188, 309);
            this.time_p73.Margin = new System.Windows.Forms.Padding(4);
            this.time_p73.Name = "time_p73";
            this.time_p73.Size = new System.Drawing.Size(34, 28);
            this.time_p73.TabIndex = 32;
            // 
            // time_p72
            // 
            this.time_p72.Location = new System.Drawing.Point(120, 309);
            this.time_p72.Margin = new System.Windows.Forms.Padding(4);
            this.time_p72.Name = "time_p72";
            this.time_p72.Size = new System.Drawing.Size(34, 28);
            this.time_p72.TabIndex = 31;
            // 
            // time_p71
            // 
            this.time_p71.Location = new System.Drawing.Point(34, 309);
            this.time_p71.Margin = new System.Windows.Forms.Padding(4);
            this.time_p71.Name = "time_p71";
            this.time_p71.Size = new System.Drawing.Size(34, 28);
            this.time_p71.TabIndex = 30;
            // 
            // time_p64
            // 
            this.time_p64.Location = new System.Drawing.Point(258, 268);
            this.time_p64.Margin = new System.Windows.Forms.Padding(4);
            this.time_p64.Name = "time_p64";
            this.time_p64.Size = new System.Drawing.Size(34, 28);
            this.time_p64.TabIndex = 29;
            // 
            // time_p63
            // 
            this.time_p63.Location = new System.Drawing.Point(188, 268);
            this.time_p63.Margin = new System.Windows.Forms.Padding(4);
            this.time_p63.Name = "time_p63";
            this.time_p63.Size = new System.Drawing.Size(34, 28);
            this.time_p63.TabIndex = 28;
            // 
            // time_p62
            // 
            this.time_p62.Location = new System.Drawing.Point(120, 268);
            this.time_p62.Margin = new System.Windows.Forms.Padding(4);
            this.time_p62.Name = "time_p62";
            this.time_p62.Size = new System.Drawing.Size(34, 28);
            this.time_p62.TabIndex = 27;
            // 
            // time_p61
            // 
            this.time_p61.Location = new System.Drawing.Point(34, 268);
            this.time_p61.Margin = new System.Windows.Forms.Padding(4);
            this.time_p61.Name = "time_p61";
            this.time_p61.Size = new System.Drawing.Size(34, 28);
            this.time_p61.TabIndex = 26;
            // 
            // time_p54
            // 
            this.time_p54.Location = new System.Drawing.Point(258, 228);
            this.time_p54.Margin = new System.Windows.Forms.Padding(4);
            this.time_p54.Name = "time_p54";
            this.time_p54.Size = new System.Drawing.Size(34, 28);
            this.time_p54.TabIndex = 25;
            // 
            // time_p53
            // 
            this.time_p53.Location = new System.Drawing.Point(188, 228);
            this.time_p53.Margin = new System.Windows.Forms.Padding(4);
            this.time_p53.Name = "time_p53";
            this.time_p53.Size = new System.Drawing.Size(34, 28);
            this.time_p53.TabIndex = 24;
            // 
            // time_p52
            // 
            this.time_p52.Location = new System.Drawing.Point(120, 228);
            this.time_p52.Margin = new System.Windows.Forms.Padding(4);
            this.time_p52.Name = "time_p52";
            this.time_p52.Size = new System.Drawing.Size(34, 28);
            this.time_p52.TabIndex = 23;
            // 
            // time_p51
            // 
            this.time_p51.Location = new System.Drawing.Point(34, 228);
            this.time_p51.Margin = new System.Windows.Forms.Padding(4);
            this.time_p51.Name = "time_p51";
            this.time_p51.Size = new System.Drawing.Size(34, 28);
            this.time_p51.TabIndex = 22;
            // 
            // time_p44
            // 
            this.time_p44.Location = new System.Drawing.Point(258, 188);
            this.time_p44.Margin = new System.Windows.Forms.Padding(4);
            this.time_p44.Name = "time_p44";
            this.time_p44.Size = new System.Drawing.Size(34, 28);
            this.time_p44.TabIndex = 21;
            // 
            // time_p43
            // 
            this.time_p43.Location = new System.Drawing.Point(188, 188);
            this.time_p43.Margin = new System.Windows.Forms.Padding(4);
            this.time_p43.Name = "time_p43";
            this.time_p43.Size = new System.Drawing.Size(34, 28);
            this.time_p43.TabIndex = 20;
            // 
            // time_p42
            // 
            this.time_p42.Location = new System.Drawing.Point(120, 188);
            this.time_p42.Margin = new System.Windows.Forms.Padding(4);
            this.time_p42.Name = "time_p42";
            this.time_p42.Size = new System.Drawing.Size(34, 28);
            this.time_p42.TabIndex = 19;
            // 
            // time_p41
            // 
            this.time_p41.Location = new System.Drawing.Point(34, 188);
            this.time_p41.Margin = new System.Windows.Forms.Padding(4);
            this.time_p41.Name = "time_p41";
            this.time_p41.Size = new System.Drawing.Size(34, 28);
            this.time_p41.TabIndex = 18;
            // 
            // time_p34
            // 
            this.time_p34.Location = new System.Drawing.Point(258, 147);
            this.time_p34.Margin = new System.Windows.Forms.Padding(4);
            this.time_p34.Name = "time_p34";
            this.time_p34.Size = new System.Drawing.Size(34, 28);
            this.time_p34.TabIndex = 17;
            // 
            // time_p33
            // 
            this.time_p33.Location = new System.Drawing.Point(188, 147);
            this.time_p33.Margin = new System.Windows.Forms.Padding(4);
            this.time_p33.Name = "time_p33";
            this.time_p33.Size = new System.Drawing.Size(34, 28);
            this.time_p33.TabIndex = 16;
            // 
            // time_p32
            // 
            this.time_p32.Location = new System.Drawing.Point(120, 147);
            this.time_p32.Margin = new System.Windows.Forms.Padding(4);
            this.time_p32.Name = "time_p32";
            this.time_p32.Size = new System.Drawing.Size(34, 28);
            this.time_p32.TabIndex = 15;
            // 
            // time_p31
            // 
            this.time_p31.Location = new System.Drawing.Point(34, 147);
            this.time_p31.Margin = new System.Windows.Forms.Padding(4);
            this.time_p31.Name = "time_p31";
            this.time_p31.Size = new System.Drawing.Size(34, 28);
            this.time_p31.TabIndex = 14;
            // 
            // time_p24
            // 
            this.time_p24.Location = new System.Drawing.Point(258, 106);
            this.time_p24.Margin = new System.Windows.Forms.Padding(4);
            this.time_p24.Name = "time_p24";
            this.time_p24.Size = new System.Drawing.Size(34, 28);
            this.time_p24.TabIndex = 13;
            // 
            // time_p23
            // 
            this.time_p23.Location = new System.Drawing.Point(188, 106);
            this.time_p23.Margin = new System.Windows.Forms.Padding(4);
            this.time_p23.Name = "time_p23";
            this.time_p23.Size = new System.Drawing.Size(34, 28);
            this.time_p23.TabIndex = 12;
            // 
            // time_p22
            // 
            this.time_p22.Location = new System.Drawing.Point(120, 106);
            this.time_p22.Margin = new System.Windows.Forms.Padding(4);
            this.time_p22.Name = "time_p22";
            this.time_p22.Size = new System.Drawing.Size(34, 28);
            this.time_p22.TabIndex = 11;
            // 
            // time_p21
            // 
            this.time_p21.Location = new System.Drawing.Point(34, 106);
            this.time_p21.Margin = new System.Windows.Forms.Padding(4);
            this.time_p21.Name = "time_p21";
            this.time_p21.Size = new System.Drawing.Size(34, 28);
            this.time_p21.TabIndex = 10;
            // 
            // time_p14
            // 
            this.time_p14.Location = new System.Drawing.Point(258, 66);
            this.time_p14.Margin = new System.Windows.Forms.Padding(4);
            this.time_p14.Name = "time_p14";
            this.time_p14.Size = new System.Drawing.Size(34, 28);
            this.time_p14.TabIndex = 9;
            // 
            // time_p13
            // 
            this.time_p13.Location = new System.Drawing.Point(188, 66);
            this.time_p13.Margin = new System.Windows.Forms.Padding(4);
            this.time_p13.Name = "time_p13";
            this.time_p13.Size = new System.Drawing.Size(34, 28);
            this.time_p13.TabIndex = 8;
            // 
            // time_p12
            // 
            this.time_p12.Location = new System.Drawing.Point(120, 66);
            this.time_p12.Margin = new System.Windows.Forms.Padding(4);
            this.time_p12.Name = "time_p12";
            this.time_p12.Size = new System.Drawing.Size(34, 28);
            this.time_p12.TabIndex = 7;
            // 
            // time_p11
            // 
            this.time_p11.Location = new System.Drawing.Point(34, 66);
            this.time_p11.Margin = new System.Windows.Forms.Padding(4);
            this.time_p11.Name = "time_p11";
            this.time_p11.Size = new System.Drawing.Size(34, 28);
            this.time_p11.TabIndex = 6;
            // 
            // time_number
            // 
            this.time_number.Location = new System.Drawing.Point(165, 21);
            this.time_number.Margin = new System.Windows.Forms.Padding(4);
            this.time_number.Name = "time_number";
            this.time_number.Size = new System.Drawing.Size(66, 28);
            this.time_number.TabIndex = 5;
            this.time_number.Text = "1";
            // 
            // init_system
            // 
            this.init_system.Location = new System.Drawing.Point(196, 9);
            this.init_system.Margin = new System.Windows.Forms.Padding(4);
            this.init_system.Name = "init_system";
            this.init_system.Size = new System.Drawing.Size(160, 34);
            this.init_system.TabIndex = 2;
            this.init_system.Text = "Init System";
            this.init_system.UseVisualStyleBackColor = true;
            this.init_system.Click += new System.EventHandler(this.init_system_Click);
            // 
            // init_user_area
            // 
            this.init_user_area.Location = new System.Drawing.Point(9, 9);
            this.init_user_area.Margin = new System.Windows.Forms.Padding(4);
            this.init_user_area.Name = "init_user_area";
            this.init_user_area.Size = new System.Drawing.Size(160, 34);
            this.init_user_area.TabIndex = 1;
            this.init_user_area.Text = "Init User Area";
            this.init_user_area.UseVisualStyleBackColor = true;
            this.init_user_area.Click += new System.EventHandler(this.inituserarea_Click);
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.groupBox16);
            this.tabPage6.Controls.Add(this.groupBox14);
            this.tabPage6.Controls.Add(this.groupBox13);
            this.tabPage6.Controls.Add(this.groupBox12);
            this.tabPage6.Controls.Add(this.config3);
            this.tabPage6.Location = new System.Drawing.Point(4, 28);
            this.tabPage6.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage6.Size = new System.Drawing.Size(1444, 501);
            this.tabPage6.TabIndex = 6;
            this.tabPage6.Text = "tabPage6";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // groupBox16
            // 
            this.groupBox16.Controls.Add(this.label93);
            this.groupBox16.Controls.Add(this.label92);
            this.groupBox16.Controls.Add(this.label91);
            this.groupBox16.Controls.Add(this.button11);
            this.groupBox16.Controls.Add(this.sdk_03);
            this.groupBox16.Controls.Add(this.sdk_01);
            this.groupBox16.Controls.Add(this.sdk_02);
            this.groupBox16.Location = new System.Drawing.Point(1074, 9);
            this.groupBox16.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox16.Name = "groupBox16";
            this.groupBox16.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox16.Size = new System.Drawing.Size(357, 196);
            this.groupBox16.TabIndex = 8;
            this.groupBox16.TabStop = false;
            this.groupBox16.Text = "Set SDK config";
            // 
            // label93
            // 
            this.label93.AutoSize = true;
            this.label93.Location = new System.Drawing.Point(24, 111);
            this.label93.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label93.Name = "label93";
            this.label93.Size = new System.Drawing.Size(107, 18);
            this.label93.TabIndex = 48;
            this.label93.Text = "SetLogFile:";
            // 
            // label92
            // 
            this.label92.AutoSize = true;
            this.label92.Location = new System.Drawing.Point(24, 70);
            this.label92.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label92.Name = "label92";
            this.label92.Size = new System.Drawing.Size(134, 18);
            this.label92.TabIndex = 47;
            this.label92.Text = "SetRecordflag:";
            this.label92.Click += new System.EventHandler(this.label92_Click);
            // 
            // label91
            // 
            this.label91.AutoSize = true;
            this.label91.Location = new System.Drawing.Point(24, 30);
            this.label91.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label91.Name = "label91";
            this.label91.Size = new System.Drawing.Size(206, 18);
            this.label91.TabIndex = 46;
            this.label91.Text = "SetAutoDownloadRecord:";
            // 
            // button11
            // 
            this.button11.Location = new System.Drawing.Point(27, 147);
            this.button11.Margin = new System.Windows.Forms.Padding(4);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(279, 45);
            this.button11.TabIndex = 45;
            this.button11.Text = "Set SDK Config";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.button11_Click_1);
            // 
            // sdk_03
            // 
            this.sdk_03.Location = new System.Drawing.Point(238, 106);
            this.sdk_03.Margin = new System.Windows.Forms.Padding(4);
            this.sdk_03.Name = "sdk_03";
            this.sdk_03.Size = new System.Drawing.Size(66, 28);
            this.sdk_03.TabIndex = 8;
            this.sdk_03.Text = "0";
            // 
            // sdk_01
            // 
            this.sdk_01.Location = new System.Drawing.Point(238, 26);
            this.sdk_01.Margin = new System.Windows.Forms.Padding(4);
            this.sdk_01.Name = "sdk_01";
            this.sdk_01.Size = new System.Drawing.Size(66, 28);
            this.sdk_01.TabIndex = 7;
            this.sdk_01.Text = "1";
            // 
            // sdk_02
            // 
            this.sdk_02.Location = new System.Drawing.Point(238, 66);
            this.sdk_02.Margin = new System.Windows.Forms.Padding(4);
            this.sdk_02.Name = "sdk_02";
            this.sdk_02.Size = new System.Drawing.Size(66, 28);
            this.sdk_02.TabIndex = 6;
            this.sdk_02.Text = "1";
            // 
            // groupBox14
            // 
            this.groupBox14.Controls.Add(this.baifenbi);
            this.groupBox14.Controls.Add(this.update_status);
            this.groupBox14.Controls.Add(this.update_file);
            this.groupBox14.Location = new System.Drawing.Point(770, 9);
            this.groupBox14.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox14.Name = "groupBox14";
            this.groupBox14.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox14.Size = new System.Drawing.Size(296, 196);
            this.groupBox14.TabIndex = 6;
            this.groupBox14.TabStop = false;
            this.groupBox14.Text = "groupBox14";
            // 
            // baifenbi
            // 
            this.baifenbi.Location = new System.Drawing.Point(40, 26);
            this.baifenbi.Margin = new System.Windows.Forms.Padding(4);
            this.baifenbi.Name = "baifenbi";
            this.baifenbi.Size = new System.Drawing.Size(212, 28);
            this.baifenbi.TabIndex = 46;
            this.baifenbi.Text = "0/100";
            // 
            // update_status
            // 
            this.update_status.Location = new System.Drawing.Point(40, 134);
            this.update_status.Margin = new System.Windows.Forms.Padding(4);
            this.update_status.Name = "update_status";
            this.update_status.Size = new System.Drawing.Size(214, 45);
            this.update_status.TabIndex = 45;
            this.update_status.Text = "UpdateStatus";
            this.update_status.UseVisualStyleBackColor = true;
            this.update_status.Click += new System.EventHandler(this.button15_Click);
            // 
            // update_file
            // 
            this.update_file.Location = new System.Drawing.Point(40, 70);
            this.update_file.Margin = new System.Windows.Forms.Padding(4);
            this.update_file.Name = "update_file";
            this.update_file.Size = new System.Drawing.Size(214, 45);
            this.update_file.TabIndex = 44;
            this.update_file.Text = "UpdateFile";
            this.update_file.UseVisualStyleBackColor = true;
            this.update_file.Click += new System.EventHandler(this.button14_Click);
            // 
            // groupBox13
            // 
            this.groupBox13.Controls.Add(this.tgj_040);
            this.groupBox13.Controls.Add(this.tgj_039);
            this.groupBox13.Controls.Add(this.tgj_038);
            this.groupBox13.Controls.Add(this.tgj_037);
            this.groupBox13.Controls.Add(this.tgj_036);
            this.groupBox13.Controls.Add(this.tgj_035);
            this.groupBox13.Controls.Add(this.tgj_030);
            this.groupBox13.Controls.Add(this.tgj_025);
            this.groupBox13.Controls.Add(this.tgj_020);
            this.groupBox13.Controls.Add(this.tgj_015);
            this.groupBox13.Controls.Add(this.tgj_010);
            this.groupBox13.Controls.Add(this.tgj_005);
            this.groupBox13.Controls.Add(this.label77);
            this.groupBox13.Controls.Add(this.label78);
            this.groupBox13.Controls.Add(this.label79);
            this.groupBox13.Controls.Add(this.label80);
            this.groupBox13.Controls.Add(this.label81);
            this.groupBox13.Controls.Add(this.setstatus02);
            this.groupBox13.Controls.Add(this.getstatus02);
            this.groupBox13.Controls.Add(this.tgj_034);
            this.groupBox13.Controls.Add(this.tgj_033);
            this.groupBox13.Controls.Add(this.tgj_032);
            this.groupBox13.Controls.Add(this.tgj_031);
            this.groupBox13.Controls.Add(this.tgj_029);
            this.groupBox13.Controls.Add(this.tgj_028);
            this.groupBox13.Controls.Add(this.tgj_027);
            this.groupBox13.Controls.Add(this.tgj_026);
            this.groupBox13.Controls.Add(this.tgj_024);
            this.groupBox13.Controls.Add(this.tgj_023);
            this.groupBox13.Controls.Add(this.tgj_022);
            this.groupBox13.Controls.Add(this.tgj_021);
            this.groupBox13.Controls.Add(this.tgj_019);
            this.groupBox13.Controls.Add(this.tgj_018);
            this.groupBox13.Controls.Add(this.tgj_017);
            this.groupBox13.Controls.Add(this.tgj_016);
            this.groupBox13.Controls.Add(this.tgj_014);
            this.groupBox13.Controls.Add(this.tgj_013);
            this.groupBox13.Controls.Add(this.tgj_012);
            this.groupBox13.Controls.Add(this.tgj_011);
            this.groupBox13.Controls.Add(this.tgj_009);
            this.groupBox13.Controls.Add(this.tgj_008);
            this.groupBox13.Controls.Add(this.tgj_007);
            this.groupBox13.Controls.Add(this.tgj_006);
            this.groupBox13.Controls.Add(this.tgj_004);
            this.groupBox13.Controls.Add(this.tgj_003);
            this.groupBox13.Controls.Add(this.tgj_002);
            this.groupBox13.Controls.Add(this.tgj_001);
            this.groupBox13.Controls.Add(this.flagweek_01);
            this.groupBox13.Location = new System.Drawing.Point(345, 9);
            this.groupBox13.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox13.Size = new System.Drawing.Size(399, 441);
            this.groupBox13.TabIndex = 5;
            this.groupBox13.TabStop = false;
            this.groupBox13.Text = "Period time";
            // 
            // tgj_040
            // 
            this.tgj_040.Location = new System.Drawing.Point(326, 351);
            this.tgj_040.Margin = new System.Windows.Forms.Padding(4);
            this.tgj_040.Name = "tgj_040";
            this.tgj_040.Size = new System.Drawing.Size(34, 28);
            this.tgj_040.TabIndex = 53;
            // 
            // tgj_039
            // 
            this.tgj_039.Location = new System.Drawing.Point(258, 351);
            this.tgj_039.Margin = new System.Windows.Forms.Padding(4);
            this.tgj_039.Name = "tgj_039";
            this.tgj_039.Size = new System.Drawing.Size(34, 28);
            this.tgj_039.TabIndex = 52;
            // 
            // tgj_038
            // 
            this.tgj_038.Location = new System.Drawing.Point(188, 351);
            this.tgj_038.Margin = new System.Windows.Forms.Padding(4);
            this.tgj_038.Name = "tgj_038";
            this.tgj_038.Size = new System.Drawing.Size(34, 28);
            this.tgj_038.TabIndex = 51;
            // 
            // tgj_037
            // 
            this.tgj_037.Location = new System.Drawing.Point(120, 351);
            this.tgj_037.Margin = new System.Windows.Forms.Padding(4);
            this.tgj_037.Name = "tgj_037";
            this.tgj_037.Size = new System.Drawing.Size(34, 28);
            this.tgj_037.TabIndex = 50;
            // 
            // tgj_036
            // 
            this.tgj_036.Location = new System.Drawing.Point(34, 351);
            this.tgj_036.Margin = new System.Windows.Forms.Padding(4);
            this.tgj_036.Name = "tgj_036";
            this.tgj_036.Size = new System.Drawing.Size(34, 28);
            this.tgj_036.TabIndex = 49;
            // 
            // tgj_035
            // 
            this.tgj_035.Location = new System.Drawing.Point(326, 309);
            this.tgj_035.Margin = new System.Windows.Forms.Padding(4);
            this.tgj_035.Name = "tgj_035";
            this.tgj_035.Size = new System.Drawing.Size(34, 28);
            this.tgj_035.TabIndex = 48;
            // 
            // tgj_030
            // 
            this.tgj_030.Location = new System.Drawing.Point(326, 268);
            this.tgj_030.Margin = new System.Windows.Forms.Padding(4);
            this.tgj_030.Name = "tgj_030";
            this.tgj_030.Size = new System.Drawing.Size(34, 28);
            this.tgj_030.TabIndex = 47;
            // 
            // tgj_025
            // 
            this.tgj_025.Location = new System.Drawing.Point(326, 228);
            this.tgj_025.Margin = new System.Windows.Forms.Padding(4);
            this.tgj_025.Name = "tgj_025";
            this.tgj_025.Size = new System.Drawing.Size(34, 28);
            this.tgj_025.TabIndex = 46;
            // 
            // tgj_020
            // 
            this.tgj_020.Location = new System.Drawing.Point(326, 188);
            this.tgj_020.Margin = new System.Windows.Forms.Padding(4);
            this.tgj_020.Name = "tgj_020";
            this.tgj_020.Size = new System.Drawing.Size(34, 28);
            this.tgj_020.TabIndex = 45;
            // 
            // tgj_015
            // 
            this.tgj_015.Location = new System.Drawing.Point(326, 147);
            this.tgj_015.Margin = new System.Windows.Forms.Padding(4);
            this.tgj_015.Name = "tgj_015";
            this.tgj_015.Size = new System.Drawing.Size(34, 28);
            this.tgj_015.TabIndex = 44;
            // 
            // tgj_010
            // 
            this.tgj_010.Location = new System.Drawing.Point(326, 106);
            this.tgj_010.Margin = new System.Windows.Forms.Padding(4);
            this.tgj_010.Name = "tgj_010";
            this.tgj_010.Size = new System.Drawing.Size(34, 28);
            this.tgj_010.TabIndex = 43;
            // 
            // tgj_005
            // 
            this.tgj_005.Location = new System.Drawing.Point(326, 66);
            this.tgj_005.Margin = new System.Windows.Forms.Padding(4);
            this.tgj_005.Name = "tgj_005";
            this.tgj_005.Size = new System.Drawing.Size(34, 28);
            this.tgj_005.TabIndex = 42;
            // 
            // label77
            // 
            this.label77.AutoSize = true;
            this.label77.Location = new System.Drawing.Point(86, 70);
            this.label77.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(26, 18);
            this.label77.TabIndex = 41;
            this.label77.Text = "m:";
            // 
            // label78
            // 
            this.label78.AutoSize = true;
            this.label78.Location = new System.Drawing.Point(232, 70);
            this.label78.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(26, 18);
            this.label78.TabIndex = 40;
            this.label78.Text = "m:";
            // 
            // label79
            // 
            this.label79.AutoSize = true;
            this.label79.Location = new System.Drawing.Point(158, 70);
            this.label79.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label79.Name = "label79";
            this.label79.Size = new System.Drawing.Size(26, 18);
            this.label79.TabIndex = 39;
            this.label79.Text = "h:";
            // 
            // label80
            // 
            this.label80.AutoSize = true;
            this.label80.Location = new System.Drawing.Point(0, 70);
            this.label80.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label80.Name = "label80";
            this.label80.Size = new System.Drawing.Size(26, 18);
            this.label80.TabIndex = 37;
            this.label80.Text = "h:";
            // 
            // label81
            // 
            this.label81.AutoSize = true;
            this.label81.Location = new System.Drawing.Point(32, 26);
            this.label81.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label81.Name = "label81";
            this.label81.Size = new System.Drawing.Size(89, 18);
            this.label81.TabIndex = 36;
            this.label81.Text = "FlagWeek:";
            // 
            // setstatus02
            // 
            this.setstatus02.Location = new System.Drawing.Point(226, 392);
            this.setstatus02.Margin = new System.Windows.Forms.Padding(4);
            this.setstatus02.Name = "setstatus02";
            this.setstatus02.Size = new System.Drawing.Size(135, 34);
            this.setstatus02.TabIndex = 35;
            this.setstatus02.Text = "SetStatus_C";
            this.setstatus02.UseVisualStyleBackColor = true;
            this.setstatus02.Click += new System.EventHandler(this.setstatus02_Click);
            // 
            // getstatus02
            // 
            this.getstatus02.Location = new System.Drawing.Point(34, 392);
            this.getstatus02.Margin = new System.Windows.Forms.Padding(4);
            this.getstatus02.Name = "getstatus02";
            this.getstatus02.Size = new System.Drawing.Size(134, 34);
            this.getstatus02.TabIndex = 34;
            this.getstatus02.Text = "GetStatus_C";
            this.getstatus02.UseVisualStyleBackColor = true;
            this.getstatus02.Click += new System.EventHandler(this.getstatus02_Click);
            // 
            // tgj_034
            // 
            this.tgj_034.Location = new System.Drawing.Point(258, 309);
            this.tgj_034.Margin = new System.Windows.Forms.Padding(4);
            this.tgj_034.Name = "tgj_034";
            this.tgj_034.Size = new System.Drawing.Size(34, 28);
            this.tgj_034.TabIndex = 33;
            // 
            // tgj_033
            // 
            this.tgj_033.Location = new System.Drawing.Point(188, 309);
            this.tgj_033.Margin = new System.Windows.Forms.Padding(4);
            this.tgj_033.Name = "tgj_033";
            this.tgj_033.Size = new System.Drawing.Size(34, 28);
            this.tgj_033.TabIndex = 32;
            // 
            // tgj_032
            // 
            this.tgj_032.Location = new System.Drawing.Point(120, 309);
            this.tgj_032.Margin = new System.Windows.Forms.Padding(4);
            this.tgj_032.Name = "tgj_032";
            this.tgj_032.Size = new System.Drawing.Size(34, 28);
            this.tgj_032.TabIndex = 31;
            // 
            // tgj_031
            // 
            this.tgj_031.Location = new System.Drawing.Point(34, 309);
            this.tgj_031.Margin = new System.Windows.Forms.Padding(4);
            this.tgj_031.Name = "tgj_031";
            this.tgj_031.Size = new System.Drawing.Size(34, 28);
            this.tgj_031.TabIndex = 30;
            // 
            // tgj_029
            // 
            this.tgj_029.Location = new System.Drawing.Point(258, 268);
            this.tgj_029.Margin = new System.Windows.Forms.Padding(4);
            this.tgj_029.Name = "tgj_029";
            this.tgj_029.Size = new System.Drawing.Size(34, 28);
            this.tgj_029.TabIndex = 29;
            // 
            // tgj_028
            // 
            this.tgj_028.Location = new System.Drawing.Point(188, 268);
            this.tgj_028.Margin = new System.Windows.Forms.Padding(4);
            this.tgj_028.Name = "tgj_028";
            this.tgj_028.Size = new System.Drawing.Size(34, 28);
            this.tgj_028.TabIndex = 28;
            // 
            // tgj_027
            // 
            this.tgj_027.Location = new System.Drawing.Point(120, 268);
            this.tgj_027.Margin = new System.Windows.Forms.Padding(4);
            this.tgj_027.Name = "tgj_027";
            this.tgj_027.Size = new System.Drawing.Size(34, 28);
            this.tgj_027.TabIndex = 27;
            // 
            // tgj_026
            // 
            this.tgj_026.Location = new System.Drawing.Point(34, 268);
            this.tgj_026.Margin = new System.Windows.Forms.Padding(4);
            this.tgj_026.Name = "tgj_026";
            this.tgj_026.Size = new System.Drawing.Size(34, 28);
            this.tgj_026.TabIndex = 26;
            // 
            // tgj_024
            // 
            this.tgj_024.Location = new System.Drawing.Point(258, 228);
            this.tgj_024.Margin = new System.Windows.Forms.Padding(4);
            this.tgj_024.Name = "tgj_024";
            this.tgj_024.Size = new System.Drawing.Size(34, 28);
            this.tgj_024.TabIndex = 25;
            // 
            // tgj_023
            // 
            this.tgj_023.Location = new System.Drawing.Point(188, 228);
            this.tgj_023.Margin = new System.Windows.Forms.Padding(4);
            this.tgj_023.Name = "tgj_023";
            this.tgj_023.Size = new System.Drawing.Size(34, 28);
            this.tgj_023.TabIndex = 24;
            // 
            // tgj_022
            // 
            this.tgj_022.Location = new System.Drawing.Point(120, 228);
            this.tgj_022.Margin = new System.Windows.Forms.Padding(4);
            this.tgj_022.Name = "tgj_022";
            this.tgj_022.Size = new System.Drawing.Size(34, 28);
            this.tgj_022.TabIndex = 23;
            // 
            // tgj_021
            // 
            this.tgj_021.Location = new System.Drawing.Point(34, 228);
            this.tgj_021.Margin = new System.Windows.Forms.Padding(4);
            this.tgj_021.Name = "tgj_021";
            this.tgj_021.Size = new System.Drawing.Size(34, 28);
            this.tgj_021.TabIndex = 22;
            // 
            // tgj_019
            // 
            this.tgj_019.Location = new System.Drawing.Point(258, 188);
            this.tgj_019.Margin = new System.Windows.Forms.Padding(4);
            this.tgj_019.Name = "tgj_019";
            this.tgj_019.Size = new System.Drawing.Size(34, 28);
            this.tgj_019.TabIndex = 21;
            // 
            // tgj_018
            // 
            this.tgj_018.Location = new System.Drawing.Point(188, 188);
            this.tgj_018.Margin = new System.Windows.Forms.Padding(4);
            this.tgj_018.Name = "tgj_018";
            this.tgj_018.Size = new System.Drawing.Size(34, 28);
            this.tgj_018.TabIndex = 20;
            // 
            // tgj_017
            // 
            this.tgj_017.Location = new System.Drawing.Point(120, 188);
            this.tgj_017.Margin = new System.Windows.Forms.Padding(4);
            this.tgj_017.Name = "tgj_017";
            this.tgj_017.Size = new System.Drawing.Size(34, 28);
            this.tgj_017.TabIndex = 19;
            // 
            // tgj_016
            // 
            this.tgj_016.Location = new System.Drawing.Point(34, 188);
            this.tgj_016.Margin = new System.Windows.Forms.Padding(4);
            this.tgj_016.Name = "tgj_016";
            this.tgj_016.Size = new System.Drawing.Size(34, 28);
            this.tgj_016.TabIndex = 18;
            // 
            // tgj_014
            // 
            this.tgj_014.Location = new System.Drawing.Point(258, 147);
            this.tgj_014.Margin = new System.Windows.Forms.Padding(4);
            this.tgj_014.Name = "tgj_014";
            this.tgj_014.Size = new System.Drawing.Size(34, 28);
            this.tgj_014.TabIndex = 17;
            // 
            // tgj_013
            // 
            this.tgj_013.Location = new System.Drawing.Point(188, 147);
            this.tgj_013.Margin = new System.Windows.Forms.Padding(4);
            this.tgj_013.Name = "tgj_013";
            this.tgj_013.Size = new System.Drawing.Size(34, 28);
            this.tgj_013.TabIndex = 16;
            // 
            // tgj_012
            // 
            this.tgj_012.Location = new System.Drawing.Point(120, 147);
            this.tgj_012.Margin = new System.Windows.Forms.Padding(4);
            this.tgj_012.Name = "tgj_012";
            this.tgj_012.Size = new System.Drawing.Size(34, 28);
            this.tgj_012.TabIndex = 15;
            // 
            // tgj_011
            // 
            this.tgj_011.Location = new System.Drawing.Point(34, 147);
            this.tgj_011.Margin = new System.Windows.Forms.Padding(4);
            this.tgj_011.Name = "tgj_011";
            this.tgj_011.Size = new System.Drawing.Size(34, 28);
            this.tgj_011.TabIndex = 14;
            // 
            // tgj_009
            // 
            this.tgj_009.Location = new System.Drawing.Point(258, 106);
            this.tgj_009.Margin = new System.Windows.Forms.Padding(4);
            this.tgj_009.Name = "tgj_009";
            this.tgj_009.Size = new System.Drawing.Size(34, 28);
            this.tgj_009.TabIndex = 13;
            // 
            // tgj_008
            // 
            this.tgj_008.Location = new System.Drawing.Point(188, 106);
            this.tgj_008.Margin = new System.Windows.Forms.Padding(4);
            this.tgj_008.Name = "tgj_008";
            this.tgj_008.Size = new System.Drawing.Size(34, 28);
            this.tgj_008.TabIndex = 12;
            // 
            // tgj_007
            // 
            this.tgj_007.Location = new System.Drawing.Point(120, 106);
            this.tgj_007.Margin = new System.Windows.Forms.Padding(4);
            this.tgj_007.Name = "tgj_007";
            this.tgj_007.Size = new System.Drawing.Size(34, 28);
            this.tgj_007.TabIndex = 11;
            // 
            // tgj_006
            // 
            this.tgj_006.Location = new System.Drawing.Point(34, 106);
            this.tgj_006.Margin = new System.Windows.Forms.Padding(4);
            this.tgj_006.Name = "tgj_006";
            this.tgj_006.Size = new System.Drawing.Size(34, 28);
            this.tgj_006.TabIndex = 10;
            // 
            // tgj_004
            // 
            this.tgj_004.Location = new System.Drawing.Point(258, 66);
            this.tgj_004.Margin = new System.Windows.Forms.Padding(4);
            this.tgj_004.Name = "tgj_004";
            this.tgj_004.Size = new System.Drawing.Size(34, 28);
            this.tgj_004.TabIndex = 9;
            // 
            // tgj_003
            // 
            this.tgj_003.Location = new System.Drawing.Point(188, 66);
            this.tgj_003.Margin = new System.Windows.Forms.Padding(4);
            this.tgj_003.Name = "tgj_003";
            this.tgj_003.Size = new System.Drawing.Size(34, 28);
            this.tgj_003.TabIndex = 8;
            // 
            // tgj_002
            // 
            this.tgj_002.Location = new System.Drawing.Point(120, 66);
            this.tgj_002.Margin = new System.Windows.Forms.Padding(4);
            this.tgj_002.Name = "tgj_002";
            this.tgj_002.Size = new System.Drawing.Size(34, 28);
            this.tgj_002.TabIndex = 7;
            // 
            // tgj_001
            // 
            this.tgj_001.Location = new System.Drawing.Point(34, 66);
            this.tgj_001.Margin = new System.Windows.Forms.Padding(4);
            this.tgj_001.Name = "tgj_001";
            this.tgj_001.Size = new System.Drawing.Size(34, 28);
            this.tgj_001.TabIndex = 6;
            // 
            // flagweek_01
            // 
            this.flagweek_01.Location = new System.Drawing.Point(129, 21);
            this.flagweek_01.Margin = new System.Windows.Forms.Padding(4);
            this.flagweek_01.Name = "flagweek_01";
            this.flagweek_01.Size = new System.Drawing.Size(163, 28);
            this.flagweek_01.TabIndex = 5;
            this.flagweek_01.Text = "0";
            // 
            // groupBox12
            // 
            this.groupBox12.Controls.Add(this.label82);
            this.groupBox12.Controls.Add(this.status00);
            this.groupBox12.Controls.Add(this.label72);
            this.groupBox12.Controls.Add(this.label73);
            this.groupBox12.Controls.Add(this.label74);
            this.groupBox12.Controls.Add(this.label75);
            this.groupBox12.Controls.Add(this.label76);
            this.groupBox12.Controls.Add(this.setstatus01);
            this.groupBox12.Controls.Add(this.getstatus01);
            this.groupBox12.Controls.Add(this.tg_028);
            this.groupBox12.Controls.Add(this.tg_027);
            this.groupBox12.Controls.Add(this.tg_026);
            this.groupBox12.Controls.Add(this.tg_025);
            this.groupBox12.Controls.Add(this.tg_024);
            this.groupBox12.Controls.Add(this.tg_023);
            this.groupBox12.Controls.Add(this.tg_022);
            this.groupBox12.Controls.Add(this.tg_021);
            this.groupBox12.Controls.Add(this.tg_020);
            this.groupBox12.Controls.Add(this.tg_019);
            this.groupBox12.Controls.Add(this.tg_018);
            this.groupBox12.Controls.Add(this.tg_017);
            this.groupBox12.Controls.Add(this.tg_016);
            this.groupBox12.Controls.Add(this.tg_015);
            this.groupBox12.Controls.Add(this.tg_014);
            this.groupBox12.Controls.Add(this.tg_013);
            this.groupBox12.Controls.Add(this.tg_012);
            this.groupBox12.Controls.Add(this.tg_011);
            this.groupBox12.Controls.Add(this.tg_010);
            this.groupBox12.Controls.Add(this.tg_009);
            this.groupBox12.Controls.Add(this.tg_008);
            this.groupBox12.Controls.Add(this.tg_007);
            this.groupBox12.Controls.Add(this.tg_006);
            this.groupBox12.Controls.Add(this.tg_005);
            this.groupBox12.Controls.Add(this.tg_004);
            this.groupBox12.Controls.Add(this.tg_003);
            this.groupBox12.Controls.Add(this.tg_002);
            this.groupBox12.Controls.Add(this.tg_001);
            this.groupBox12.Controls.Add(this.groupid01);
            this.groupBox12.Location = new System.Drawing.Point(4, 9);
            this.groupBox12.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox12.Size = new System.Drawing.Size(332, 441);
            this.groupBox12.TabIndex = 4;
            this.groupBox12.TabStop = false;
            this.groupBox12.Text = "Period time";
            // 
            // label82
            // 
            this.label82.AutoSize = true;
            this.label82.Location = new System.Drawing.Point(32, 356);
            this.label82.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(89, 18);
            this.label82.TabIndex = 43;
            this.label82.Text = "StatusId:";
            // 
            // status00
            // 
            this.status00.Location = new System.Drawing.Point(160, 351);
            this.status00.Margin = new System.Windows.Forms.Padding(4);
            this.status00.Name = "status00";
            this.status00.Size = new System.Drawing.Size(66, 28);
            this.status00.TabIndex = 42;
            this.status00.Text = "0";
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.Location = new System.Drawing.Point(86, 70);
            this.label72.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(26, 18);
            this.label72.TabIndex = 41;
            this.label72.Text = "m:";
            // 
            // label73
            // 
            this.label73.AutoSize = true;
            this.label73.Location = new System.Drawing.Point(232, 70);
            this.label73.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(26, 18);
            this.label73.TabIndex = 40;
            this.label73.Text = "m:";
            // 
            // label74
            // 
            this.label74.AutoSize = true;
            this.label74.Location = new System.Drawing.Point(158, 70);
            this.label74.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(26, 18);
            this.label74.TabIndex = 39;
            this.label74.Text = "h:";
            // 
            // label75
            // 
            this.label75.AutoSize = true;
            this.label75.Location = new System.Drawing.Point(0, 70);
            this.label75.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(26, 18);
            this.label75.TabIndex = 37;
            this.label75.Text = "h:";
            // 
            // label76
            // 
            this.label76.AutoSize = true;
            this.label76.Location = new System.Drawing.Point(32, 26);
            this.label76.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(80, 18);
            this.label76.TabIndex = 36;
            this.label76.Text = "GroupId:";
            // 
            // setstatus01
            // 
            this.setstatus01.Location = new System.Drawing.Point(188, 392);
            this.setstatus01.Margin = new System.Windows.Forms.Padding(4);
            this.setstatus01.Name = "setstatus01";
            this.setstatus01.Size = new System.Drawing.Size(135, 34);
            this.setstatus01.TabIndex = 35;
            this.setstatus01.Text = "SetStatus_P";
            this.setstatus01.UseVisualStyleBackColor = true;
            this.setstatus01.Click += new System.EventHandler(this.setstatus01_Click);
            // 
            // getstatus01
            // 
            this.getstatus01.Location = new System.Drawing.Point(22, 392);
            this.getstatus01.Margin = new System.Windows.Forms.Padding(4);
            this.getstatus01.Name = "getstatus01";
            this.getstatus01.Size = new System.Drawing.Size(134, 34);
            this.getstatus01.TabIndex = 34;
            this.getstatus01.Text = "GetStatus_P";
            this.getstatus01.UseVisualStyleBackColor = true;
            this.getstatus01.Click += new System.EventHandler(this.getstatus01_Click);
            // 
            // tg_028
            // 
            this.tg_028.Location = new System.Drawing.Point(258, 309);
            this.tg_028.Margin = new System.Windows.Forms.Padding(4);
            this.tg_028.Name = "tg_028";
            this.tg_028.Size = new System.Drawing.Size(34, 28);
            this.tg_028.TabIndex = 33;
            // 
            // tg_027
            // 
            this.tg_027.Location = new System.Drawing.Point(188, 309);
            this.tg_027.Margin = new System.Windows.Forms.Padding(4);
            this.tg_027.Name = "tg_027";
            this.tg_027.Size = new System.Drawing.Size(34, 28);
            this.tg_027.TabIndex = 32;
            // 
            // tg_026
            // 
            this.tg_026.Location = new System.Drawing.Point(120, 309);
            this.tg_026.Margin = new System.Windows.Forms.Padding(4);
            this.tg_026.Name = "tg_026";
            this.tg_026.Size = new System.Drawing.Size(34, 28);
            this.tg_026.TabIndex = 31;
            // 
            // tg_025
            // 
            this.tg_025.Location = new System.Drawing.Point(34, 309);
            this.tg_025.Margin = new System.Windows.Forms.Padding(4);
            this.tg_025.Name = "tg_025";
            this.tg_025.Size = new System.Drawing.Size(34, 28);
            this.tg_025.TabIndex = 30;
            // 
            // tg_024
            // 
            this.tg_024.Location = new System.Drawing.Point(258, 268);
            this.tg_024.Margin = new System.Windows.Forms.Padding(4);
            this.tg_024.Name = "tg_024";
            this.tg_024.Size = new System.Drawing.Size(34, 28);
            this.tg_024.TabIndex = 29;
            // 
            // tg_023
            // 
            this.tg_023.Location = new System.Drawing.Point(188, 268);
            this.tg_023.Margin = new System.Windows.Forms.Padding(4);
            this.tg_023.Name = "tg_023";
            this.tg_023.Size = new System.Drawing.Size(34, 28);
            this.tg_023.TabIndex = 28;
            // 
            // tg_022
            // 
            this.tg_022.Location = new System.Drawing.Point(120, 268);
            this.tg_022.Margin = new System.Windows.Forms.Padding(4);
            this.tg_022.Name = "tg_022";
            this.tg_022.Size = new System.Drawing.Size(34, 28);
            this.tg_022.TabIndex = 27;
            // 
            // tg_021
            // 
            this.tg_021.Location = new System.Drawing.Point(34, 268);
            this.tg_021.Margin = new System.Windows.Forms.Padding(4);
            this.tg_021.Name = "tg_021";
            this.tg_021.Size = new System.Drawing.Size(34, 28);
            this.tg_021.TabIndex = 26;
            // 
            // tg_020
            // 
            this.tg_020.Location = new System.Drawing.Point(258, 228);
            this.tg_020.Margin = new System.Windows.Forms.Padding(4);
            this.tg_020.Name = "tg_020";
            this.tg_020.Size = new System.Drawing.Size(34, 28);
            this.tg_020.TabIndex = 25;
            // 
            // tg_019
            // 
            this.tg_019.Location = new System.Drawing.Point(188, 228);
            this.tg_019.Margin = new System.Windows.Forms.Padding(4);
            this.tg_019.Name = "tg_019";
            this.tg_019.Size = new System.Drawing.Size(34, 28);
            this.tg_019.TabIndex = 24;
            // 
            // tg_018
            // 
            this.tg_018.Location = new System.Drawing.Point(120, 228);
            this.tg_018.Margin = new System.Windows.Forms.Padding(4);
            this.tg_018.Name = "tg_018";
            this.tg_018.Size = new System.Drawing.Size(34, 28);
            this.tg_018.TabIndex = 23;
            // 
            // tg_017
            // 
            this.tg_017.Location = new System.Drawing.Point(34, 228);
            this.tg_017.Margin = new System.Windows.Forms.Padding(4);
            this.tg_017.Name = "tg_017";
            this.tg_017.Size = new System.Drawing.Size(34, 28);
            this.tg_017.TabIndex = 22;
            // 
            // tg_016
            // 
            this.tg_016.Location = new System.Drawing.Point(258, 188);
            this.tg_016.Margin = new System.Windows.Forms.Padding(4);
            this.tg_016.Name = "tg_016";
            this.tg_016.Size = new System.Drawing.Size(34, 28);
            this.tg_016.TabIndex = 21;
            // 
            // tg_015
            // 
            this.tg_015.Location = new System.Drawing.Point(188, 188);
            this.tg_015.Margin = new System.Windows.Forms.Padding(4);
            this.tg_015.Name = "tg_015";
            this.tg_015.Size = new System.Drawing.Size(34, 28);
            this.tg_015.TabIndex = 20;
            // 
            // tg_014
            // 
            this.tg_014.Location = new System.Drawing.Point(120, 188);
            this.tg_014.Margin = new System.Windows.Forms.Padding(4);
            this.tg_014.Name = "tg_014";
            this.tg_014.Size = new System.Drawing.Size(34, 28);
            this.tg_014.TabIndex = 19;
            // 
            // tg_013
            // 
            this.tg_013.Location = new System.Drawing.Point(34, 188);
            this.tg_013.Margin = new System.Windows.Forms.Padding(4);
            this.tg_013.Name = "tg_013";
            this.tg_013.Size = new System.Drawing.Size(34, 28);
            this.tg_013.TabIndex = 18;
            // 
            // tg_012
            // 
            this.tg_012.Location = new System.Drawing.Point(258, 147);
            this.tg_012.Margin = new System.Windows.Forms.Padding(4);
            this.tg_012.Name = "tg_012";
            this.tg_012.Size = new System.Drawing.Size(34, 28);
            this.tg_012.TabIndex = 17;
            // 
            // tg_011
            // 
            this.tg_011.Location = new System.Drawing.Point(188, 147);
            this.tg_011.Margin = new System.Windows.Forms.Padding(4);
            this.tg_011.Name = "tg_011";
            this.tg_011.Size = new System.Drawing.Size(34, 28);
            this.tg_011.TabIndex = 16;
            // 
            // tg_010
            // 
            this.tg_010.Location = new System.Drawing.Point(120, 147);
            this.tg_010.Margin = new System.Windows.Forms.Padding(4);
            this.tg_010.Name = "tg_010";
            this.tg_010.Size = new System.Drawing.Size(34, 28);
            this.tg_010.TabIndex = 15;
            // 
            // tg_009
            // 
            this.tg_009.Location = new System.Drawing.Point(34, 147);
            this.tg_009.Margin = new System.Windows.Forms.Padding(4);
            this.tg_009.Name = "tg_009";
            this.tg_009.Size = new System.Drawing.Size(34, 28);
            this.tg_009.TabIndex = 14;
            // 
            // tg_008
            // 
            this.tg_008.Location = new System.Drawing.Point(258, 106);
            this.tg_008.Margin = new System.Windows.Forms.Padding(4);
            this.tg_008.Name = "tg_008";
            this.tg_008.Size = new System.Drawing.Size(34, 28);
            this.tg_008.TabIndex = 13;
            // 
            // tg_007
            // 
            this.tg_007.Location = new System.Drawing.Point(188, 106);
            this.tg_007.Margin = new System.Windows.Forms.Padding(4);
            this.tg_007.Name = "tg_007";
            this.tg_007.Size = new System.Drawing.Size(34, 28);
            this.tg_007.TabIndex = 12;
            // 
            // tg_006
            // 
            this.tg_006.Location = new System.Drawing.Point(120, 106);
            this.tg_006.Margin = new System.Windows.Forms.Padding(4);
            this.tg_006.Name = "tg_006";
            this.tg_006.Size = new System.Drawing.Size(34, 28);
            this.tg_006.TabIndex = 11;
            // 
            // tg_005
            // 
            this.tg_005.Location = new System.Drawing.Point(34, 106);
            this.tg_005.Margin = new System.Windows.Forms.Padding(4);
            this.tg_005.Name = "tg_005";
            this.tg_005.Size = new System.Drawing.Size(34, 28);
            this.tg_005.TabIndex = 10;
            // 
            // tg_004
            // 
            this.tg_004.Location = new System.Drawing.Point(258, 66);
            this.tg_004.Margin = new System.Windows.Forms.Padding(4);
            this.tg_004.Name = "tg_004";
            this.tg_004.Size = new System.Drawing.Size(34, 28);
            this.tg_004.TabIndex = 9;
            // 
            // tg_003
            // 
            this.tg_003.Location = new System.Drawing.Point(188, 66);
            this.tg_003.Margin = new System.Windows.Forms.Padding(4);
            this.tg_003.Name = "tg_003";
            this.tg_003.Size = new System.Drawing.Size(34, 28);
            this.tg_003.TabIndex = 8;
            // 
            // tg_002
            // 
            this.tg_002.Location = new System.Drawing.Point(120, 66);
            this.tg_002.Margin = new System.Windows.Forms.Padding(4);
            this.tg_002.Name = "tg_002";
            this.tg_002.Size = new System.Drawing.Size(34, 28);
            this.tg_002.TabIndex = 7;
            // 
            // tg_001
            // 
            this.tg_001.Location = new System.Drawing.Point(34, 66);
            this.tg_001.Margin = new System.Windows.Forms.Padding(4);
            this.tg_001.Name = "tg_001";
            this.tg_001.Size = new System.Drawing.Size(34, 28);
            this.tg_001.TabIndex = 6;
            // 
            // groupid01
            // 
            this.groupid01.Location = new System.Drawing.Point(156, 21);
            this.groupid01.Margin = new System.Windows.Forms.Padding(4);
            this.groupid01.Name = "groupid01";
            this.groupid01.Size = new System.Drawing.Size(66, 28);
            this.groupid01.TabIndex = 5;
            this.groupid01.Text = "1";
            // 
            // config3
            // 
            this.config3.Controls.Add(this.SetConfig3_01);
            this.config3.Controls.Add(this.GetConfig3_01);
            this.config3.Controls.Add(this.c3_08);
            this.config3.Controls.Add(this.c3_06);
            this.config3.Controls.Add(this.c3_04);
            this.config3.Controls.Add(this.c3_02);
            this.config3.Controls.Add(this.c3_07);
            this.config3.Controls.Add(this.c3_05);
            this.config3.Controls.Add(this.c3_03);
            this.config3.Controls.Add(this.c3_01);
            this.config3.Controls.Add(this.label87);
            this.config3.Controls.Add(this.label88);
            this.config3.Controls.Add(this.label89);
            this.config3.Controls.Add(this.label90);
            this.config3.Controls.Add(this.label86);
            this.config3.Controls.Add(this.label85);
            this.config3.Controls.Add(this.label84);
            this.config3.Controls.Add(this.label83);
            this.config3.Location = new System.Drawing.Point(770, 214);
            this.config3.Margin = new System.Windows.Forms.Padding(4);
            this.config3.Name = "config3";
            this.config3.Padding = new System.Windows.Forms.Padding(4);
            this.config3.Size = new System.Drawing.Size(500, 225);
            this.config3.TabIndex = 7;
            this.config3.TabStop = false;
            this.config3.Text = "Config3";
            // 
            // SetConfig3_01
            // 
            this.SetConfig3_01.Location = new System.Drawing.Point(276, 182);
            this.SetConfig3_01.Margin = new System.Windows.Forms.Padding(4);
            this.SetConfig3_01.Name = "SetConfig3_01";
            this.SetConfig3_01.Size = new System.Drawing.Size(214, 34);
            this.SetConfig3_01.TabIndex = 54;
            this.SetConfig3_01.Text = "SetConfig3";
            this.SetConfig3_01.UseVisualStyleBackColor = true;
            this.SetConfig3_01.Click += new System.EventHandler(this.SetConfig3_01_Click);
            // 
            // GetConfig3_01
            // 
            this.GetConfig3_01.Location = new System.Drawing.Point(16, 182);
            this.GetConfig3_01.Margin = new System.Windows.Forms.Padding(4);
            this.GetConfig3_01.Name = "GetConfig3_01";
            this.GetConfig3_01.Size = new System.Drawing.Size(218, 34);
            this.GetConfig3_01.TabIndex = 53;
            this.GetConfig3_01.Text = "GetConfig3";
            this.GetConfig3_01.UseVisualStyleBackColor = true;
            this.GetConfig3_01.Click += new System.EventHandler(this.GetConfig3_01_Click);
            // 
            // c3_08
            // 
            this.c3_08.Location = new System.Drawing.Point(423, 147);
            this.c3_08.Margin = new System.Windows.Forms.Padding(4);
            this.c3_08.Name = "c3_08";
            this.c3_08.Size = new System.Drawing.Size(66, 28);
            this.c3_08.TabIndex = 52;
            this.c3_08.Text = "0";
            // 
            // c3_06
            // 
            this.c3_06.Location = new System.Drawing.Point(423, 106);
            this.c3_06.Margin = new System.Windows.Forms.Padding(4);
            this.c3_06.Name = "c3_06";
            this.c3_06.Size = new System.Drawing.Size(66, 28);
            this.c3_06.TabIndex = 51;
            this.c3_06.Text = "0";
            // 
            // c3_04
            // 
            this.c3_04.Location = new System.Drawing.Point(423, 72);
            this.c3_04.Margin = new System.Windows.Forms.Padding(4);
            this.c3_04.Name = "c3_04";
            this.c3_04.Size = new System.Drawing.Size(66, 28);
            this.c3_04.TabIndex = 50;
            this.c3_04.Text = "0";
            // 
            // c3_02
            // 
            this.c3_02.Location = new System.Drawing.Point(423, 32);
            this.c3_02.Margin = new System.Windows.Forms.Padding(4);
            this.c3_02.Name = "c3_02";
            this.c3_02.Size = new System.Drawing.Size(66, 28);
            this.c3_02.TabIndex = 49;
            this.c3_02.Text = "0";
            // 
            // c3_07
            // 
            this.c3_07.Location = new System.Drawing.Point(166, 147);
            this.c3_07.Margin = new System.Windows.Forms.Padding(4);
            this.c3_07.Name = "c3_07";
            this.c3_07.Size = new System.Drawing.Size(66, 28);
            this.c3_07.TabIndex = 48;
            this.c3_07.Text = "0";
            // 
            // c3_05
            // 
            this.c3_05.Location = new System.Drawing.Point(166, 106);
            this.c3_05.Margin = new System.Windows.Forms.Padding(4);
            this.c3_05.Name = "c3_05";
            this.c3_05.Size = new System.Drawing.Size(66, 28);
            this.c3_05.TabIndex = 47;
            this.c3_05.Text = "0";
            // 
            // c3_03
            // 
            this.c3_03.Location = new System.Drawing.Point(166, 72);
            this.c3_03.Margin = new System.Windows.Forms.Padding(4);
            this.c3_03.Name = "c3_03";
            this.c3_03.Size = new System.Drawing.Size(66, 28);
            this.c3_03.TabIndex = 46;
            this.c3_03.Text = "0";
            // 
            // c3_01
            // 
            this.c3_01.Location = new System.Drawing.Point(166, 32);
            this.c3_01.Margin = new System.Windows.Forms.Padding(4);
            this.c3_01.Name = "c3_01";
            this.c3_01.Size = new System.Drawing.Size(66, 28);
            this.c3_01.TabIndex = 45;
            this.c3_01.Text = "0";
            // 
            // label87
            // 
            this.label87.AutoSize = true;
            this.label87.Location = new System.Drawing.Point(243, 150);
            this.label87.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label87.Name = "label87";
            this.label87.Size = new System.Drawing.Size(125, 18);
            this.label87.TabIndex = 44;
            this.label87.Text = "m5_t5_status:";
            // 
            // label88
            // 
            this.label88.AutoSize = true;
            this.label88.Location = new System.Drawing.Point(243, 117);
            this.label88.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label88.Name = "label88";
            this.label88.Size = new System.Drawing.Size(179, 18);
            this.label88.TabIndex = 43;
            this.label88.Text = "UnauthorizedRecord:";
            // 
            // label89
            // 
            this.label89.AutoSize = true;
            this.label89.Location = new System.Drawing.Point(243, 76);
            this.label89.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label89.Name = "label89";
            this.label89.Size = new System.Drawing.Size(107, 18);
            this.label89.TabIndex = 42;
            this.label89.Text = "pwd_status:";
            // 
            // label90
            // 
            this.label90.AutoSize = true;
            this.label90.Location = new System.Drawing.Point(243, 36);
            this.label90.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label90.Name = "label90";
            this.label90.Size = new System.Drawing.Size(116, 18);
            this.label90.TabIndex = 41;
            this.label90.Text = "online_mode:";
            // 
            // label86
            // 
            this.label86.AutoSize = true;
            this.label86.Location = new System.Drawing.Point(14, 150);
            this.label86.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label86.Name = "label86";
            this.label86.Size = new System.Drawing.Size(152, 18);
            this.label86.TabIndex = 40;
            this.label86.Text = "IndependentTime:";
            // 
            // label85
            // 
            this.label85.AutoSize = true;
            this.label85.Location = new System.Drawing.Point(14, 112);
            this.label85.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label85.Name = "label85";
            this.label85.Size = new System.Drawing.Size(134, 18);
            this.label85.TabIndex = 39;
            this.label85.Text = "sensor_status:";
            // 
            // label84
            // 
            this.label84.AutoSize = true;
            this.label84.Location = new System.Drawing.Point(14, 76);
            this.label84.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label84.Name = "label84";
            this.label84.Size = new System.Drawing.Size(134, 18);
            this.label84.TabIndex = 38;
            this.label84.Text = "collect_level:";
            // 
            // label83
            // 
            this.label83.AutoSize = true;
            this.label83.Location = new System.Drawing.Point(14, 36);
            this.label83.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label83.Name = "label83";
            this.label83.Size = new System.Drawing.Size(125, 18);
            this.label83.TabIndex = 37;
            this.label83.Text = "wiegand_type:";
            // 
            // tabPage7
            // 
            this.tabPage7.Controls.Add(this.groupBox26);
            this.tabPage7.Controls.Add(this.groupBox22);
            this.tabPage7.Controls.Add(this.groupBox20);
            this.tabPage7.Controls.Add(this.groupBox11);
            this.tabPage7.Controls.Add(this.groupBox19);
            this.tabPage7.Controls.Add(this.groupBox18);
            this.tabPage7.Controls.Add(this.groupBox17);
            this.tabPage7.Location = new System.Drawing.Point(4, 28);
            this.tabPage7.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage7.Size = new System.Drawing.Size(1444, 501);
            this.tabPage7.TabIndex = 7;
            this.tabPage7.Text = "tabPage7";
            this.tabPage7.UseVisualStyleBackColor = true;
            // 
            // groupBox26
            // 
            this.groupBox26.Controls.Add(this.button_verifGet);
            this.groupBox26.Controls.Add(this.button_verifSet);
            this.groupBox26.Controls.Add(this.listBox_verifs);
            this.groupBox26.Controls.Add(this.label180);
            this.groupBox26.Controls.Add(this.label179);
            this.groupBox26.Controls.Add(this.textBox_verfVer);
            this.groupBox26.Controls.Add(this.textBox_verifmode);
            this.groupBox26.Location = new System.Drawing.Point(980, 9);
            this.groupBox26.Name = "groupBox26";
            this.groupBox26.Size = new System.Drawing.Size(324, 196);
            this.groupBox26.TabIndex = 20;
            this.groupBox26.TabStop = false;
            this.groupBox26.Text = "Verification mode";
            // 
            // button_verifGet
            // 
            this.button_verifGet.Location = new System.Drawing.Point(28, 113);
            this.button_verifGet.Name = "button_verifGet";
            this.button_verifGet.Size = new System.Drawing.Size(160, 32);
            this.button_verifGet.TabIndex = 4;
            this.button_verifGet.Text = "Get";
            this.button_verifGet.UseVisualStyleBackColor = true;
            this.button_verifGet.Click += new System.EventHandler(this.button_verifGet_Click);
            // 
            // button_verifSet
            // 
            this.button_verifSet.Location = new System.Drawing.Point(28, 145);
            this.button_verifSet.Name = "button_verifSet";
            this.button_verifSet.Size = new System.Drawing.Size(160, 32);
            this.button_verifSet.TabIndex = 3;
            this.button_verifSet.Text = "Set";
            this.button_verifSet.UseVisualStyleBackColor = true;
            this.button_verifSet.Click += new System.EventHandler(this.button_verifSet_Click);
            // 
            // listBox_verifs
            // 
            this.listBox_verifs.FormattingEnabled = true;
            this.listBox_verifs.ItemHeight = 18;
            this.listBox_verifs.Location = new System.Drawing.Point(203, 27);
            this.listBox_verifs.Name = "listBox_verifs";
            this.listBox_verifs.Size = new System.Drawing.Size(115, 148);
            this.listBox_verifs.TabIndex = 2;
            this.listBox_verifs.MouseHover += new System.EventHandler(this.verifTitle);
            // 
            // label180
            // 
            this.label180.AutoSize = true;
            this.label180.Location = new System.Drawing.Point(6, 81);
            this.label180.Name = "label180";
            this.label180.Size = new System.Drawing.Size(44, 18);
            this.label180.TabIndex = 1;
            this.label180.Text = "ver:";
            // 
            // label179
            // 
            this.label179.AutoSize = true;
            this.label179.Location = new System.Drawing.Point(6, 47);
            this.label179.Name = "label179";
            this.label179.Size = new System.Drawing.Size(53, 18);
            this.label179.TabIndex = 1;
            this.label179.Text = "mode:";
            // 
            // textBox_verfVer
            // 
            this.textBox_verfVer.Location = new System.Drawing.Point(88, 75);
            this.textBox_verfVer.Name = "textBox_verfVer";
            this.textBox_verfVer.Size = new System.Drawing.Size(100, 28);
            this.textBox_verfVer.TabIndex = 0;
            // 
            // textBox_verifmode
            // 
            this.textBox_verifmode.Location = new System.Drawing.Point(88, 41);
            this.textBox_verifmode.Name = "textBox_verifmode";
            this.textBox_verifmode.Size = new System.Drawing.Size(100, 28);
            this.textBox_verifmode.TabIndex = 0;
            // 
            // groupBox22
            // 
            this.groupBox22.Controls.Add(this.set_a);
            this.groupBox22.Controls.Add(this.label109);
            this.groupBox22.Controls.Add(this.choose02);
            this.groupBox22.Controls.Add(this.a_name_02);
            this.groupBox22.Controls.Add(this.a_password_02);
            this.groupBox22.Controls.Add(this.label111);
            this.groupBox22.Location = new System.Drawing.Point(708, 214);
            this.groupBox22.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox22.Name = "groupBox22";
            this.groupBox22.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox22.Size = new System.Drawing.Size(552, 226);
            this.groupBox22.TabIndex = 19;
            this.groupBox22.TabStop = false;
            this.groupBox22.Text = "Set  Connect Authentication  Before  Login";
            // 
            // set_a
            // 
            this.set_a.Location = new System.Drawing.Point(0, 186);
            this.set_a.Margin = new System.Windows.Forms.Padding(4);
            this.set_a.Name = "set_a";
            this.set_a.Size = new System.Drawing.Size(495, 34);
            this.set_a.TabIndex = 16;
            this.set_a.Text = "Set Enable(diseable) Authentication  before Login";
            this.set_a.UseVisualStyleBackColor = true;
            this.set_a.Click += new System.EventHandler(this.set_a_Click);
            // 
            // label109
            // 
            this.label109.AutoSize = true;
            this.label109.Location = new System.Drawing.Point(0, 100);
            this.label109.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label109.Name = "label109";
            this.label109.Size = new System.Drawing.Size(332, 18);
            this.label109.TabIndex = 5;
            this.label109.Text = "Default Connect Authentication Name:";
            // 
            // choose02
            // 
            this.choose02.AutoSize = true;
            this.choose02.Location = new System.Drawing.Point(9, 46);
            this.choose02.Margin = new System.Windows.Forms.Padding(4);
            this.choose02.Name = "choose02";
            this.choose02.Size = new System.Drawing.Size(484, 22);
            this.choose02.TabIndex = 10;
            this.choose02.Text = "Choose Here to authenticate .UNchoose Set Disable!";
            this.choose02.UseVisualStyleBackColor = true;
            // 
            // a_name_02
            // 
            this.a_name_02.Location = new System.Drawing.Point(340, 96);
            this.a_name_02.Margin = new System.Windows.Forms.Padding(4);
            this.a_name_02.Name = "a_name_02";
            this.a_name_02.Size = new System.Drawing.Size(148, 28);
            this.a_name_02.TabIndex = 6;
            this.a_name_02.Text = "admin";
            // 
            // a_password_02
            // 
            this.a_password_02.Location = new System.Drawing.Point(345, 136);
            this.a_password_02.Margin = new System.Windows.Forms.Padding(4);
            this.a_password_02.Name = "a_password_02";
            this.a_password_02.Size = new System.Drawing.Size(148, 28);
            this.a_password_02.TabIndex = 7;
            this.a_password_02.Text = "12345";
            // 
            // label111
            // 
            this.label111.AutoSize = true;
            this.label111.Location = new System.Drawing.Point(243, 141);
            this.label111.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label111.Name = "label111";
            this.label111.Size = new System.Drawing.Size(89, 18);
            this.label111.TabIndex = 9;
            this.label111.Text = "Password:";
            // 
            // groupBox20
            // 
            this.groupBox20.Controls.Add(this.devidx_z);
            this.groupBox20.Controls.Add(this.label106);
            this.groupBox20.Controls.Add(this.button13);
            this.groupBox20.Controls.Add(this.machine_z);
            this.groupBox20.Controls.Add(this.label107);
            this.groupBox20.Location = new System.Drawing.Point(662, 9);
            this.groupBox20.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox20.Name = "groupBox20";
            this.groupBox20.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox20.Size = new System.Drawing.Size(300, 196);
            this.groupBox20.TabIndex = 18;
            this.groupBox20.TabStop = false;
            this.groupBox20.Text = "Find DevIdx By MachineId";
            // 
            // devidx_z
            // 
            this.devidx_z.Location = new System.Drawing.Point(124, 82);
            this.devidx_z.Margin = new System.Windows.Forms.Padding(4);
            this.devidx_z.Name = "devidx_z";
            this.devidx_z.Size = new System.Drawing.Size(164, 28);
            this.devidx_z.TabIndex = 17;
            // 
            // label106
            // 
            this.label106.AutoSize = true;
            this.label106.Location = new System.Drawing.Point(9, 87);
            this.label106.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label106.Name = "label106";
            this.label106.Size = new System.Drawing.Size(71, 18);
            this.label106.TabIndex = 16;
            this.label106.Text = "DevIdx:";
            // 
            // button13
            // 
            this.button13.Location = new System.Drawing.Point(12, 134);
            this.button13.Margin = new System.Windows.Forms.Padding(4);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(279, 34);
            this.button13.TabIndex = 15;
            this.button13.Text = "Find DevIdx";
            this.button13.UseVisualStyleBackColor = true;
            this.button13.Click += new System.EventHandler(this.button13_Click);
            // 
            // machine_z
            // 
            this.machine_z.Location = new System.Drawing.Point(124, 44);
            this.machine_z.Margin = new System.Windows.Forms.Padding(4);
            this.machine_z.Name = "machine_z";
            this.machine_z.Size = new System.Drawing.Size(164, 28);
            this.machine_z.TabIndex = 13;
            // 
            // label107
            // 
            this.label107.AutoSize = true;
            this.label107.Location = new System.Drawing.Point(9, 48);
            this.label107.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label107.Name = "label107";
            this.label107.Size = new System.Drawing.Size(98, 18);
            this.label107.TabIndex = 12;
            this.label107.Text = "MachineId:";
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.label94);
            this.groupBox11.Controls.Add(this.url_dns);
            this.groupBox11.Controls.Add(this.seturl);
            this.groupBox11.Controls.Add(this.geturl);
            this.groupBox11.Controls.Add(this.url_01);
            this.groupBox11.Location = new System.Drawing.Point(4, 214);
            this.groupBox11.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox11.Size = new System.Drawing.Size(694, 142);
            this.groupBox11.TabIndex = 17;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "URL info";
            // 
            // label94
            // 
            this.label94.AutoSize = true;
            this.label94.Location = new System.Drawing.Point(10, 46);
            this.label94.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label94.Name = "label94";
            this.label94.Size = new System.Drawing.Size(44, 18);
            this.label94.TabIndex = 33;
            this.label94.Text = "DNS:";
            // 
            // url_dns
            // 
            this.url_dns.Location = new System.Drawing.Point(58, 42);
            this.url_dns.Margin = new System.Windows.Forms.Padding(4);
            this.url_dns.Name = "url_dns";
            this.url_dns.Size = new System.Drawing.Size(133, 28);
            this.url_dns.TabIndex = 13;
            // 
            // seturl
            // 
            this.seturl.Location = new System.Drawing.Point(250, 93);
            this.seturl.Margin = new System.Windows.Forms.Padding(4);
            this.seturl.Name = "seturl";
            this.seturl.Size = new System.Drawing.Size(200, 34);
            this.seturl.TabIndex = 11;
            this.seturl.Text = "Set Url";
            this.seturl.UseVisualStyleBackColor = true;
            this.seturl.Click += new System.EventHandler(this.seturl_Click_1);
            // 
            // geturl
            // 
            this.geturl.Location = new System.Drawing.Point(9, 93);
            this.geturl.Margin = new System.Windows.Forms.Padding(4);
            this.geturl.Name = "geturl";
            this.geturl.Size = new System.Drawing.Size(200, 34);
            this.geturl.TabIndex = 10;
            this.geturl.Text = "Get Url";
            this.geturl.UseVisualStyleBackColor = true;
            this.geturl.Click += new System.EventHandler(this.geturl_Click_1);
            // 
            // url_01
            // 
            this.url_01.Location = new System.Drawing.Point(202, 42);
            this.url_01.Margin = new System.Windows.Forms.Padding(4);
            this.url_01.Name = "url_01";
            this.url_01.Size = new System.Drawing.Size(468, 28);
            this.url_01.TabIndex = 9;
            // 
            // groupBox19
            // 
            this.groupBox19.Controls.Add(this.clearadmin);
            this.groupBox19.Location = new System.Drawing.Point(9, 357);
            this.groupBox19.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox19.Name = "groupBox19";
            this.groupBox19.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox19.Size = new System.Drawing.Size(262, 84);
            this.groupBox19.TabIndex = 16;
            this.groupBox19.TabStop = false;
            this.groupBox19.Text = "Administrat Status";
            // 
            // clearadmin
            // 
            this.clearadmin.Location = new System.Drawing.Point(9, 30);
            this.clearadmin.Margin = new System.Windows.Forms.Padding(4);
            this.clearadmin.Name = "clearadmin";
            this.clearadmin.Size = new System.Drawing.Size(231, 34);
            this.clearadmin.TabIndex = 8;
            this.clearadmin.Text = "Clear Administrator";
            this.clearadmin.UseVisualStyleBackColor = true;
            this.clearadmin.Click += new System.EventHandler(this.clearadmin_Click);
            // 
            // groupBox18
            // 
            this.groupBox18.Controls.Add(this.c_password);
            this.groupBox18.Controls.Add(this.label103);
            this.groupBox18.Controls.Add(this.authentication);
            this.groupBox18.Controls.Add(this.c_username);
            this.groupBox18.Controls.Add(this.label102);
            this.groupBox18.Location = new System.Drawing.Point(318, 9);
            this.groupBox18.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox18.Name = "groupBox18";
            this.groupBox18.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox18.Size = new System.Drawing.Size(300, 196);
            this.groupBox18.TabIndex = 15;
            this.groupBox18.TabStop = false;
            this.groupBox18.Text = "Connect Authentication";
            // 
            // c_password
            // 
            this.c_password.Location = new System.Drawing.Point(124, 82);
            this.c_password.Margin = new System.Windows.Forms.Padding(4);
            this.c_password.Name = "c_password";
            this.c_password.Size = new System.Drawing.Size(164, 28);
            this.c_password.TabIndex = 17;
            this.c_password.Text = "admin";
            // 
            // label103
            // 
            this.label103.AutoSize = true;
            this.label103.Location = new System.Drawing.Point(9, 87);
            this.label103.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label103.Name = "label103";
            this.label103.Size = new System.Drawing.Size(89, 18);
            this.label103.TabIndex = 16;
            this.label103.Text = "Password:";
            // 
            // authentication
            // 
            this.authentication.Location = new System.Drawing.Point(12, 134);
            this.authentication.Margin = new System.Windows.Forms.Padding(4);
            this.authentication.Name = "authentication";
            this.authentication.Size = new System.Drawing.Size(279, 34);
            this.authentication.TabIndex = 15;
            this.authentication.Text = "Connect Authentication";
            this.authentication.UseVisualStyleBackColor = true;
            this.authentication.Click += new System.EventHandler(this.authentication_Click);
            // 
            // c_username
            // 
            this.c_username.Location = new System.Drawing.Point(124, 44);
            this.c_username.Margin = new System.Windows.Forms.Padding(4);
            this.c_username.Name = "c_username";
            this.c_username.Size = new System.Drawing.Size(164, 28);
            this.c_username.TabIndex = 13;
            this.c_username.Text = "admin";
            // 
            // label102
            // 
            this.label102.AutoSize = true;
            this.label102.Location = new System.Drawing.Point(9, 48);
            this.label102.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label102.Name = "label102";
            this.label102.Size = new System.Drawing.Size(89, 18);
            this.label102.TabIndex = 12;
            this.label102.Text = "Username:";
            // 
            // groupBox17
            // 
            this.groupBox17.Controls.Add(this.setmachi01);
            this.groupBox17.Controls.Add(this.getmachineid);
            this.groupBox17.Controls.Add(this.machineid_01);
            this.groupBox17.Controls.Add(this.label101);
            this.groupBox17.Location = new System.Drawing.Point(9, 9);
            this.groupBox17.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox17.Name = "groupBox17";
            this.groupBox17.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox17.Size = new System.Drawing.Size(300, 196);
            this.groupBox17.TabIndex = 14;
            this.groupBox17.TabStop = false;
            this.groupBox17.Text = "MachineID";
            // 
            // setmachi01
            // 
            this.setmachi01.Location = new System.Drawing.Point(12, 134);
            this.setmachi01.Margin = new System.Windows.Forms.Padding(4);
            this.setmachi01.Name = "setmachi01";
            this.setmachi01.Size = new System.Drawing.Size(279, 34);
            this.setmachi01.TabIndex = 15;
            this.setmachi01.Text = "Set Machine Id";
            this.setmachi01.UseVisualStyleBackColor = true;
            this.setmachi01.Click += new System.EventHandler(this.setmachine_Click);
            // 
            // getmachineid
            // 
            this.getmachineid.Location = new System.Drawing.Point(12, 90);
            this.getmachineid.Margin = new System.Windows.Forms.Padding(4);
            this.getmachineid.Name = "getmachineid";
            this.getmachineid.Size = new System.Drawing.Size(279, 34);
            this.getmachineid.TabIndex = 14;
            this.getmachineid.Text = "Get Machine Id";
            this.getmachineid.UseVisualStyleBackColor = true;
            this.getmachineid.Click += new System.EventHandler(this.getmachineid_Click);
            // 
            // machineid_01
            // 
            this.machineid_01.Location = new System.Drawing.Point(124, 44);
            this.machineid_01.Margin = new System.Windows.Forms.Padding(4);
            this.machineid_01.Name = "machineid_01";
            this.machineid_01.Size = new System.Drawing.Size(164, 28);
            this.machineid_01.TabIndex = 13;
            this.machineid_01.Text = "0";
            // 
            // label101
            // 
            this.label101.AutoSize = true;
            this.label101.Location = new System.Drawing.Point(9, 48);
            this.label101.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label101.Name = "label101";
            this.label101.Size = new System.Drawing.Size(107, 18);
            this.label101.TabIndex = 12;
            this.label101.Text = "Machine Id:";
            // 
            // tabPage8
            // 
            this.tabPage8.Controls.Add(this.button19);
            this.tabPage8.Controls.Add(this.button18);
            this.tabPage8.Controls.Add(this.button17);
            this.tabPage8.Controls.Add(this.button_del_flag_count);
            this.tabPage8.Controls.Add(this.textBox_del_flag_count);
            this.tabPage8.Controls.Add(this.label28);
            this.tabPage8.Controls.Add(this.button_del_all_record);
            this.tabPage8.Controls.Add(this.groupBox24);
            this.tabPage8.Controls.Add(this.groupBox23);
            this.tabPage8.Location = new System.Drawing.Point(4, 28);
            this.tabPage8.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage8.Name = "tabPage8";
            this.tabPage8.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage8.Size = new System.Drawing.Size(1444, 501);
            this.tabPage8.TabIndex = 8;
            this.tabPage8.Text = "tabPage8";
            this.tabPage8.UseVisualStyleBackColor = true;
            // 
            // button19
            // 
            this.button19.Location = new System.Drawing.Point(542, 352);
            this.button19.Margin = new System.Windows.Forms.Padding(4);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(168, 82);
            this.button19.TabIndex = 34;
            this.button19.Text = "STOP HANDLE";
            this.button19.UseVisualStyleBackColor = true;
            this.button19.Click += new System.EventHandler(this.button19_Click);
            // 
            // button18
            // 
            this.button18.Location = new System.Drawing.Point(368, 352);
            this.button18.Margin = new System.Windows.Forms.Padding(4);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(150, 82);
            this.button18.TabIndex = 33;
            this.button18.Text = "START HANDLE";
            this.button18.UseVisualStyleBackColor = true;
            this.button18.Click += new System.EventHandler(this.button18_Click);
            // 
            // button17
            // 
            this.button17.Location = new System.Drawing.Point(368, 306);
            this.button17.Margin = new System.Windows.Forms.Padding(4);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(342, 38);
            this.button17.TabIndex = 32;
            this.button17.Text = "Get Record Info";
            this.button17.UseVisualStyleBackColor = true;
            this.button17.Click += new System.EventHandler(this.button17_Click);
            // 
            // button_del_flag_count
            // 
            this.button_del_flag_count.Location = new System.Drawing.Point(33, 398);
            this.button_del_flag_count.Margin = new System.Windows.Forms.Padding(4);
            this.button_del_flag_count.Name = "button_del_flag_count";
            this.button_del_flag_count.Size = new System.Drawing.Size(324, 38);
            this.button_del_flag_count.TabIndex = 31;
            this.button_del_flag_count.Text = "Set New flag To Old flag";
            this.button_del_flag_count.UseVisualStyleBackColor = true;
            this.button_del_flag_count.Click += new System.EventHandler(this.button_del_flag_count_Click_1);
            // 
            // textBox_del_flag_count
            // 
            this.textBox_del_flag_count.Location = new System.Drawing.Point(244, 352);
            this.textBox_del_flag_count.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_del_flag_count.Name = "textBox_del_flag_count";
            this.textBox_del_flag_count.Size = new System.Drawing.Size(112, 28);
            this.textBox_del_flag_count.TabIndex = 30;
            this.textBox_del_flag_count.Text = "0";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(30, 357);
            this.label28.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(206, 18);
            this.label28.TabIndex = 29;
            this.label28.Text = "Flag new record count:";
            // 
            // button_del_all_record
            // 
            this.button_del_all_record.Location = new System.Drawing.Point(33, 308);
            this.button_del_all_record.Margin = new System.Windows.Forms.Padding(4);
            this.button_del_all_record.Name = "button_del_all_record";
            this.button_del_all_record.Size = new System.Drawing.Size(326, 36);
            this.button_del_all_record.TabIndex = 28;
            this.button_del_all_record.Text = "Delete all record";
            this.button_del_all_record.UseVisualStyleBackColor = true;
            this.button_del_all_record.Click += new System.EventHandler(this.button_del_all_record_Click_1);
            // 
            // groupBox24
            // 
            this.groupBox24.Controls.Add(this.label117);
            this.groupBox24.Controls.Add(this.p_record_004);
            this.groupBox24.Controls.Add(this.button15);
            this.groupBox24.Controls.Add(this.label119);
            this.groupBox24.Controls.Add(this.label120);
            this.groupBox24.Controls.Add(this.label121);
            this.groupBox24.Controls.Add(this.button14);
            this.groupBox24.Controls.Add(this.p_record_003);
            this.groupBox24.Controls.Add(this.p_record_002);
            this.groupBox24.Controls.Add(this.p_record_001);
            this.groupBox24.Location = new System.Drawing.Point(366, 9);
            this.groupBox24.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox24.Name = "groupBox24";
            this.groupBox24.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox24.Size = new System.Drawing.Size(352, 273);
            this.groupBox24.TabIndex = 1;
            this.groupBox24.TabStop = false;
            this.groupBox24.Text = "downloadRecordByTimeAndPerson";
            // 
            // label117
            // 
            this.label117.AutoSize = true;
            this.label117.Location = new System.Drawing.Point(30, 154);
            this.label117.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label117.Name = "label117";
            this.label117.Size = new System.Drawing.Size(71, 18);
            this.label117.TabIndex = 25;
            this.label117.Text = "Number:";
            // 
            // p_record_004
            // 
            this.p_record_004.Location = new System.Drawing.Point(146, 150);
            this.p_record_004.Margin = new System.Windows.Forms.Padding(4);
            this.p_record_004.Name = "p_record_004";
            this.p_record_004.Size = new System.Drawing.Size(196, 28);
            this.p_record_004.TabIndex = 24;
            // 
            // button15
            // 
            this.button15.Location = new System.Drawing.Point(33, 186);
            this.button15.Margin = new System.Windows.Forms.Padding(4);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(310, 34);
            this.button15.TabIndex = 23;
            this.button15.Text = "Demand Record";
            this.button15.UseVisualStyleBackColor = true;
            this.button15.Click += new System.EventHandler(this.button15_Click_1);
            // 
            // label119
            // 
            this.label119.AutoSize = true;
            this.label119.Location = new System.Drawing.Point(30, 118);
            this.label119.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label119.Name = "label119";
            this.label119.Size = new System.Drawing.Size(89, 18);
            this.label119.TabIndex = 22;
            this.label119.Text = "end time:";
            // 
            // label120
            // 
            this.label120.AutoSize = true;
            this.label120.Location = new System.Drawing.Point(30, 78);
            this.label120.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label120.Name = "label120";
            this.label120.Size = new System.Drawing.Size(107, 18);
            this.label120.TabIndex = 21;
            this.label120.Text = "start time:";
            // 
            // label121
            // 
            this.label121.AutoSize = true;
            this.label121.Location = new System.Drawing.Point(30, 38);
            this.label121.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label121.Name = "label121";
            this.label121.Size = new System.Drawing.Size(107, 18);
            this.label121.TabIndex = 20;
            this.label121.Text = "EmployeeId:";
            // 
            // button14
            // 
            this.button14.Location = new System.Drawing.Point(33, 230);
            this.button14.Margin = new System.Windows.Forms.Padding(4);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(310, 34);
            this.button14.TabIndex = 19;
            this.button14.Text = "Download Record";
            this.button14.UseVisualStyleBackColor = true;
            this.button14.Click += new System.EventHandler(this.button14_Click_1);
            // 
            // p_record_003
            // 
            this.p_record_003.Location = new System.Drawing.Point(146, 114);
            this.p_record_003.Margin = new System.Windows.Forms.Padding(4);
            this.p_record_003.Name = "p_record_003";
            this.p_record_003.Size = new System.Drawing.Size(196, 28);
            this.p_record_003.TabIndex = 16;
            this.p_record_003.Text = "2019-04-01 00:00:00";
            // 
            // p_record_002
            // 
            this.p_record_002.Location = new System.Drawing.Point(146, 74);
            this.p_record_002.Margin = new System.Windows.Forms.Padding(4);
            this.p_record_002.Name = "p_record_002";
            this.p_record_002.Size = new System.Drawing.Size(196, 28);
            this.p_record_002.TabIndex = 15;
            this.p_record_002.Text = "2019-01-01 00:00:00";
            // 
            // p_record_001
            // 
            this.p_record_001.Location = new System.Drawing.Point(146, 33);
            this.p_record_001.Margin = new System.Windows.Forms.Padding(4);
            this.p_record_001.Name = "p_record_001";
            this.p_record_001.Size = new System.Drawing.Size(196, 28);
            this.p_record_001.TabIndex = 14;
            this.p_record_001.Text = "1";
            // 
            // groupBox23
            // 
            this.groupBox23.Controls.Add(this.label116);
            this.groupBox23.Controls.Add(this.label115);
            this.groupBox23.Controls.Add(this.label114);
            this.groupBox23.Controls.Add(this.label113);
            this.groupBox23.Controls.Add(this.label112);
            this.groupBox23.Controls.Add(this.upload_record);
            this.groupBox23.Controls.Add(this.upload_005);
            this.groupBox23.Controls.Add(this.upload_004);
            this.groupBox23.Controls.Add(this.upload_003);
            this.groupBox23.Controls.Add(this.upload_002);
            this.groupBox23.Controls.Add(this.upload_001);
            this.groupBox23.Location = new System.Drawing.Point(0, 4);
            this.groupBox23.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox23.Name = "groupBox23";
            this.groupBox23.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox23.Size = new System.Drawing.Size(357, 278);
            this.groupBox23.TabIndex = 0;
            this.groupBox23.TabStop = false;
            this.groupBox23.Text = "UploadRecord";
            // 
            // label116
            // 
            this.label116.AutoSize = true;
            this.label116.Location = new System.Drawing.Point(30, 200);
            this.label116.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label116.Name = "label116";
            this.label116.Size = new System.Drawing.Size(98, 18);
            this.label116.TabIndex = 24;
            this.label116.Text = "work_type:";
            // 
            // label115
            // 
            this.label115.AutoSize = true;
            this.label115.Location = new System.Drawing.Point(30, 159);
            this.label115.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label115.Name = "label115";
            this.label115.Size = new System.Drawing.Size(107, 18);
            this.label115.TabIndex = 23;
            this.label115.Text = "RecordType:";
            // 
            // label114
            // 
            this.label114.AutoSize = true;
            this.label114.Location = new System.Drawing.Point(30, 118);
            this.label114.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label114.Name = "label114";
            this.label114.Size = new System.Drawing.Size(80, 18);
            this.label114.TabIndex = 22;
            this.label114.Text = "back_id:";
            // 
            // label113
            // 
            this.label113.AutoSize = true;
            this.label113.Location = new System.Drawing.Point(30, 78);
            this.label113.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label113.Name = "label113";
            this.label113.Size = new System.Drawing.Size(53, 18);
            this.label113.TabIndex = 21;
            this.label113.Text = "time:";
            // 
            // label112
            // 
            this.label112.AutoSize = true;
            this.label112.Location = new System.Drawing.Point(30, 38);
            this.label112.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label112.Name = "label112";
            this.label112.Size = new System.Drawing.Size(107, 18);
            this.label112.TabIndex = 20;
            this.label112.Text = "EmployeeId:";
            // 
            // upload_record
            // 
            this.upload_record.Location = new System.Drawing.Point(33, 234);
            this.upload_record.Margin = new System.Windows.Forms.Padding(4);
            this.upload_record.Name = "upload_record";
            this.upload_record.Size = new System.Drawing.Size(315, 34);
            this.upload_record.TabIndex = 19;
            this.upload_record.Text = "Upload Record";
            this.upload_record.UseVisualStyleBackColor = true;
            this.upload_record.Click += new System.EventHandler(this.upload_record_Click);
            // 
            // upload_005
            // 
            this.upload_005.Location = new System.Drawing.Point(146, 195);
            this.upload_005.Margin = new System.Windows.Forms.Padding(4);
            this.upload_005.Name = "upload_005";
            this.upload_005.Size = new System.Drawing.Size(200, 28);
            this.upload_005.TabIndex = 18;
            this.upload_005.Text = "0";
            // 
            // upload_004
            // 
            this.upload_004.Location = new System.Drawing.Point(146, 154);
            this.upload_004.Margin = new System.Windows.Forms.Padding(4);
            this.upload_004.Name = "upload_004";
            this.upload_004.Size = new System.Drawing.Size(200, 28);
            this.upload_004.TabIndex = 17;
            this.upload_004.Text = "0";
            // 
            // upload_003
            // 
            this.upload_003.Location = new System.Drawing.Point(146, 114);
            this.upload_003.Margin = new System.Windows.Forms.Padding(4);
            this.upload_003.Name = "upload_003";
            this.upload_003.Size = new System.Drawing.Size(200, 28);
            this.upload_003.TabIndex = 16;
            this.upload_003.Text = "4";
            this.upload_003.TextChanged += new System.EventHandler(this.upload_003_TextChanged);
            // 
            // upload_002
            // 
            this.upload_002.Location = new System.Drawing.Point(146, 74);
            this.upload_002.Margin = new System.Windows.Forms.Padding(4);
            this.upload_002.Name = "upload_002";
            this.upload_002.Size = new System.Drawing.Size(200, 28);
            this.upload_002.TabIndex = 15;
            this.upload_002.Text = "2019-01-01 00:00:00";
            this.upload_002.TextChanged += new System.EventHandler(this.upload_002_TextChanged);
            // 
            // upload_001
            // 
            this.upload_001.Location = new System.Drawing.Point(146, 33);
            this.upload_001.Margin = new System.Windows.Forms.Padding(4);
            this.upload_001.Name = "upload_001";
            this.upload_001.Size = new System.Drawing.Size(200, 28);
            this.upload_001.TabIndex = 14;
            this.upload_001.Text = "1";
            // 
            // tabPage9
            // 
            this.tabPage9.Controls.Add(this.sac_getevent);
            this.tabPage9.Controls.Add(this.sac_delete01);
            this.tabPage9.Controls.Add(this.sac_delete02);
            this.tabPage9.Controls.Add(this.label173);
            this.tabPage9.Controls.Add(this.sac_init_people);
            this.tabPage9.Controls.Add(this.sac_delete_people);
            this.tabPage9.Controls.Add(this.label138);
            this.tabPage9.Controls.Add(this.label139);
            this.tabPage9.Controls.Add(this.p_g_02);
            this.tabPage9.Controls.Add(this.p_g_01);
            this.tabPage9.Controls.Add(this.p_g_btn2);
            this.tabPage9.Controls.Add(this.p_g_btn1);
            this.tabPage9.Controls.Add(this.label137);
            this.tabPage9.Controls.Add(this.label136);
            this.tabPage9.Controls.Add(this.sac_up_02);
            this.tabPage9.Controls.Add(this.sac_up_01);
            this.tabPage9.Controls.Add(this.sac_upload_group);
            this.tabPage9.Controls.Add(this.sac_get_group);
            this.tabPage9.Controls.Add(this.button20);
            this.tabPage9.Controls.Add(this.sac_e_09);
            this.tabPage9.Controls.Add(this.label135);
            this.tabPage9.Controls.Add(this.sac_e_10);
            this.tabPage9.Controls.Add(this.sac_e_08);
            this.tabPage9.Controls.Add(this.sac_e_07);
            this.tabPage9.Controls.Add(this.sac_e_06);
            this.tabPage9.Controls.Add(this.sac_e_05);
            this.tabPage9.Controls.Add(this.sac_e_04);
            this.tabPage9.Controls.Add(this.sac_e_03);
            this.tabPage9.Controls.Add(this.sac_e_02);
            this.tabPage9.Controls.Add(this.sac_e_01);
            this.tabPage9.Controls.Add(this.label126);
            this.tabPage9.Controls.Add(this.label127);
            this.tabPage9.Controls.Add(this.label128);
            this.tabPage9.Controls.Add(this.label129);
            this.tabPage9.Controls.Add(this.label130);
            this.tabPage9.Controls.Add(this.label131);
            this.tabPage9.Controls.Add(this.label132);
            this.tabPage9.Controls.Add(this.label133);
            this.tabPage9.Controls.Add(this.label134);
            this.tabPage9.Controls.Add(this.sac_get_employee);
            this.tabPage9.Controls.Add(this.listsac_employee);
            this.tabPage9.Location = new System.Drawing.Point(4, 28);
            this.tabPage9.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage9.Name = "tabPage9";
            this.tabPage9.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage9.Size = new System.Drawing.Size(1444, 501);
            this.tabPage9.TabIndex = 9;
            this.tabPage9.Text = "SAC_Dev01";
            this.tabPage9.UseVisualStyleBackColor = true;
            // 
            // sac_getevent
            // 
            this.sac_getevent.Location = new System.Drawing.Point(9, 108);
            this.sac_getevent.Margin = new System.Windows.Forms.Padding(4);
            this.sac_getevent.Name = "sac_getevent";
            this.sac_getevent.Size = new System.Drawing.Size(222, 60);
            this.sac_getevent.TabIndex = 58;
            this.sac_getevent.Text = "Get Event";
            this.sac_getevent.UseVisualStyleBackColor = true;
            this.sac_getevent.Click += new System.EventHandler(this.sac_getevent_Click);
            // 
            // sac_delete01
            // 
            this.sac_delete01.Location = new System.Drawing.Point(370, 124);
            this.sac_delete01.Margin = new System.Windows.Forms.Padding(4);
            this.sac_delete01.Name = "sac_delete01";
            this.sac_delete01.Size = new System.Drawing.Size(206, 28);
            this.sac_delete01.TabIndex = 57;
            this.sac_delete01.Text = "1";
            // 
            // sac_delete02
            // 
            this.sac_delete02.Location = new System.Drawing.Point(598, 124);
            this.sac_delete02.Margin = new System.Windows.Forms.Padding(4);
            this.sac_delete02.Name = "sac_delete02";
            this.sac_delete02.Size = new System.Drawing.Size(206, 28);
            this.sac_delete02.TabIndex = 56;
            this.sac_delete02.Text = "1";
            // 
            // label173
            // 
            this.label173.AutoSize = true;
            this.label173.Location = new System.Drawing.Point(232, 129);
            this.label173.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label173.Name = "label173";
            this.label173.Size = new System.Drawing.Size(89, 18);
            this.label173.TabIndex = 55;
            this.label173.Text = "Person ID";
            // 
            // sac_init_people
            // 
            this.sac_init_people.Location = new System.Drawing.Point(1098, 108);
            this.sac_init_people.Margin = new System.Windows.Forms.Padding(4);
            this.sac_init_people.Name = "sac_init_people";
            this.sac_init_people.Size = new System.Drawing.Size(254, 60);
            this.sac_init_people.TabIndex = 54;
            this.sac_init_people.Text = "Init People";
            this.sac_init_people.UseVisualStyleBackColor = true;
            this.sac_init_people.Click += new System.EventHandler(this.sac_init_people_Click);
            // 
            // sac_delete_people
            // 
            this.sac_delete_people.Location = new System.Drawing.Point(820, 108);
            this.sac_delete_people.Margin = new System.Windows.Forms.Padding(4);
            this.sac_delete_people.Name = "sac_delete_people";
            this.sac_delete_people.Size = new System.Drawing.Size(254, 60);
            this.sac_delete_people.TabIndex = 53;
            this.sac_delete_people.Text = "Delete People";
            this.sac_delete_people.UseVisualStyleBackColor = true;
            this.sac_delete_people.Click += new System.EventHandler(this.sac_delete_people_Click);
            // 
            // label138
            // 
            this.label138.AutoSize = true;
            this.label138.Location = new System.Drawing.Point(588, 68);
            this.label138.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label138.Name = "label138";
            this.label138.Size = new System.Drawing.Size(89, 18);
            this.label138.TabIndex = 52;
            this.label138.Text = "PersonId:";
            // 
            // label139
            // 
            this.label139.AutoSize = true;
            this.label139.Location = new System.Drawing.Point(416, 68);
            this.label139.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label139.Name = "label139";
            this.label139.Size = new System.Drawing.Size(80, 18);
            this.label139.TabIndex = 51;
            this.label139.Text = "GroupId:";
            // 
            // p_g_02
            // 
            this.p_g_02.Location = new System.Drawing.Point(711, 63);
            this.p_g_02.Margin = new System.Windows.Forms.Padding(4);
            this.p_g_02.Name = "p_g_02";
            this.p_g_02.Size = new System.Drawing.Size(468, 28);
            this.p_g_02.TabIndex = 50;
            this.p_g_02.Text = "1";
            // 
            // p_g_01
            // 
            this.p_g_01.Location = new System.Drawing.Point(504, 63);
            this.p_g_01.Margin = new System.Windows.Forms.Padding(4);
            this.p_g_01.Name = "p_g_01";
            this.p_g_01.Size = new System.Drawing.Size(73, 28);
            this.p_g_01.TabIndex = 49;
            this.p_g_01.Text = "1";
            // 
            // p_g_btn2
            // 
            this.p_g_btn2.Location = new System.Drawing.Point(1192, 54);
            this.p_g_btn2.Margin = new System.Windows.Forms.Padding(4);
            this.p_g_btn2.Name = "p_g_btn2";
            this.p_g_btn2.Size = new System.Drawing.Size(234, 45);
            this.p_g_btn2.TabIndex = 48;
            this.p_g_btn2.Text = "Upload_Employee_Group";
            this.p_g_btn2.UseVisualStyleBackColor = true;
            this.p_g_btn2.Click += new System.EventHandler(this.p_g_btn2_Click);
            // 
            // p_g_btn1
            // 
            this.p_g_btn1.Location = new System.Drawing.Point(9, 54);
            this.p_g_btn1.Margin = new System.Windows.Forms.Padding(4);
            this.p_g_btn1.Name = "p_g_btn1";
            this.p_g_btn1.Size = new System.Drawing.Size(398, 45);
            this.p_g_btn1.TabIndex = 47;
            this.p_g_btn1.Text = "Get_Employee_with_Group";
            this.p_g_btn1.UseVisualStyleBackColor = true;
            this.p_g_btn1.Click += new System.EventHandler(this.p_g_btn1_Click);
            // 
            // label137
            // 
            this.label137.AutoSize = true;
            this.label137.Location = new System.Drawing.Point(588, 14);
            this.label137.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label137.Name = "label137";
            this.label137.Size = new System.Drawing.Size(53, 18);
            this.label137.TabIndex = 46;
            this.label137.Text = "Name:";
            // 
            // label136
            // 
            this.label136.AutoSize = true;
            this.label136.Location = new System.Drawing.Point(416, 14);
            this.label136.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label136.Name = "label136";
            this.label136.Size = new System.Drawing.Size(80, 18);
            this.label136.TabIndex = 45;
            this.label136.Text = "GroupId:";
            // 
            // sac_up_02
            // 
            this.sac_up_02.Location = new System.Drawing.Point(712, 9);
            this.sac_up_02.Margin = new System.Windows.Forms.Padding(4);
            this.sac_up_02.Name = "sac_up_02";
            this.sac_up_02.Size = new System.Drawing.Size(466, 28);
            this.sac_up_02.TabIndex = 44;
            this.sac_up_02.Text = "GroupName";
            // 
            // sac_up_01
            // 
            this.sac_up_01.Location = new System.Drawing.Point(504, 9);
            this.sac_up_01.Margin = new System.Windows.Forms.Padding(4);
            this.sac_up_01.Name = "sac_up_01";
            this.sac_up_01.Size = new System.Drawing.Size(73, 28);
            this.sac_up_01.TabIndex = 43;
            this.sac_up_01.Text = "1";
            // 
            // sac_upload_group
            // 
            this.sac_upload_group.Location = new System.Drawing.Point(1192, 0);
            this.sac_upload_group.Margin = new System.Windows.Forms.Padding(4);
            this.sac_upload_group.Name = "sac_upload_group";
            this.sac_upload_group.Size = new System.Drawing.Size(234, 45);
            this.sac_upload_group.TabIndex = 42;
            this.sac_upload_group.Text = "SAC_Upload_Group";
            this.sac_upload_group.UseVisualStyleBackColor = true;
            this.sac_upload_group.Click += new System.EventHandler(this.sac_upload_group_Click);
            // 
            // sac_get_group
            // 
            this.sac_get_group.Location = new System.Drawing.Point(220, 0);
            this.sac_get_group.Margin = new System.Windows.Forms.Padding(4);
            this.sac_get_group.Name = "sac_get_group";
            this.sac_get_group.Size = new System.Drawing.Size(186, 45);
            this.sac_get_group.TabIndex = 41;
            this.sac_get_group.Text = "SAC_Get_all_Group";
            this.sac_get_group.UseVisualStyleBackColor = true;
            this.sac_get_group.Click += new System.EventHandler(this.sac_get_group_Click);
            // 
            // button20
            // 
            this.button20.Location = new System.Drawing.Point(1286, 170);
            this.button20.Margin = new System.Windows.Forms.Padding(4);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(141, 60);
            this.button20.TabIndex = 40;
            this.button20.Text = "Add/Modify";
            this.button20.UseVisualStyleBackColor = true;
            this.button20.Click += new System.EventHandler(this.button20_Click);
            // 
            // sac_e_09
            // 
            this.sac_e_09.Location = new System.Drawing.Point(1068, 195);
            this.sac_e_09.Margin = new System.Windows.Forms.Padding(4);
            this.sac_e_09.Name = "sac_e_09";
            this.sac_e_09.Size = new System.Drawing.Size(82, 28);
            this.sac_e_09.TabIndex = 39;
            this.sac_e_09.Text = "64";
            // 
            // label135
            // 
            this.label135.AutoSize = true;
            this.label135.Location = new System.Drawing.Point(1065, 170);
            this.label135.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label135.Name = "label135";
            this.label135.Size = new System.Drawing.Size(116, 18);
            this.label135.TabIndex = 38;
            this.label135.Text = "HolidayGroup";
            // 
            // sac_e_10
            // 
            this.sac_e_10.Location = new System.Drawing.Point(1192, 198);
            this.sac_e_10.Margin = new System.Windows.Forms.Padding(4);
            this.sac_e_10.Name = "sac_e_10";
            this.sac_e_10.Size = new System.Drawing.Size(82, 28);
            this.sac_e_10.TabIndex = 37;
            this.sac_e_10.Text = "64";
            // 
            // sac_e_08
            // 
            this.sac_e_08.Location = new System.Drawing.Point(970, 195);
            this.sac_e_08.Margin = new System.Windows.Forms.Padding(4);
            this.sac_e_08.Name = "sac_e_08";
            this.sac_e_08.Size = new System.Drawing.Size(82, 28);
            this.sac_e_08.TabIndex = 36;
            this.sac_e_08.Text = "0";
            // 
            // sac_e_07
            // 
            this.sac_e_07.Location = new System.Drawing.Point(880, 196);
            this.sac_e_07.Margin = new System.Windows.Forms.Padding(4);
            this.sac_e_07.Name = "sac_e_07";
            this.sac_e_07.Size = new System.Drawing.Size(82, 28);
            this.sac_e_07.TabIndex = 35;
            this.sac_e_07.Text = "6";
            // 
            // sac_e_06
            // 
            this.sac_e_06.Location = new System.Drawing.Point(790, 196);
            this.sac_e_06.Margin = new System.Windows.Forms.Padding(4);
            this.sac_e_06.Name = "sac_e_06";
            this.sac_e_06.Size = new System.Drawing.Size(82, 28);
            this.sac_e_06.TabIndex = 34;
            this.sac_e_06.Text = "2";
            // 
            // sac_e_05
            // 
            this.sac_e_05.Location = new System.Drawing.Point(712, 195);
            this.sac_e_05.Margin = new System.Windows.Forms.Padding(4);
            this.sac_e_05.Name = "sac_e_05";
            this.sac_e_05.Size = new System.Drawing.Size(67, 28);
            this.sac_e_05.TabIndex = 33;
            this.sac_e_05.Text = "0";
            // 
            // sac_e_04
            // 
            this.sac_e_04.Location = new System.Drawing.Point(560, 196);
            this.sac_e_04.Margin = new System.Windows.Forms.Padding(4);
            this.sac_e_04.Name = "sac_e_04";
            this.sac_e_04.Size = new System.Drawing.Size(142, 28);
            this.sac_e_04.TabIndex = 32;
            this.sac_e_04.Text = "1";
            // 
            // sac_e_03
            // 
            this.sac_e_03.Location = new System.Drawing.Point(432, 195);
            this.sac_e_03.Margin = new System.Windows.Forms.Padding(4);
            this.sac_e_03.Name = "sac_e_03";
            this.sac_e_03.Size = new System.Drawing.Size(116, 28);
            this.sac_e_03.TabIndex = 31;
            this.sac_e_03.Text = "1";
            // 
            // sac_e_02
            // 
            this.sac_e_02.Location = new System.Drawing.Point(220, 195);
            this.sac_e_02.Margin = new System.Windows.Forms.Padding(4);
            this.sac_e_02.Name = "sac_e_02";
            this.sac_e_02.Size = new System.Drawing.Size(200, 28);
            this.sac_e_02.TabIndex = 30;
            this.sac_e_02.Text = "1";
            // 
            // sac_e_01
            // 
            this.sac_e_01.Location = new System.Drawing.Point(3, 195);
            this.sac_e_01.Margin = new System.Windows.Forms.Padding(4);
            this.sac_e_01.Name = "sac_e_01";
            this.sac_e_01.Size = new System.Drawing.Size(206, 28);
            this.sac_e_01.TabIndex = 29;
            this.sac_e_01.Text = "1";
            // 
            // label126
            // 
            this.label126.AutoSize = true;
            this.label126.Location = new System.Drawing.Point(1190, 172);
            this.label126.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label126.Name = "label126";
            this.label126.Size = new System.Drawing.Size(71, 18);
            this.label126.TabIndex = 28;
            this.label126.Text = "Special";
            // 
            // label127
            // 
            this.label127.AutoSize = true;
            this.label127.Location = new System.Drawing.Point(968, 172);
            this.label127.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label127.Name = "label127";
            this.label127.Size = new System.Drawing.Size(89, 18);
            this.label127.TabIndex = 27;
            this.label127.Text = "Fp status";
            // 
            // label128
            // 
            this.label128.AutoSize = true;
            this.label128.Location = new System.Drawing.Point(878, 172);
            this.label128.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label128.Name = "label128";
            this.label128.Size = new System.Drawing.Size(44, 18);
            this.label128.TabIndex = 26;
            this.label128.Text = "Mode";
            // 
            // label129
            // 
            this.label129.AutoSize = true;
            this.label129.Location = new System.Drawing.Point(788, 170);
            this.label129.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label129.Name = "label129";
            this.label129.Size = new System.Drawing.Size(71, 18);
            this.label129.TabIndex = 25;
            this.label129.Text = "GroupId";
            // 
            // label130
            // 
            this.label130.AutoSize = true;
            this.label130.Location = new System.Drawing.Point(712, 174);
            this.label130.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label130.Name = "label130";
            this.label130.Size = new System.Drawing.Size(80, 18);
            this.label130.TabIndex = 24;
            this.label130.Text = "CardType";
            // 
            // label131
            // 
            this.label131.AutoSize = true;
            this.label131.Location = new System.Drawing.Point(570, 176);
            this.label131.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label131.Name = "label131";
            this.label131.Size = new System.Drawing.Size(71, 18);
            this.label131.TabIndex = 23;
            this.label131.Text = "Card ID";
            // 
            // label132
            // 
            this.label132.AutoSize = true;
            this.label132.Location = new System.Drawing.Point(428, 174);
            this.label132.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label132.Name = "label132";
            this.label132.Size = new System.Drawing.Size(80, 18);
            this.label132.TabIndex = 22;
            this.label132.Text = "Password";
            // 
            // label133
            // 
            this.label133.AutoSize = true;
            this.label133.Location = new System.Drawing.Point(232, 170);
            this.label133.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label133.Name = "label133";
            this.label133.Size = new System.Drawing.Size(44, 18);
            this.label133.TabIndex = 21;
            this.label133.Text = "Name";
            // 
            // label134
            // 
            this.label134.AutoSize = true;
            this.label134.Location = new System.Drawing.Point(0, 170);
            this.label134.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label134.Name = "label134";
            this.label134.Size = new System.Drawing.Size(89, 18);
            this.label134.TabIndex = 20;
            this.label134.Text = "Person ID";
            // 
            // sac_get_employee
            // 
            this.sac_get_employee.Location = new System.Drawing.Point(0, 0);
            this.sac_get_employee.Margin = new System.Windows.Forms.Padding(4);
            this.sac_get_employee.Name = "sac_get_employee";
            this.sac_get_employee.Size = new System.Drawing.Size(186, 45);
            this.sac_get_employee.TabIndex = 2;
            this.sac_get_employee.Text = "SAC_Get_all_person";
            this.sac_get_employee.UseVisualStyleBackColor = true;
            this.sac_get_employee.Click += new System.EventHandler(this.sac_get_employee_Click);
            // 
            // listsac_employee
            // 
            this.listsac_employee.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader22,
            this.columnHeader23,
            this.columnHeader24,
            this.columnHeader25,
            this.columnHeader26,
            this.columnHeader27,
            this.columnHeader28,
            this.columnHeader29,
            this.columnHeader30,
            this.columnHeader31,
            this.columnHeader34});
            this.listsac_employee.FullRowSelect = true;
            this.listsac_employee.GridLines = true;
            this.listsac_employee.Location = new System.Drawing.Point(4, 244);
            this.listsac_employee.Margin = new System.Windows.Forms.Padding(4);
            this.listsac_employee.Name = "listsac_employee";
            this.listsac_employee.Size = new System.Drawing.Size(1420, 204);
            this.listsac_employee.TabIndex = 1;
            this.listsac_employee.UseCompatibleStateImageBehavior = false;
            this.listsac_employee.View = System.Windows.Forms.View.Details;
            this.listsac_employee.SelectedIndexChanged += new System.EventHandler(this.select_sac_employee);
            // 
            // columnHeader22
            // 
            this.columnHeader22.Text = "No";
            // 
            // columnHeader23
            // 
            this.columnHeader23.Text = "Person ID";
            this.columnHeader23.Width = 100;
            // 
            // columnHeader24
            // 
            this.columnHeader24.Text = "Name";
            this.columnHeader24.Width = 123;
            // 
            // columnHeader25
            // 
            this.columnHeader25.Text = "Password";
            this.columnHeader25.Width = 83;
            // 
            // columnHeader26
            // 
            this.columnHeader26.Text = "Card ID";
            this.columnHeader26.Width = 113;
            // 
            // columnHeader27
            // 
            this.columnHeader27.Text = "CardType";
            this.columnHeader27.Width = 78;
            // 
            // columnHeader28
            // 
            this.columnHeader28.Text = "GroupID";
            // 
            // columnHeader29
            // 
            this.columnHeader29.Text = "AttendanceMode";
            this.columnHeader29.Width = 82;
            // 
            // columnHeader30
            // 
            this.columnHeader30.Text = "Fp status";
            this.columnHeader30.Width = 71;
            // 
            // columnHeader31
            // 
            this.columnHeader31.Text = "HolidayGroup";
            this.columnHeader31.Width = 102;
            // 
            // columnHeader34
            // 
            this.columnHeader34.Text = "Special";
            this.columnHeader34.Width = 68;
            // 
            // Bolid_Log
            // 
            this.Bolid_Log.Controls.Add(this.groupBox25);
            this.Bolid_Log.Location = new System.Drawing.Point(4, 28);
            this.Bolid_Log.Margin = new System.Windows.Forms.Padding(4);
            this.Bolid_Log.Name = "Bolid_Log";
            this.Bolid_Log.Padding = new System.Windows.Forms.Padding(4);
            this.Bolid_Log.Size = new System.Drawing.Size(1444, 501);
            this.Bolid_Log.TabIndex = 10;
            this.Bolid_Log.Text = "Log_Manage";
            this.Bolid_Log.UseVisualStyleBackColor = true;
            // 
            // groupBox25
            // 
            this.groupBox25.Controls.Add(this.label163);
            this.groupBox25.Controls.Add(this.log_auto_01);
            this.groupBox25.Controls.Add(this.log_auto_btn1);
            this.groupBox25.Controls.Add(this.log_auto_btn3);
            this.groupBox25.Controls.Add(this.log_auto_btn2);
            this.groupBox25.Controls.Add(this.log_manage_03);
            this.groupBox25.Controls.Add(this.log_manage_02);
            this.groupBox25.Controls.Add(this.log_manage_01);
            this.groupBox25.Controls.Add(this.label123);
            this.groupBox25.Controls.Add(this.log_number);
            this.groupBox25.Controls.Add(this.label124);
            this.groupBox25.Controls.Add(this.label125);
            this.groupBox25.Controls.Add(this.log_endtime);
            this.groupBox25.Controls.Add(this.log_begintime);
            this.groupBox25.Location = new System.Drawing.Point(3, 4);
            this.groupBox25.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox25.Name = "groupBox25";
            this.groupBox25.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox25.Size = new System.Drawing.Size(308, 430);
            this.groupBox25.TabIndex = 0;
            this.groupBox25.TabStop = false;
            this.groupBox25.Text = "Log_Manage";
            // 
            // label163
            // 
            this.label163.AutoSize = true;
            this.label163.Location = new System.Drawing.Point(9, 264);
            this.label163.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label163.Name = "label163";
            this.label163.Size = new System.Drawing.Size(125, 18);
            this.label163.TabIndex = 39;
            this.label163.Text = "Is open Auto:";
            // 
            // log_auto_01
            // 
            this.log_auto_01.Location = new System.Drawing.Point(142, 260);
            this.log_auto_01.Margin = new System.Windows.Forms.Padding(4);
            this.log_auto_01.Name = "log_auto_01";
            this.log_auto_01.Size = new System.Drawing.Size(154, 28);
            this.log_auto_01.TabIndex = 38;
            // 
            // log_auto_btn1
            // 
            this.log_auto_btn1.Location = new System.Drawing.Point(9, 300);
            this.log_auto_btn1.Margin = new System.Windows.Forms.Padding(4);
            this.log_auto_btn1.Name = "log_auto_btn1";
            this.log_auto_btn1.Size = new System.Drawing.Size(290, 34);
            this.log_auto_btn1.TabIndex = 37;
            this.log_auto_btn1.Text = "Get log auto status";
            this.log_auto_btn1.UseVisualStyleBackColor = true;
            this.log_auto_btn1.Click += new System.EventHandler(this.log_auto_btn1_Click);
            // 
            // log_auto_btn3
            // 
            this.log_auto_btn3.Location = new System.Drawing.Point(10, 387);
            this.log_auto_btn3.Margin = new System.Windows.Forms.Padding(4);
            this.log_auto_btn3.Name = "log_auto_btn3";
            this.log_auto_btn3.Size = new System.Drawing.Size(288, 34);
            this.log_auto_btn3.TabIndex = 36;
            this.log_auto_btn3.Text = "Close log auto live send";
            this.log_auto_btn3.UseVisualStyleBackColor = true;
            this.log_auto_btn3.Click += new System.EventHandler(this.log_auto_btn3_Click);
            // 
            // log_auto_btn2
            // 
            this.log_auto_btn2.Location = new System.Drawing.Point(10, 344);
            this.log_auto_btn2.Margin = new System.Windows.Forms.Padding(4);
            this.log_auto_btn2.Name = "log_auto_btn2";
            this.log_auto_btn2.Size = new System.Drawing.Size(288, 34);
            this.log_auto_btn2.TabIndex = 35;
            this.log_auto_btn2.Text = "Open log auto live send";
            this.log_auto_btn2.UseVisualStyleBackColor = true;
            this.log_auto_btn2.Click += new System.EventHandler(this.log_auto_btn2_Click);
            // 
            // log_manage_03
            // 
            this.log_manage_03.Location = new System.Drawing.Point(8, 213);
            this.log_manage_03.Margin = new System.Windows.Forms.Padding(4);
            this.log_manage_03.Name = "log_manage_03";
            this.log_manage_03.Size = new System.Drawing.Size(291, 34);
            this.log_manage_03.TabIndex = 34;
            this.log_manage_03.Text = "Remove Log by time";
            this.log_manage_03.UseVisualStyleBackColor = true;
            this.log_manage_03.Click += new System.EventHandler(this.log_manage_03_Click);
            // 
            // log_manage_02
            // 
            this.log_manage_02.Location = new System.Drawing.Point(6, 170);
            this.log_manage_02.Margin = new System.Windows.Forms.Padding(4);
            this.log_manage_02.Name = "log_manage_02";
            this.log_manage_02.Size = new System.Drawing.Size(292, 34);
            this.log_manage_02.TabIndex = 33;
            this.log_manage_02.Text = "Download Log  by time";
            this.log_manage_02.UseVisualStyleBackColor = true;
            this.log_manage_02.Click += new System.EventHandler(this.log_manage_02_Click);
            // 
            // log_manage_01
            // 
            this.log_manage_01.Location = new System.Drawing.Point(10, 126);
            this.log_manage_01.Margin = new System.Windows.Forms.Padding(4);
            this.log_manage_01.Name = "log_manage_01";
            this.log_manage_01.Size = new System.Drawing.Size(188, 34);
            this.log_manage_01.TabIndex = 32;
            this.log_manage_01.Text = "Get Number by time";
            this.log_manage_01.UseVisualStyleBackColor = true;
            this.log_manage_01.Click += new System.EventHandler(this.log_manage_01_Click);
            // 
            // label123
            // 
            this.label123.AutoSize = true;
            this.label123.Location = new System.Drawing.Point(8, 111);
            this.label123.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label123.Name = "label123";
            this.label123.Size = new System.Drawing.Size(0, 18);
            this.label123.TabIndex = 31;
            // 
            // log_number
            // 
            this.log_number.Location = new System.Drawing.Point(207, 129);
            this.log_number.Margin = new System.Windows.Forms.Padding(4);
            this.log_number.Name = "log_number";
            this.log_number.Size = new System.Drawing.Size(90, 28);
            this.log_number.TabIndex = 30;
            // 
            // label124
            // 
            this.label124.AutoSize = true;
            this.label124.Location = new System.Drawing.Point(8, 75);
            this.label124.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label124.Name = "label124";
            this.label124.Size = new System.Drawing.Size(89, 18);
            this.label124.TabIndex = 29;
            this.label124.Text = "end time:";
            // 
            // label125
            // 
            this.label125.AutoSize = true;
            this.label125.Location = new System.Drawing.Point(8, 34);
            this.label125.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label125.Name = "label125";
            this.label125.Size = new System.Drawing.Size(107, 18);
            this.label125.TabIndex = 28;
            this.label125.Text = "start time:";
            // 
            // log_endtime
            // 
            this.log_endtime.Location = new System.Drawing.Point(112, 70);
            this.log_endtime.Margin = new System.Windows.Forms.Padding(4);
            this.log_endtime.Name = "log_endtime";
            this.log_endtime.Size = new System.Drawing.Size(184, 28);
            this.log_endtime.TabIndex = 27;
            this.log_endtime.Text = "2019-04-01 00:00:00";
            // 
            // log_begintime
            // 
            this.log_begintime.Location = new System.Drawing.Point(112, 30);
            this.log_begintime.Margin = new System.Windows.Forms.Padding(4);
            this.log_begintime.Name = "log_begintime";
            this.log_begintime.Size = new System.Drawing.Size(184, 28);
            this.log_begintime.TabIndex = 26;
            this.log_begintime.Text = "2019-01-01 00:00:00";
            // 
            // tabPage10
            // 
            this.tabPage10.Controls.Add(this.gettimeframe);
            this.tabPage10.Controls.Add(this.sac_set);
            this.tabPage10.Controls.Add(this.sac_get);
            this.tabPage10.Controls.Add(this.sac_sac05);
            this.tabPage10.Controls.Add(this.label162);
            this.tabPage10.Controls.Add(this.sac_sac04);
            this.tabPage10.Controls.Add(this.label161);
            this.tabPage10.Controls.Add(this.sac_sac03);
            this.tabPage10.Controls.Add(this.label160);
            this.tabPage10.Controls.Add(this.sac_sac02);
            this.tabPage10.Controls.Add(this.label159);
            this.tabPage10.Controls.Add(this.sac_sac01);
            this.tabPage10.Controls.Add(this.label158);
            this.tabPage10.Controls.Add(this.label156);
            this.tabPage10.Controls.Add(this.label157);
            this.tabPage10.Controls.Add(this.time_g_02);
            this.tabPage10.Controls.Add(this.time_g_01);
            this.tabPage10.Controls.Add(this.uptimegroup);
            this.tabPage10.Controls.Add(this.downtimegroup);
            this.tabPage10.Controls.Add(this.updoorgroup);
            this.tabPage10.Controls.Add(this.downdoorgroup);
            this.tabPage10.Controls.Add(this.label154);
            this.tabPage10.Controls.Add(this.label155);
            this.tabPage10.Controls.Add(this.door_g_02);
            this.tabPage10.Controls.Add(this.door_g_01);
            this.tabPage10.Controls.Add(this.button26);
            this.tabPage10.Controls.Add(this.button25);
            this.tabPage10.Controls.Add(this.updoor_group);
            this.tabPage10.Controls.Add(this.button23);
            this.tabPage10.Controls.Add(this.door_group);
            this.tabPage10.Controls.Add(this.time03);
            this.tabPage10.Controls.Add(this.label153);
            this.tabPage10.Controls.Add(this.time02);
            this.tabPage10.Controls.Add(this.label152);
            this.tabPage10.Controls.Add(this.time01);
            this.tabPage10.Controls.Add(this.label151);
            this.tabPage10.Controls.Add(this.door03);
            this.tabPage10.Controls.Add(this.label150);
            this.tabPage10.Controls.Add(this.door02);
            this.tabPage10.Controls.Add(this.label149);
            this.tabPage10.Controls.Add(this.door01);
            this.tabPage10.Controls.Add(this.label148);
            this.tabPage10.Controls.Add(this.sac_time00);
            this.tabPage10.Controls.Add(this.settimeframe);
            this.tabPage10.Controls.Add(this.label147);
            this.tabPage10.Controls.Add(this.sac_time01);
            this.tabPage10.Controls.Add(this.sac_door);
            this.tabPage10.Controls.Add(this.sac_1006);
            this.tabPage10.Controls.Add(this.label146);
            this.tabPage10.Controls.Add(this.sac_1007);
            this.tabPage10.Controls.Add(this.label145);
            this.tabPage10.Controls.Add(this.sac_1005);
            this.tabPage10.Controls.Add(this.label144);
            this.tabPage10.Controls.Add(this.sac_1004);
            this.tabPage10.Controls.Add(this.label143);
            this.tabPage10.Controls.Add(this.sac_1003);
            this.tabPage10.Controls.Add(this.label142);
            this.tabPage10.Controls.Add(this.sac_1002);
            this.tabPage10.Controls.Add(this.label141);
            this.tabPage10.Controls.Add(this.sac_1001);
            this.tabPage10.Controls.Add(this.label140);
            this.tabPage10.Location = new System.Drawing.Point(4, 28);
            this.tabPage10.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage10.Name = "tabPage10";
            this.tabPage10.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage10.Size = new System.Drawing.Size(1444, 501);
            this.tabPage10.TabIndex = 11;
            this.tabPage10.Text = "SAC_Dev02";
            this.tabPage10.UseVisualStyleBackColor = true;
            // 
            // gettimeframe
            // 
            this.gettimeframe.Location = new System.Drawing.Point(1144, 70);
            this.gettimeframe.Margin = new System.Windows.Forms.Padding(4);
            this.gettimeframe.Name = "gettimeframe";
            this.gettimeframe.Size = new System.Drawing.Size(141, 33);
            this.gettimeframe.TabIndex = 90;
            this.gettimeframe.Text = "GetTimeFrame";
            this.gettimeframe.UseVisualStyleBackColor = true;
            this.gettimeframe.Click += new System.EventHandler(this.gettimeframe_Click);
            // 
            // sac_set
            // 
            this.sac_set.Location = new System.Drawing.Point(1278, 279);
            this.sac_set.Margin = new System.Windows.Forms.Padding(4);
            this.sac_set.Name = "sac_set";
            this.sac_set.Size = new System.Drawing.Size(141, 58);
            this.sac_set.TabIndex = 89;
            this.sac_set.Text = "UploadAccessControlGroup";
            this.sac_set.UseVisualStyleBackColor = true;
            this.sac_set.Click += new System.EventHandler(this.sac_set_Click);
            // 
            // sac_get
            // 
            this.sac_get.Location = new System.Drawing.Point(1119, 278);
            this.sac_get.Margin = new System.Windows.Forms.Padding(4);
            this.sac_get.Name = "sac_get";
            this.sac_get.Size = new System.Drawing.Size(141, 60);
            this.sac_get.TabIndex = 88;
            this.sac_get.Text = "DownloadAccessControlGroup";
            this.sac_get.UseVisualStyleBackColor = true;
            this.sac_get.Click += new System.EventHandler(this.sac_get_Click);
            // 
            // sac_sac05
            // 
            this.sac_sac05.Location = new System.Drawing.Point(998, 302);
            this.sac_sac05.Margin = new System.Windows.Forms.Padding(4);
            this.sac_sac05.Name = "sac_sac05";
            this.sac_sac05.Size = new System.Drawing.Size(84, 28);
            this.sac_sac05.TabIndex = 87;
            this.sac_sac05.Text = "1";
            // 
            // label162
            // 
            this.label162.AutoSize = true;
            this.label162.Location = new System.Drawing.Point(994, 279);
            this.label162.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label162.Name = "label162";
            this.label162.Size = new System.Drawing.Size(107, 18);
            this.label162.TabIndex = 86;
            this.label162.Text = "TimeGroupId";
            // 
            // sac_sac04
            // 
            this.sac_sac04.Location = new System.Drawing.Point(836, 302);
            this.sac_sac04.Margin = new System.Windows.Forms.Padding(4);
            this.sac_sac04.Name = "sac_sac04";
            this.sac_sac04.Size = new System.Drawing.Size(84, 28);
            this.sac_sac04.TabIndex = 85;
            this.sac_sac04.Text = "1";
            // 
            // label161
            // 
            this.label161.AutoSize = true;
            this.label161.Location = new System.Drawing.Point(832, 279);
            this.label161.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label161.Name = "label161";
            this.label161.Size = new System.Drawing.Size(107, 18);
            this.label161.TabIndex = 84;
            this.label161.Text = "DoorGroupId";
            // 
            // sac_sac03
            // 
            this.sac_sac03.Location = new System.Drawing.Point(669, 302);
            this.sac_sac03.Margin = new System.Windows.Forms.Padding(4);
            this.sac_sac03.Name = "sac_sac03";
            this.sac_sac03.Size = new System.Drawing.Size(84, 28);
            this.sac_sac03.TabIndex = 83;
            this.sac_sac03.Text = "1";
            // 
            // label160
            // 
            this.label160.AutoSize = true;
            this.label160.Location = new System.Drawing.Point(666, 279);
            this.label160.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label160.Name = "label160";
            this.label160.Size = new System.Drawing.Size(143, 18);
            this.label160.TabIndex = 82;
            this.label160.Text = "EmployeeGroupId";
            // 
            // sac_sac02
            // 
            this.sac_sac02.Location = new System.Drawing.Point(140, 302);
            this.sac_sac02.Margin = new System.Windows.Forms.Padding(4);
            this.sac_sac02.Name = "sac_sac02";
            this.sac_sac02.Size = new System.Drawing.Size(502, 28);
            this.sac_sac02.TabIndex = 81;
            this.sac_sac02.Text = "1";
            // 
            // label159
            // 
            this.label159.AutoSize = true;
            this.label159.Location = new System.Drawing.Point(136, 279);
            this.label159.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label159.Name = "label159";
            this.label159.Size = new System.Drawing.Size(89, 18);
            this.label159.TabIndex = 80;
            this.label159.Text = "GroupName";
            // 
            // sac_sac01
            // 
            this.sac_sac01.Location = new System.Drawing.Point(8, 302);
            this.sac_sac01.Margin = new System.Windows.Forms.Padding(4);
            this.sac_sac01.Name = "sac_sac01";
            this.sac_sac01.Size = new System.Drawing.Size(84, 28);
            this.sac_sac01.TabIndex = 79;
            this.sac_sac01.Text = "1";
            // 
            // label158
            // 
            this.label158.AutoSize = true;
            this.label158.Location = new System.Drawing.Point(4, 279);
            this.label158.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label158.Name = "label158";
            this.label158.Size = new System.Drawing.Size(107, 18);
            this.label158.TabIndex = 78;
            this.label158.Text = "SAC_GroupId";
            // 
            // label156
            // 
            this.label156.AutoSize = true;
            this.label156.Location = new System.Drawing.Point(182, 248);
            this.label156.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label156.Name = "label156";
            this.label156.Size = new System.Drawing.Size(53, 18);
            this.label156.TabIndex = 77;
            this.label156.Text = "Name:";
            // 
            // label157
            // 
            this.label157.AutoSize = true;
            this.label157.Location = new System.Drawing.Point(9, 248);
            this.label157.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label157.Name = "label157";
            this.label157.Size = new System.Drawing.Size(80, 18);
            this.label157.TabIndex = 76;
            this.label157.Text = "GroupId:";
            // 
            // time_g_02
            // 
            this.time_g_02.Location = new System.Drawing.Point(306, 243);
            this.time_g_02.Margin = new System.Windows.Forms.Padding(4);
            this.time_g_02.Name = "time_g_02";
            this.time_g_02.Size = new System.Drawing.Size(751, 28);
            this.time_g_02.TabIndex = 75;
            this.time_g_02.Text = "GroupName";
            // 
            // time_g_01
            // 
            this.time_g_01.Location = new System.Drawing.Point(98, 243);
            this.time_g_01.Margin = new System.Windows.Forms.Padding(4);
            this.time_g_01.Name = "time_g_01";
            this.time_g_01.Size = new System.Drawing.Size(73, 28);
            this.time_g_01.TabIndex = 74;
            this.time_g_01.Text = "1";
            // 
            // uptimegroup
            // 
            this.uptimegroup.Location = new System.Drawing.Point(1278, 240);
            this.uptimegroup.Margin = new System.Windows.Forms.Padding(4);
            this.uptimegroup.Name = "uptimegroup";
            this.uptimegroup.Size = new System.Drawing.Size(141, 33);
            this.uptimegroup.TabIndex = 73;
            this.uptimegroup.Text = "uptimegroup";
            this.uptimegroup.UseVisualStyleBackColor = true;
            this.uptimegroup.Click += new System.EventHandler(this.uptimegroup_Click);
            // 
            // downtimegroup
            // 
            this.downtimegroup.Location = new System.Drawing.Point(1119, 240);
            this.downtimegroup.Margin = new System.Windows.Forms.Padding(4);
            this.downtimegroup.Name = "downtimegroup";
            this.downtimegroup.Size = new System.Drawing.Size(141, 33);
            this.downtimegroup.TabIndex = 72;
            this.downtimegroup.Text = "downtimegroup";
            this.downtimegroup.UseVisualStyleBackColor = true;
            this.downtimegroup.Click += new System.EventHandler(this.downtimegroup_Click);
            // 
            // updoorgroup
            // 
            this.updoorgroup.Location = new System.Drawing.Point(1278, 195);
            this.updoorgroup.Margin = new System.Windows.Forms.Padding(4);
            this.updoorgroup.Name = "updoorgroup";
            this.updoorgroup.Size = new System.Drawing.Size(141, 33);
            this.updoorgroup.TabIndex = 71;
            this.updoorgroup.Text = "updoorgroup";
            this.updoorgroup.UseVisualStyleBackColor = true;
            this.updoorgroup.Click += new System.EventHandler(this.updoorgroup_Click);
            // 
            // downdoorgroup
            // 
            this.downdoorgroup.Location = new System.Drawing.Point(1119, 198);
            this.downdoorgroup.Margin = new System.Windows.Forms.Padding(4);
            this.downdoorgroup.Name = "downdoorgroup";
            this.downdoorgroup.Size = new System.Drawing.Size(141, 33);
            this.downdoorgroup.TabIndex = 70;
            this.downdoorgroup.Text = "downdoorgroup";
            this.downdoorgroup.UseVisualStyleBackColor = true;
            this.downdoorgroup.Click += new System.EventHandler(this.downdoorgroup_Click);
            // 
            // label154
            // 
            this.label154.AutoSize = true;
            this.label154.Location = new System.Drawing.Point(182, 206);
            this.label154.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label154.Name = "label154";
            this.label154.Size = new System.Drawing.Size(53, 18);
            this.label154.TabIndex = 69;
            this.label154.Text = "Name:";
            // 
            // label155
            // 
            this.label155.AutoSize = true;
            this.label155.Location = new System.Drawing.Point(9, 206);
            this.label155.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label155.Name = "label155";
            this.label155.Size = new System.Drawing.Size(80, 18);
            this.label155.TabIndex = 68;
            this.label155.Text = "GroupId:";
            // 
            // door_g_02
            // 
            this.door_g_02.Location = new System.Drawing.Point(306, 201);
            this.door_g_02.Margin = new System.Windows.Forms.Padding(4);
            this.door_g_02.Name = "door_g_02";
            this.door_g_02.Size = new System.Drawing.Size(751, 28);
            this.door_g_02.TabIndex = 67;
            this.door_g_02.Text = "GroupName";
            // 
            // door_g_01
            // 
            this.door_g_01.Location = new System.Drawing.Point(98, 201);
            this.door_g_01.Margin = new System.Windows.Forms.Padding(4);
            this.door_g_01.Name = "door_g_01";
            this.door_g_01.Size = new System.Drawing.Size(73, 28);
            this.door_g_01.TabIndex = 66;
            this.door_g_01.Text = "1";
            // 
            // button26
            // 
            this.button26.Location = new System.Drawing.Point(75, 8);
            this.button26.Margin = new System.Windows.Forms.Padding(4);
            this.button26.Name = "button26";
            this.button26.Size = new System.Drawing.Size(75, 60);
            this.button26.TabIndex = 65;
            this.button26.Text = "Get Door";
            this.button26.UseVisualStyleBackColor = true;
            this.button26.Click += new System.EventHandler(this.button26_Click);
            // 
            // button25
            // 
            this.button25.Location = new System.Drawing.Point(968, 153);
            this.button25.Margin = new System.Windows.Forms.Padding(4);
            this.button25.Name = "button25";
            this.button25.Size = new System.Drawing.Size(452, 33);
            this.button25.TabIndex = 64;
            this.button25.Text = "Upload time_with_timegroup";
            this.button25.UseVisualStyleBackColor = true;
            this.button25.Click += new System.EventHandler(this.button25_Click);
            // 
            // updoor_group
            // 
            this.updoor_group.Location = new System.Drawing.Point(968, 117);
            this.updoor_group.Margin = new System.Windows.Forms.Padding(4);
            this.updoor_group.Name = "updoor_group";
            this.updoor_group.Size = new System.Drawing.Size(452, 33);
            this.updoor_group.TabIndex = 63;
            this.updoor_group.Text = "Upload door_with_doorgroup";
            this.updoor_group.UseVisualStyleBackColor = true;
            this.updoor_group.Click += new System.EventHandler(this.updoor_group_Click);
            // 
            // button23
            // 
            this.button23.Location = new System.Drawing.Point(560, 156);
            this.button23.Margin = new System.Windows.Forms.Padding(4);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(370, 33);
            this.button23.TabIndex = 62;
            this.button23.Text = "Download time_with_timegroup";
            this.button23.UseVisualStyleBackColor = true;
            this.button23.Click += new System.EventHandler(this.button23_Click);
            // 
            // door_group
            // 
            this.door_group.Location = new System.Drawing.Point(560, 117);
            this.door_group.Margin = new System.Windows.Forms.Padding(4);
            this.door_group.Name = "door_group";
            this.door_group.Size = new System.Drawing.Size(370, 33);
            this.door_group.TabIndex = 61;
            this.door_group.Text = "Download door_with_doorgroup";
            this.door_group.UseVisualStyleBackColor = true;
            this.door_group.Click += new System.EventHandler(this.door_group_Click);
            // 
            // time03
            // 
            this.time03.Location = new System.Drawing.Point(459, 160);
            this.time03.Margin = new System.Windows.Forms.Padding(4);
            this.time03.Name = "time03";
            this.time03.Size = new System.Drawing.Size(50, 28);
            this.time03.TabIndex = 60;
            this.time03.Text = "1";
            // 
            // label153
            // 
            this.label153.AutoSize = true;
            this.label153.Location = new System.Drawing.Point(352, 160);
            this.label153.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label153.Name = "label153";
            this.label153.Size = new System.Drawing.Size(98, 18);
            this.label153.TabIndex = 59;
            this.label153.Text = "TimeFrame:";
            // 
            // time02
            // 
            this.time02.Location = new System.Drawing.Point(285, 156);
            this.time02.Margin = new System.Windows.Forms.Padding(4);
            this.time02.Name = "time02";
            this.time02.Size = new System.Drawing.Size(56, 28);
            this.time02.TabIndex = 58;
            this.time02.Text = "1";
            // 
            // label152
            // 
            this.label152.AutoSize = true;
            this.label152.Location = new System.Drawing.Point(178, 160);
            this.label152.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label152.Name = "label152";
            this.label152.Size = new System.Drawing.Size(98, 18);
            this.label152.TabIndex = 57;
            this.label152.Text = "TimeFrame:";
            // 
            // time01
            // 
            this.time01.Location = new System.Drawing.Point(111, 156);
            this.time01.Margin = new System.Windows.Forms.Padding(4);
            this.time01.Name = "time01";
            this.time01.Size = new System.Drawing.Size(56, 28);
            this.time01.TabIndex = 56;
            this.time01.Text = "1";
            // 
            // label151
            // 
            this.label151.AutoSize = true;
            this.label151.Location = new System.Drawing.Point(4, 160);
            this.label151.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label151.Name = "label151";
            this.label151.Size = new System.Drawing.Size(98, 18);
            this.label151.TabIndex = 55;
            this.label151.Text = "TimeFrame:";
            // 
            // door03
            // 
            this.door03.Location = new System.Drawing.Point(459, 120);
            this.door03.Margin = new System.Windows.Forms.Padding(4);
            this.door03.Name = "door03";
            this.door03.Size = new System.Drawing.Size(50, 28);
            this.door03.TabIndex = 54;
            this.door03.Text = "1";
            // 
            // label150
            // 
            this.label150.AutoSize = true;
            this.label150.Location = new System.Drawing.Point(352, 124);
            this.label150.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label150.Name = "label150";
            this.label150.Size = new System.Drawing.Size(98, 18);
            this.label150.TabIndex = 53;
            this.label150.Text = "TimeFrame:";
            // 
            // door02
            // 
            this.door02.Location = new System.Drawing.Point(285, 120);
            this.door02.Margin = new System.Windows.Forms.Padding(4);
            this.door02.Name = "door02";
            this.door02.Size = new System.Drawing.Size(56, 28);
            this.door02.TabIndex = 52;
            this.door02.Text = "1";
            // 
            // label149
            // 
            this.label149.AutoSize = true;
            this.label149.Location = new System.Drawing.Point(178, 124);
            this.label149.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label149.Name = "label149";
            this.label149.Size = new System.Drawing.Size(98, 18);
            this.label149.TabIndex = 51;
            this.label149.Text = "TimeFrame:";
            // 
            // door01
            // 
            this.door01.Location = new System.Drawing.Point(116, 120);
            this.door01.Margin = new System.Windows.Forms.Padding(4);
            this.door01.Name = "door01";
            this.door01.Size = new System.Drawing.Size(52, 28);
            this.door01.TabIndex = 50;
            this.door01.Text = "1";
            // 
            // label148
            // 
            this.label148.AutoSize = true;
            this.label148.Location = new System.Drawing.Point(9, 124);
            this.label148.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label148.Name = "label148";
            this.label148.Size = new System.Drawing.Size(98, 18);
            this.label148.TabIndex = 49;
            this.label148.Text = "TimeFrame:";
            // 
            // sac_time00
            // 
            this.sac_time00.Location = new System.Drawing.Point(116, 70);
            this.sac_time00.Margin = new System.Windows.Forms.Padding(4);
            this.sac_time00.Name = "sac_time00";
            this.sac_time00.Size = new System.Drawing.Size(84, 28);
            this.sac_time00.TabIndex = 48;
            this.sac_time00.Text = "1";
            // 
            // settimeframe
            // 
            this.settimeframe.Location = new System.Drawing.Point(1294, 70);
            this.settimeframe.Margin = new System.Windows.Forms.Padding(4);
            this.settimeframe.Name = "settimeframe";
            this.settimeframe.Size = new System.Drawing.Size(141, 33);
            this.settimeframe.TabIndex = 47;
            this.settimeframe.Text = "SetTimeFrame";
            this.settimeframe.UseVisualStyleBackColor = true;
            this.settimeframe.Click += new System.EventHandler(this.settimeframe_Click);
            // 
            // label147
            // 
            this.label147.AutoSize = true;
            this.label147.Location = new System.Drawing.Point(9, 75);
            this.label147.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label147.Name = "label147";
            this.label147.Size = new System.Drawing.Size(98, 18);
            this.label147.TabIndex = 46;
            this.label147.Text = "TimeFrame:";
            // 
            // sac_time01
            // 
            this.sac_time01.Location = new System.Drawing.Point(228, 70);
            this.sac_time01.Margin = new System.Windows.Forms.Padding(4);
            this.sac_time01.Name = "sac_time01";
            this.sac_time01.Size = new System.Drawing.Size(906, 28);
            this.sac_time01.TabIndex = 45;
            // 
            // sac_door
            // 
            this.sac_door.Location = new System.Drawing.Point(1294, 8);
            this.sac_door.Margin = new System.Windows.Forms.Padding(4);
            this.sac_door.Name = "sac_door";
            this.sac_door.Size = new System.Drawing.Size(141, 60);
            this.sac_door.TabIndex = 44;
            this.sac_door.Text = "Set Door";
            this.sac_door.UseVisualStyleBackColor = true;
            this.sac_door.Click += new System.EventHandler(this.sac_door_Click);
            // 
            // sac_1006
            // 
            this.sac_1006.Location = new System.Drawing.Point(1098, 32);
            this.sac_1006.Margin = new System.Windows.Forms.Padding(4);
            this.sac_1006.Name = "sac_1006";
            this.sac_1006.Size = new System.Drawing.Size(84, 28);
            this.sac_1006.TabIndex = 43;
            this.sac_1006.Text = "1";
            // 
            // label146
            // 
            this.label146.AutoSize = true;
            this.label146.Location = new System.Drawing.Point(1048, 9);
            this.label146.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label146.Name = "label146";
            this.label146.Size = new System.Drawing.Size(143, 18);
            this.label146.TabIndex = 42;
            this.label146.Text = "InterlockDoorId";
            // 
            // sac_1007
            // 
            this.sac_1007.Location = new System.Drawing.Point(1203, 32);
            this.sac_1007.Margin = new System.Windows.Forms.Padding(4);
            this.sac_1007.Name = "sac_1007";
            this.sac_1007.Size = new System.Drawing.Size(84, 28);
            this.sac_1007.TabIndex = 41;
            this.sac_1007.Text = "1";
            // 
            // label145
            // 
            this.label145.AutoSize = true;
            this.label145.Location = new System.Drawing.Point(1200, 9);
            this.label145.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label145.Name = "label145";
            this.label145.Size = new System.Drawing.Size(98, 18);
            this.label145.TabIndex = 40;
            this.label145.Text = "DoorStatus";
            // 
            // sac_1005
            // 
            this.sac_1005.Location = new System.Drawing.Point(974, 30);
            this.sac_1005.Margin = new System.Windows.Forms.Padding(4);
            this.sac_1005.Name = "sac_1005";
            this.sac_1005.Size = new System.Drawing.Size(84, 28);
            this.sac_1005.TabIndex = 39;
            this.sac_1005.Text = "1";
            // 
            // label144
            // 
            this.label144.AutoSize = true;
            this.label144.Location = new System.Drawing.Point(915, 9);
            this.label144.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label144.Name = "label144";
            this.label144.Size = new System.Drawing.Size(125, 18);
            this.label144.TabIndex = 38;
            this.label144.Text = "InterlockFlag";
            // 
            // sac_1004
            // 
            this.sac_1004.Location = new System.Drawing.Point(862, 30);
            this.sac_1004.Margin = new System.Windows.Forms.Padding(4);
            this.sac_1004.Name = "sac_1004";
            this.sac_1004.Size = new System.Drawing.Size(84, 28);
            this.sac_1004.TabIndex = 37;
            this.sac_1004.Text = "1";
            this.sac_1004.TextChanged += new System.EventHandler(this.textBox6_TextChanged);
            // 
            // label143
            // 
            this.label143.AutoSize = true;
            this.label143.Location = new System.Drawing.Point(782, 9);
            this.label143.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label143.Name = "label143";
            this.label143.Size = new System.Drawing.Size(116, 18);
            this.label143.TabIndex = 36;
            this.label143.Text = "Anti_subType";
            // 
            // sac_1003
            // 
            this.sac_1003.Location = new System.Drawing.Point(518, 30);
            this.sac_1003.Margin = new System.Windows.Forms.Padding(4);
            this.sac_1003.Name = "sac_1003";
            this.sac_1003.Size = new System.Drawing.Size(313, 28);
            this.sac_1003.TabIndex = 35;
            this.sac_1003.Text = "1";
            // 
            // label142
            // 
            this.label142.AutoSize = true;
            this.label142.Location = new System.Drawing.Point(514, 8);
            this.label142.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label142.Name = "label142";
            this.label142.Size = new System.Drawing.Size(71, 18);
            this.label142.TabIndex = 34;
            this.label142.Text = "DevName";
            // 
            // sac_1002
            // 
            this.sac_1002.Location = new System.Drawing.Point(159, 30);
            this.sac_1002.Margin = new System.Windows.Forms.Padding(4);
            this.sac_1002.Name = "sac_1002";
            this.sac_1002.Size = new System.Drawing.Size(348, 28);
            this.sac_1002.TabIndex = 33;
            this.sac_1002.Text = "1";
            // 
            // label141
            // 
            this.label141.AutoSize = true;
            this.label141.Location = new System.Drawing.Point(159, 8);
            this.label141.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label141.Name = "label141";
            this.label141.Size = new System.Drawing.Size(80, 18);
            this.label141.TabIndex = 32;
            this.label141.Text = "DoorName";
            // 
            // sac_1001
            // 
            this.sac_1001.Location = new System.Drawing.Point(8, 30);
            this.sac_1001.Margin = new System.Windows.Forms.Padding(4);
            this.sac_1001.Name = "sac_1001";
            this.sac_1001.Size = new System.Drawing.Size(56, 28);
            this.sac_1001.TabIndex = 31;
            this.sac_1001.Text = "1";
            // 
            // label140
            // 
            this.label140.AutoSize = true;
            this.label140.Location = new System.Drawing.Point(4, 8);
            this.label140.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label140.Name = "label140";
            this.label140.Size = new System.Drawing.Size(62, 18);
            this.label140.TabIndex = 30;
            this.label140.Text = "DoorId";
            // 
            // tabPage11
            // 
            this.tabPage11.Controls.Add(this.label167);
            this.tabPage11.Controls.Add(this.pictureBox1);
            this.tabPage11.Controls.Add(this.label166);
            this.tabPage11.Controls.Add(this.label165);
            this.tabPage11.Controls.Add(this.pic_delpic);
            this.tabPage11.Controls.Add(this.pic_getpic);
            this.tabPage11.Controls.Add(this.pic_time);
            this.tabPage11.Controls.Add(this.pic_eid);
            this.tabPage11.Controls.Add(this.pic_gethead);
            this.tabPage11.Controls.Add(this.label164);
            this.tabPage11.Controls.Add(this.pic_num);
            this.tabPage11.Controls.Add(this.pic_getnum);
            this.tabPage11.Location = new System.Drawing.Point(4, 28);
            this.tabPage11.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage11.Name = "tabPage11";
            this.tabPage11.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage11.Size = new System.Drawing.Size(1444, 501);
            this.tabPage11.TabIndex = 12;
            this.tabPage11.Text = "OA1000-Picture";
            this.tabPage11.UseVisualStyleBackColor = true;
            // 
            // label167
            // 
            this.label167.AutoSize = true;
            this.label167.Location = new System.Drawing.Point(0, 14);
            this.label167.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label167.Name = "label167";
            this.label167.Size = new System.Drawing.Size(170, 18);
            this.label167.TabIndex = 55;
            this.label167.Text = "Page for OA1000?? ";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(267, 4);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(750, 434);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 54;
            this.pictureBox1.TabStop = false;
            // 
            // label166
            // 
            this.label166.AutoSize = true;
            this.label166.Location = new System.Drawing.Point(1023, 152);
            this.label166.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label166.Name = "label166";
            this.label166.Size = new System.Drawing.Size(98, 18);
            this.label166.TabIndex = 53;
            this.label166.Text = "Date Time:";
            // 
            // label165
            // 
            this.label165.AutoSize = true;
            this.label165.Location = new System.Drawing.Point(1023, 111);
            this.label165.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label165.Name = "label165";
            this.label165.Size = new System.Drawing.Size(116, 18);
            this.label165.TabIndex = 52;
            this.label165.Text = "Employee Id:";
            // 
            // pic_delpic
            // 
            this.pic_delpic.Location = new System.Drawing.Point(1236, 188);
            this.pic_delpic.Margin = new System.Windows.Forms.Padding(4);
            this.pic_delpic.Name = "pic_delpic";
            this.pic_delpic.Size = new System.Drawing.Size(201, 45);
            this.pic_delpic.TabIndex = 51;
            this.pic_delpic.Text = "Delete Picture";
            this.pic_delpic.UseVisualStyleBackColor = true;
            this.pic_delpic.Click += new System.EventHandler(this.pic_delpic_Click);
            // 
            // pic_getpic
            // 
            this.pic_getpic.Location = new System.Drawing.Point(1026, 188);
            this.pic_getpic.Margin = new System.Windows.Forms.Padding(4);
            this.pic_getpic.Name = "pic_getpic";
            this.pic_getpic.Size = new System.Drawing.Size(201, 45);
            this.pic_getpic.TabIndex = 50;
            this.pic_getpic.Text = "Get Picture";
            this.pic_getpic.UseVisualStyleBackColor = true;
            this.pic_getpic.Click += new System.EventHandler(this.pic_getpic_Click);
            // 
            // pic_time
            // 
            this.pic_time.Location = new System.Drawing.Point(1174, 147);
            this.pic_time.Margin = new System.Windows.Forms.Padding(4);
            this.pic_time.Name = "pic_time";
            this.pic_time.Size = new System.Drawing.Size(254, 28);
            this.pic_time.TabIndex = 49;
            this.pic_time.Text = "2019-04-10 15:25:37";
            // 
            // pic_eid
            // 
            this.pic_eid.Location = new System.Drawing.Point(1174, 106);
            this.pic_eid.Margin = new System.Windows.Forms.Padding(4);
            this.pic_eid.Name = "pic_eid";
            this.pic_eid.Size = new System.Drawing.Size(254, 28);
            this.pic_eid.TabIndex = 48;
            this.pic_eid.Text = "0";
            // 
            // pic_gethead
            // 
            this.pic_gethead.Location = new System.Drawing.Point(1236, 52);
            this.pic_gethead.Margin = new System.Windows.Forms.Padding(4);
            this.pic_gethead.Name = "pic_gethead";
            this.pic_gethead.Size = new System.Drawing.Size(201, 45);
            this.pic_gethead.TabIndex = 47;
            this.pic_gethead.Text = "Get All Head";
            this.pic_gethead.UseVisualStyleBackColor = true;
            this.pic_gethead.Click += new System.EventHandler(this.pic_gethead_Click);
            // 
            // label164
            // 
            this.label164.AutoSize = true;
            this.label164.Location = new System.Drawing.Point(1023, 18);
            this.label164.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label164.Name = "label164";
            this.label164.Size = new System.Drawing.Size(116, 18);
            this.label164.TabIndex = 46;
            this.label164.Text = "Picture Num:";
            // 
            // pic_num
            // 
            this.pic_num.Location = new System.Drawing.Point(1236, 14);
            this.pic_num.Margin = new System.Windows.Forms.Padding(4);
            this.pic_num.Name = "pic_num";
            this.pic_num.Size = new System.Drawing.Size(103, 28);
            this.pic_num.TabIndex = 45;
            this.pic_num.Text = "0";
            // 
            // pic_getnum
            // 
            this.pic_getnum.Location = new System.Drawing.Point(1026, 52);
            this.pic_getnum.Margin = new System.Windows.Forms.Padding(4);
            this.pic_getnum.Name = "pic_getnum";
            this.pic_getnum.Size = new System.Drawing.Size(201, 45);
            this.pic_getnum.TabIndex = 44;
            this.pic_getnum.Text = "Get Picture Number";
            this.pic_getnum.UseVisualStyleBackColor = true;
            this.pic_getnum.Click += new System.EventHandler(this.pic_getnum_Click);
            // 
            // Test_page12
            // 
            this.Test_page12.Controls.Add(this.label171);
            this.Test_page12.Controls.Add(this.label170);
            this.Test_page12.Controls.Add(this.label169);
            this.Test_page12.Controls.Add(this.label168);
            this.Test_page12.Controls.Add(this.bell3);
            this.Test_page12.Controls.Add(this.bell2);
            this.Test_page12.Controls.Add(this.bell1);
            this.Test_page12.Controls.Add(this.bell0);
            this.Test_page12.Controls.Add(this.button21);
            this.Test_page12.Controls.Add(this.Test_Bell);
            this.Test_page12.Location = new System.Drawing.Point(4, 28);
            this.Test_page12.Margin = new System.Windows.Forms.Padding(4);
            this.Test_page12.Name = "Test_page12";
            this.Test_page12.Padding = new System.Windows.Forms.Padding(4);
            this.Test_page12.Size = new System.Drawing.Size(1444, 501);
            this.Test_page12.TabIndex = 13;
            this.Test_page12.Text = "Test Page12";
            this.Test_page12.UseVisualStyleBackColor = true;
            // 
            // label171
            // 
            this.label171.AutoSize = true;
            this.label171.Location = new System.Drawing.Point(1212, 33);
            this.label171.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label171.Name = "label171";
            this.label171.Size = new System.Drawing.Size(98, 18);
            this.label171.TabIndex = 53;
            this.label171.Text = "Flag_week:";
            // 
            // label170
            // 
            this.label170.AutoSize = true;
            this.label170.Location = new System.Drawing.Point(990, 33);
            this.label170.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label170.Name = "label170";
            this.label170.Size = new System.Drawing.Size(71, 18);
            this.label170.TabIndex = 52;
            this.label170.Text = "Minute:";
            // 
            // label169
            // 
            this.label169.AutoSize = true;
            this.label169.Location = new System.Drawing.Point(790, 33);
            this.label169.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label169.Name = "label169";
            this.label169.Size = new System.Drawing.Size(53, 18);
            this.label169.TabIndex = 51;
            this.label169.Text = "Hour:";
            // 
            // label168
            // 
            this.label168.AutoSize = true;
            this.label168.Location = new System.Drawing.Point(579, 33);
            this.label168.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label168.Name = "label168";
            this.label168.Size = new System.Drawing.Size(89, 18);
            this.label168.TabIndex = 50;
            this.label168.Text = "NumberId:";
            // 
            // bell3
            // 
            this.bell3.Location = new System.Drawing.Point(1305, 28);
            this.bell3.Margin = new System.Windows.Forms.Padding(4);
            this.bell3.Name = "bell3";
            this.bell3.Size = new System.Drawing.Size(103, 28);
            this.bell3.TabIndex = 49;
            this.bell3.Text = "0";
            // 
            // bell2
            // 
            this.bell2.Location = new System.Drawing.Point(1098, 28);
            this.bell2.Margin = new System.Windows.Forms.Padding(4);
            this.bell2.Name = "bell2";
            this.bell2.Size = new System.Drawing.Size(103, 28);
            this.bell2.TabIndex = 48;
            this.bell2.Text = "0";
            // 
            // bell1
            // 
            this.bell1.Location = new System.Drawing.Point(876, 28);
            this.bell1.Margin = new System.Windows.Forms.Padding(4);
            this.bell1.Name = "bell1";
            this.bell1.Size = new System.Drawing.Size(103, 28);
            this.bell1.TabIndex = 47;
            this.bell1.Text = "0";
            // 
            // bell0
            // 
            this.bell0.Location = new System.Drawing.Point(682, 28);
            this.bell0.Margin = new System.Windows.Forms.Padding(4);
            this.bell0.Name = "bell0";
            this.bell0.Size = new System.Drawing.Size(103, 28);
            this.bell0.TabIndex = 46;
            this.bell0.Text = "0";
            // 
            // button21
            // 
            this.button21.Location = new System.Drawing.Point(288, 22);
            this.button21.Margin = new System.Windows.Forms.Padding(4);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(272, 40);
            this.button21.TabIndex = 1;
            this.button21.Text = "Test_Set_Bell";
            this.button21.UseVisualStyleBackColor = true;
            this.button21.Click += new System.EventHandler(this.button21_Click);
            // 
            // Test_Bell
            // 
            this.Test_Bell.Location = new System.Drawing.Point(9, 22);
            this.Test_Bell.Margin = new System.Windows.Forms.Padding(4);
            this.Test_Bell.Name = "Test_Bell";
            this.Test_Bell.Size = new System.Drawing.Size(272, 40);
            this.Test_Bell.TabIndex = 0;
            this.Test_Bell.Text = "Test_Get_Bell";
            this.Test_Bell.UseVisualStyleBackColor = true;
            this.Test_Bell.Click += new System.EventHandler(this.Test_Bell_Click);
            // 
            // FACE7TM
            // 
            this.FACE7TM.Controls.Add(this.label176);
            this.FACE7TM.Controls.Add(this.label177);
            this.FACE7TM.Controls.Add(this.label178);
            this.FACE7TM.Controls.Add(this.tm_stop_time);
            this.FACE7TM.Controls.Add(this.tm_start_time);
            this.FACE7TM.Controls.Add(this.tm_employee_id);
            this.FACE7TM.Controls.Add(this.label175);
            this.FACE7TM.Controls.Add(this.upload_face_PId);
            this.FACE7TM.Controls.Add(this.e_add_fp_pic);
            this.FACE7TM.Controls.Add(this.label174);
            this.FACE7TM.Controls.Add(this.button29);
            this.FACE7TM.Controls.Add(this.pic_face_fp_btn_ul);
            this.FACE7TM.Controls.Add(this.pic_face_btn_ul);
            this.FACE7TM.Controls.Add(this.pic_face_btn_dl);
            this.FACE7TM.Controls.Add(this.employee_face_lab);
            this.FACE7TM.Controls.Add(this.employee_face_PId);
            this.FACE7TM.Controls.Add(this.pictureBox2);
            this.FACE7TM.Controls.Add(this.button32);
            this.FACE7TM.Controls.Add(this.button31);
            this.FACE7TM.Controls.Add(this.button30);
            this.FACE7TM.Controls.Add(this.t_p_n01);
            this.FACE7TM.Controls.Add(this.t_p_04);
            this.FACE7TM.Controls.Add(this.t_p_03);
            this.FACE7TM.Controls.Add(this.t_p_02);
            this.FACE7TM.Controls.Add(this.t_p_01);
            this.FACE7TM.Controls.Add(this.button28);
            this.FACE7TM.Controls.Add(this.button27);
            this.FACE7TM.Controls.Add(this.button24);
            this.FACE7TM.Controls.Add(this.button22);
            this.FACE7TM.Location = new System.Drawing.Point(4, 28);
            this.FACE7TM.Margin = new System.Windows.Forms.Padding(4);
            this.FACE7TM.Name = "FACE7TM";
            this.FACE7TM.Padding = new System.Windows.Forms.Padding(4);
            this.FACE7TM.Size = new System.Drawing.Size(1444, 501);
            this.FACE7TM.TabIndex = 14;
            this.FACE7TM.Text = "FACE7TM";
            this.FACE7TM.UseVisualStyleBackColor = true;
            // 
            // label176
            // 
            this.label176.AutoSize = true;
            this.label176.Location = new System.Drawing.Point(304, 120);
            this.label176.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label176.Name = "label176";
            this.label176.Size = new System.Drawing.Size(89, 18);
            this.label176.TabIndex = 47;
            this.label176.Text = "end time:";
            // 
            // label177
            // 
            this.label177.AutoSize = true;
            this.label177.Location = new System.Drawing.Point(303, 70);
            this.label177.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label177.Name = "label177";
            this.label177.Size = new System.Drawing.Size(107, 18);
            this.label177.TabIndex = 46;
            this.label177.Text = "start time:";
            // 
            // label178
            // 
            this.label178.AutoSize = true;
            this.label178.Location = new System.Drawing.Point(9, 70);
            this.label178.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label178.Name = "label178";
            this.label178.Size = new System.Drawing.Size(107, 18);
            this.label178.TabIndex = 45;
            this.label178.Text = "EmployeeId:";
            // 
            // tm_stop_time
            // 
            this.tm_stop_time.Location = new System.Drawing.Point(418, 116);
            this.tm_stop_time.Margin = new System.Windows.Forms.Padding(4);
            this.tm_stop_time.Name = "tm_stop_time";
            this.tm_stop_time.Size = new System.Drawing.Size(196, 28);
            this.tm_stop_time.TabIndex = 44;
            this.tm_stop_time.Text = "2028-02-28 00:00:00";
            this.tm_stop_time.TextChanged += new System.EventHandler(this.tm_stop_time_TextChanged);
            // 
            // tm_start_time
            // 
            this.tm_start_time.Location = new System.Drawing.Point(418, 66);
            this.tm_start_time.Margin = new System.Windows.Forms.Padding(4);
            this.tm_start_time.Name = "tm_start_time";
            this.tm_start_time.Size = new System.Drawing.Size(196, 28);
            this.tm_start_time.TabIndex = 43;
            this.tm_start_time.Text = "2019-01-01 00:00:00";
            // 
            // tm_employee_id
            // 
            this.tm_employee_id.Location = new System.Drawing.Point(135, 66);
            this.tm_employee_id.Margin = new System.Windows.Forms.Padding(4);
            this.tm_employee_id.Name = "tm_employee_id";
            this.tm_employee_id.Size = new System.Drawing.Size(144, 28);
            this.tm_employee_id.TabIndex = 42;
            this.tm_employee_id.Text = "1";
            // 
            // label175
            // 
            this.label175.AutoSize = true;
            this.label175.Location = new System.Drawing.Point(9, 346);
            this.label175.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label175.Name = "label175";
            this.label175.Size = new System.Drawing.Size(80, 18);
            this.label175.TabIndex = 41;
            this.label175.Text = "PersonId";
            // 
            // upload_face_PId
            // 
            this.upload_face_PId.Location = new System.Drawing.Point(135, 342);
            this.upload_face_PId.Margin = new System.Windows.Forms.Padding(4);
            this.upload_face_PId.Name = "upload_face_PId";
            this.upload_face_PId.Size = new System.Drawing.Size(121, 28);
            this.upload_face_PId.TabIndex = 40;
            // 
            // e_add_fp_pic
            // 
            this.e_add_fp_pic.Location = new System.Drawing.Point(135, 250);
            this.e_add_fp_pic.Margin = new System.Windows.Forms.Padding(4);
            this.e_add_fp_pic.Name = "e_add_fp_pic";
            this.e_add_fp_pic.Size = new System.Drawing.Size(121, 28);
            this.e_add_fp_pic.TabIndex = 39;
            this.e_add_fp_pic.Text = "123321";
            // 
            // label174
            // 
            this.label174.AutoSize = true;
            this.label174.Location = new System.Drawing.Point(9, 255);
            this.label174.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label174.Name = "label174";
            this.label174.Size = new System.Drawing.Size(125, 18);
            this.label174.TabIndex = 38;
            this.label174.Text = "Temp PersonID";
            this.label174.Click += new System.EventHandler(this.label174_Click);
            // 
            // button29
            // 
            this.button29.Location = new System.Drawing.Point(279, 248);
            this.button29.Margin = new System.Windows.Forms.Padding(4);
            this.button29.Name = "button29";
            this.button29.Size = new System.Drawing.Size(254, 34);
            this.button29.TabIndex = 37;
            this.button29.Text = "Add FP_face_picture Online";
            this.button29.UseVisualStyleBackColor = true;
            this.button29.Click += new System.EventHandler(this.button29_Click);
            // 
            // pic_face_fp_btn_ul
            // 
            this.pic_face_fp_btn_ul.Location = new System.Drawing.Point(279, 339);
            this.pic_face_fp_btn_ul.Margin = new System.Windows.Forms.Padding(4);
            this.pic_face_fp_btn_ul.Name = "pic_face_fp_btn_ul";
            this.pic_face_fp_btn_ul.Size = new System.Drawing.Size(254, 34);
            this.pic_face_fp_btn_ul.TabIndex = 17;
            this.pic_face_fp_btn_ul.Text = "upload FP_picture";
            this.pic_face_fp_btn_ul.UseVisualStyleBackColor = true;
            this.pic_face_fp_btn_ul.Click += new System.EventHandler(this.pic_face_fp_btn_ul_Click);
            // 
            // pic_face_btn_ul
            // 
            this.pic_face_btn_ul.Location = new System.Drawing.Point(549, 339);
            this.pic_face_btn_ul.Margin = new System.Windows.Forms.Padding(4);
            this.pic_face_btn_ul.Name = "pic_face_btn_ul";
            this.pic_face_btn_ul.Size = new System.Drawing.Size(266, 34);
            this.pic_face_btn_ul.TabIndex = 16;
            this.pic_face_btn_ul.Text = "upload face picture to FP";
            this.pic_face_btn_ul.UseVisualStyleBackColor = true;
            this.pic_face_btn_ul.Click += new System.EventHandler(this.pic_face_btn_ul_Click);
            // 
            // pic_face_btn_dl
            // 
            this.pic_face_btn_dl.Location = new System.Drawing.Point(279, 291);
            this.pic_face_btn_dl.Margin = new System.Windows.Forms.Padding(4);
            this.pic_face_btn_dl.Name = "pic_face_btn_dl";
            this.pic_face_btn_dl.Size = new System.Drawing.Size(254, 34);
            this.pic_face_btn_dl.TabIndex = 15;
            this.pic_face_btn_dl.Text = "download FP_picture";
            this.pic_face_btn_dl.UseVisualStyleBackColor = true;
            this.pic_face_btn_dl.Click += new System.EventHandler(this.pic_face_btn_dl_Click);
            // 
            // employee_face_lab
            // 
            this.employee_face_lab.AutoSize = true;
            this.employee_face_lab.Location = new System.Drawing.Point(9, 298);
            this.employee_face_lab.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.employee_face_lab.Name = "employee_face_lab";
            this.employee_face_lab.Size = new System.Drawing.Size(80, 18);
            this.employee_face_lab.TabIndex = 14;
            this.employee_face_lab.Text = "PersonId";
            // 
            // employee_face_PId
            // 
            this.employee_face_PId.Location = new System.Drawing.Point(135, 294);
            this.employee_face_PId.Margin = new System.Windows.Forms.Padding(4);
            this.employee_face_PId.Name = "employee_face_PId";
            this.employee_face_PId.Size = new System.Drawing.Size(121, 28);
            this.employee_face_PId.TabIndex = 13;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Location = new System.Drawing.Point(858, 10);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(573, 430);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 12;
            this.pictureBox2.TabStop = false;
            // 
            // button32
            // 
            this.button32.Location = new System.Drawing.Point(520, 206);
            this.button32.Margin = new System.Windows.Forms.Padding(4);
            this.button32.Name = "button32";
            this.button32.Size = new System.Drawing.Size(195, 34);
            this.button32.TabIndex = 11;
            this.button32.Text = "del id picture";
            this.button32.UseVisualStyleBackColor = true;
            this.button32.Click += new System.EventHandler(this.button32_Click);
            // 
            // button31
            // 
            this.button31.Location = new System.Drawing.Point(147, 206);
            this.button31.Margin = new System.Windows.Forms.Padding(4);
            this.button31.Name = "button31";
            this.button31.Size = new System.Drawing.Size(214, 34);
            this.button31.TabIndex = 10;
            this.button31.Text = "get id picture ";
            this.button31.UseVisualStyleBackColor = true;
            this.button31.Click += new System.EventHandler(this.button31_Click);
            // 
            // button30
            // 
            this.button30.Location = new System.Drawing.Point(456, 165);
            this.button30.Margin = new System.Windows.Forms.Padding(4);
            this.button30.Name = "button30";
            this.button30.Size = new System.Drawing.Size(160, 34);
            this.button30.TabIndex = 9;
            this.button30.Text = "get T record";
            this.button30.UseVisualStyleBackColor = true;
            this.button30.Click += new System.EventHandler(this.button30_Click);
            // 
            // t_p_n01
            // 
            this.t_p_n01.Location = new System.Drawing.Point(120, 165);
            this.t_p_n01.Margin = new System.Windows.Forms.Padding(4);
            this.t_p_n01.Name = "t_p_n01";
            this.t_p_n01.Size = new System.Drawing.Size(180, 34);
            this.t_p_n01.TabIndex = 8;
            this.t_p_n01.Text = "get T record num";
            this.t_p_n01.UseVisualStyleBackColor = true;
            this.t_p_n01.Click += new System.EventHandler(this.t_p_n01_Click);
            // 
            // t_p_04
            // 
            this.t_p_04.Location = new System.Drawing.Point(390, 208);
            this.t_p_04.Margin = new System.Windows.Forms.Padding(4);
            this.t_p_04.Name = "t_p_04";
            this.t_p_04.Size = new System.Drawing.Size(120, 28);
            this.t_p_04.TabIndex = 7;
            // 
            // t_p_03
            // 
            this.t_p_03.Location = new System.Drawing.Point(9, 208);
            this.t_p_03.Margin = new System.Windows.Forms.Padding(4);
            this.t_p_03.Name = "t_p_03";
            this.t_p_03.Size = new System.Drawing.Size(127, 28);
            this.t_p_03.TabIndex = 6;
            // 
            // t_p_02
            // 
            this.t_p_02.Location = new System.Drawing.Point(345, 168);
            this.t_p_02.Margin = new System.Windows.Forms.Padding(4);
            this.t_p_02.Name = "t_p_02";
            this.t_p_02.Size = new System.Drawing.Size(100, 28);
            this.t_p_02.TabIndex = 5;
            this.t_p_02.Text = "0";
            // 
            // t_p_01
            // 
            this.t_p_01.Location = new System.Drawing.Point(9, 168);
            this.t_p_01.Margin = new System.Windows.Forms.Padding(4);
            this.t_p_01.Name = "t_p_01";
            this.t_p_01.Size = new System.Drawing.Size(100, 28);
            this.t_p_01.TabIndex = 4;
            this.t_p_01.Text = "0";
            // 
            // button28
            // 
            this.button28.Location = new System.Drawing.Point(394, 9);
            this.button28.Margin = new System.Windows.Forms.Padding(4);
            this.button28.Name = "button28";
            this.button28.Size = new System.Drawing.Size(222, 52);
            this.button28.TabIndex = 3;
            this.button28.Text = "TM_UploadRecord";
            this.button28.UseVisualStyleBackColor = true;
            this.button28.Click += new System.EventHandler(this.button28_Click);
            // 
            // button27
            // 
            this.button27.Location = new System.Drawing.Point(626, 66);
            this.button27.Margin = new System.Windows.Forms.Padding(4);
            this.button27.Name = "button27";
            this.button27.Size = new System.Drawing.Size(222, 52);
            this.button27.TabIndex = 2;
            this.button27.Text = "TM_GetRecordByTime";
            this.button27.UseVisualStyleBackColor = true;
            this.button27.Click += new System.EventHandler(this.button27_Click);
            // 
            // button24
            // 
            this.button24.Location = new System.Drawing.Point(200, 9);
            this.button24.Margin = new System.Windows.Forms.Padding(4);
            this.button24.Name = "button24";
            this.button24.Size = new System.Drawing.Size(168, 52);
            this.button24.TabIndex = 1;
            this.button24.Text = "TM_GetNewRecord";
            this.button24.UseVisualStyleBackColor = true;
            this.button24.Click += new System.EventHandler(this.button24_Click);
            // 
            // button22
            // 
            this.button22.Location = new System.Drawing.Point(9, 9);
            this.button22.Margin = new System.Windows.Forms.Padding(4);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(168, 52);
            this.button22.TabIndex = 0;
            this.button22.Text = "TM_GetAllRecord";
            this.button22.UseVisualStyleBackColor = true;
            this.button22.Click += new System.EventHandler(this.button22_Click);
            // 
            // groupBox15
            // 
            this.groupBox15.AutoSize = true;
            this.groupBox15.Controls.Add(this.groupBox21);
            this.groupBox15.Controls.Add(this.label_closesevice);
            this.groupBox15.Controls.Add(this.label_serviceport);
            this.groupBox15.Controls.Add(this.button10);
            this.groupBox15.Controls.Add(this.iscloseservice);
            this.groupBox15.Controls.Add(this.service_port);
            this.groupBox15.Location = new System.Drawing.Point(6, 8);
            this.groupBox15.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox15.Name = "groupBox15";
            this.groupBox15.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox15.Size = new System.Drawing.Size(1464, 1105);
            this.groupBox15.TabIndex = 30;
            this.groupBox15.TabStop = false;
            this.groupBox15.Text = "groupBox15";
            // 
            // groupBox21
            // 
            this.groupBox21.Controls.Add(this.label108);
            this.groupBox21.Controls.Add(this.choose);
            this.groupBox21.Controls.Add(this.a_name);
            this.groupBox21.Controls.Add(this.a_password);
            this.groupBox21.Controls.Add(this.label110);
            this.groupBox21.Location = new System.Drawing.Point(325, 467);
            this.groupBox21.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox21.Name = "groupBox21";
            this.groupBox21.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox21.Size = new System.Drawing.Size(756, 182);
            this.groupBox21.TabIndex = 11;
            this.groupBox21.TabStop = false;
            this.groupBox21.Text = "Set  Connect Authentication  Before  Login";
            // 
            // label108
            // 
            this.label108.AutoSize = true;
            this.label108.Location = new System.Drawing.Point(-3, 114);
            this.label108.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label108.Name = "label108";
            this.label108.Size = new System.Drawing.Size(332, 18);
            this.label108.TabIndex = 5;
            this.label108.Text = "Default Connect Authentication Name:";
            // 
            // choose
            // 
            this.choose.AutoSize = true;
            this.choose.Location = new System.Drawing.Point(237, 48);
            this.choose.Margin = new System.Windows.Forms.Padding(4);
            this.choose.Name = "choose";
            this.choose.Size = new System.Drawing.Size(286, 22);
            this.choose.TabIndex = 10;
            this.choose.Text = "Choose Here to authenticate!";
            this.choose.UseVisualStyleBackColor = true;
            // 
            // a_name
            // 
            this.a_name.Location = new System.Drawing.Point(338, 110);
            this.a_name.Margin = new System.Windows.Forms.Padding(4);
            this.a_name.Name = "a_name";
            this.a_name.Size = new System.Drawing.Size(148, 28);
            this.a_name.TabIndex = 6;
            this.a_name.Text = "admin";
            // 
            // a_password
            // 
            this.a_password.Location = new System.Drawing.Point(597, 110);
            this.a_password.Margin = new System.Windows.Forms.Padding(4);
            this.a_password.Name = "a_password";
            this.a_password.Size = new System.Drawing.Size(148, 28);
            this.a_password.TabIndex = 7;
            this.a_password.Text = "12345";
            this.a_password.TextChanged += new System.EventHandler(this.textBox4_TextChanged_1);
            // 
            // label110
            // 
            this.label110.AutoSize = true;
            this.label110.Location = new System.Drawing.Point(496, 114);
            this.label110.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label110.Name = "label110";
            this.label110.Size = new System.Drawing.Size(89, 18);
            this.label110.TabIndex = 9;
            this.label110.Text = "Password:";
            // 
            // label_closesevice
            // 
            this.label_closesevice.AutoSize = true;
            this.label_closesevice.Location = new System.Drawing.Point(322, 409);
            this.label_closesevice.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_closesevice.Name = "label_closesevice";
            this.label_closesevice.Size = new System.Drawing.Size(449, 18);
            this.label_closesevice.TabIndex = 4;
            this.label_closesevice.Text = "Is close service( = 1:close service just client):";
            // 
            // label_serviceport
            // 
            this.label_serviceport.AutoSize = true;
            this.label_serviceport.Location = new System.Drawing.Point(322, 273);
            this.label_serviceport.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_serviceport.Name = "label_serviceport";
            this.label_serviceport.Size = new System.Drawing.Size(566, 18);
            this.label_serviceport.TabIndex = 3;
            this.label_serviceport.Text = "service port( = 0:random, other port = ):(default port = 5010)";
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(325, 680);
            this.button10.Margin = new System.Windows.Forms.Padding(4);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(756, 40);
            this.button10.TabIndex = 2;
            this.button10.Text = "Start";
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.button10_Click_1);
            // 
            // iscloseservice
            // 
            this.iscloseservice.Location = new System.Drawing.Point(931, 404);
            this.iscloseservice.Margin = new System.Windows.Forms.Padding(4);
            this.iscloseservice.Name = "iscloseservice";
            this.iscloseservice.Size = new System.Drawing.Size(148, 28);
            this.iscloseservice.TabIndex = 1;
            this.iscloseservice.Text = "0";
            // 
            // service_port
            // 
            this.service_port.Location = new System.Drawing.Point(931, 269);
            this.service_port.Margin = new System.Windows.Forms.Padding(4);
            this.service_port.Name = "service_port";
            this.service_port.Size = new System.Drawing.Size(148, 28);
            this.service_port.TabIndex = 0;
            this.service_port.Text = "5010";
            // 
            // FrmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1494, 1118);
            this.Controls.Add(this.groupBox15);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.SAC_Dev02);
            this.Controls.Add(this.groupBox2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.Name = "FrmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ANVIZ_Demo";
            this.groupBox2.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.SAC_Dev02.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.basicconfig2.ResumeLayout(false);
            this.basicconfig2.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.getspecial.ResumeLayout(false);
            this.getspecial.PerformLayout();
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.timepriodgroup.ResumeLayout(false);
            this.timepriodgroup.PerformLayout();
            this.tabPage6.ResumeLayout(false);
            this.groupBox16.ResumeLayout(false);
            this.groupBox16.PerformLayout();
            this.groupBox14.ResumeLayout(false);
            this.groupBox14.PerformLayout();
            this.groupBox13.ResumeLayout(false);
            this.groupBox13.PerformLayout();
            this.groupBox12.ResumeLayout(false);
            this.groupBox12.PerformLayout();
            this.config3.ResumeLayout(false);
            this.config3.PerformLayout();
            this.tabPage7.ResumeLayout(false);
            this.groupBox26.ResumeLayout(false);
            this.groupBox26.PerformLayout();
            this.groupBox22.ResumeLayout(false);
            this.groupBox22.PerformLayout();
            this.groupBox20.ResumeLayout(false);
            this.groupBox20.PerformLayout();
            this.groupBox11.ResumeLayout(false);
            this.groupBox11.PerformLayout();
            this.groupBox19.ResumeLayout(false);
            this.groupBox18.ResumeLayout(false);
            this.groupBox18.PerformLayout();
            this.groupBox17.ResumeLayout(false);
            this.groupBox17.PerformLayout();
            this.tabPage8.ResumeLayout(false);
            this.tabPage8.PerformLayout();
            this.groupBox24.ResumeLayout(false);
            this.groupBox24.PerformLayout();
            this.groupBox23.ResumeLayout(false);
            this.groupBox23.PerformLayout();
            this.tabPage9.ResumeLayout(false);
            this.tabPage9.PerformLayout();
            this.Bolid_Log.ResumeLayout(false);
            this.groupBox25.ResumeLayout(false);
            this.groupBox25.PerformLayout();
            this.tabPage10.ResumeLayout(false);
            this.tabPage10.PerformLayout();
            this.tabPage11.ResumeLayout(false);
            this.tabPage11.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.Test_page12.ResumeLayout(false);
            this.Test_page12.PerformLayout();
            this.FACE7TM.ResumeLayout(false);
            this.FACE7TM.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.groupBox15.ResumeLayout(false);
            this.groupBox15.PerformLayout();
            this.groupBox21.ResumeLayout(false);
            this.groupBox21.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.Timer timer1;
        internal System.Windows.Forms.ListView listViewDevice;
        internal System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.GroupBox groupBox2;
        internal System.Windows.Forms.ColumnHeader columnHeader6;
        private System.Windows.Forms.GroupBox groupBox1;
        internal System.Windows.Forms.ListBox listBoxLog;
        private System.Windows.Forms.Button settime;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TabControl SAC_Dev02;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.TextBox textBox3;
        internal System.Windows.Forms.DateTimePicker dateTimePicker2;
        internal System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        internal System.Windows.Forms.ListView listViewMsg;
        internal System.Windows.Forms.ColumnHeader columnHeader5;
        internal System.Windows.Forms.ColumnHeader columnHeader7;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Button buttonSetNet;
        private System.Windows.Forms.Button buttonGetNet;
        private System.Windows.Forms.TextBox textBoxIp;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.CheckBox checkBoxDHCP;
        private System.Windows.Forms.TextBox textBoxMode;
        private System.Windows.Forms.TextBox textBoxPort;
        private System.Windows.Forms.TextBox textBoxMac;
        private System.Windows.Forms.TextBox textBoxGw;
        private System.Windows.Forms.TextBox textBoxMask;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBoxServIp;
        private System.Windows.Forms.Label label10;
        internal System.Windows.Forms.ColumnHeader columnHeader4;
        internal System.Windows.Forms.ColumnHeader columnHeader3;
        internal System.Windows.Forms.ColumnHeader columnHeader8;
        internal System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.TextBox textBoxRemote;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button button_get_sn;
        private System.Windows.Forms.TextBox textBox_sn;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button button_dl_all_record;
        private System.Windows.Forms.Button button_restart;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox textBox_pwd;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Button button_set_basic_cfg;
        private System.Windows.Forms.Button button_get_basic_cfg;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.TextBox textBox4_sleep_time;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.Button button8_delete_person;
        private System.Windows.Forms.Button button7_modify_person;
        private System.Windows.Forms.TextBox textBox_special;
        private System.Windows.Forms.TextBox textBox_fp_status;
        private System.Windows.Forms.TextBox textBox_mode;
        private System.Windows.Forms.TextBox textBox_group;
        private System.Windows.Forms.TextBox textBox_dept;
        private System.Windows.Forms.TextBox textBox_cardID;
        private System.Windows.Forms.TextBox textBox_password;
        private System.Windows.Forms.TextBox textBox_name;
        private System.Windows.Forms.TextBox textBox_personID;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Button button7_get_all_person;
        private System.Windows.Forms.ListView listView_person;
        private System.Windows.Forms.ColumnHeader columnHeader9;
        private System.Windows.Forms.ColumnHeader columnHeader10;
        private System.Windows.Forms.ColumnHeader columnHeader11;
        private System.Windows.Forms.ColumnHeader columnHeader12;
        private System.Windows.Forms.ColumnHeader columnHeader13;
        private System.Windows.Forms.ColumnHeader columnHeader14;
        private System.Windows.Forms.ColumnHeader columnHeader15;
        private System.Windows.Forms.ColumnHeader columnHeader16;
        private System.Windows.Forms.ColumnHeader columnHeader17;
        private System.Windows.Forms.ColumnHeader columnHeader18;
        private System.Windows.Forms.Button button_get_fp_raw_data;
        private System.Windows.Forms.Button button_put_fp_raw_data;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox Add_dev_Ip;
        private System.Windows.Forms.TextBox Add_dev_port;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Button but_disconnect;
        private System.Windows.Forms.TextBox text_disconnect;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.TextBox Box6_year;
        private System.Windows.Forms.Button gettime;
        private System.Windows.Forms.TextBox Box6_sec;
        private System.Windows.Forms.TextBox Box6_min;
        private System.Windows.Forms.TextBox Box6_hour;
        private System.Windows.Forms.TextBox Box6_day;
        private System.Windows.Forms.TextBox Box6_month;
        private System.Windows.Forms.GroupBox basicconfig2;
        private System.Windows.Forms.Button getconfig2;
        private System.Windows.Forms.Button setconfig2;
        private System.Windows.Forms.TextBox config2_1;
        private System.Windows.Forms.TextBox config2_9;
        private System.Windows.Forms.TextBox config2_10;
        private System.Windows.Forms.TextBox config2_11;
        private System.Windows.Forms.TextBox config2_12;
        private System.Windows.Forms.TextBox config2_13;
        private System.Windows.Forms.TextBox config2_7;
        private System.Windows.Forms.TextBox config2_4;
        private System.Windows.Forms.TextBox config2_8;
        private System.Windows.Forms.TextBox config2_5;
        private System.Windows.Forms.TextBox config2_2;
        private System.Windows.Forms.TextBox config2_6;
        private System.Windows.Forms.TextBox config2_3;
        private System.Windows.Forms.Label config_l1;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Button init_system;
        private System.Windows.Forms.Button init_user_area;
        private System.Windows.Forms.GroupBox timepriodgroup;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Button set_period_time;
        private System.Windows.Forms.Button get_period_time;
        private System.Windows.Forms.TextBox time_p74;
        private System.Windows.Forms.TextBox time_p73;
        private System.Windows.Forms.TextBox time_p72;
        private System.Windows.Forms.TextBox time_p71;
        private System.Windows.Forms.TextBox time_p64;
        private System.Windows.Forms.TextBox time_p63;
        private System.Windows.Forms.TextBox time_p62;
        private System.Windows.Forms.TextBox time_p61;
        private System.Windows.Forms.TextBox time_p54;
        private System.Windows.Forms.TextBox time_p53;
        private System.Windows.Forms.TextBox time_p52;
        private System.Windows.Forms.TextBox time_p51;
        private System.Windows.Forms.TextBox time_p44;
        private System.Windows.Forms.TextBox time_p43;
        private System.Windows.Forms.TextBox time_p42;
        private System.Windows.Forms.TextBox time_p41;
        private System.Windows.Forms.TextBox time_p34;
        private System.Windows.Forms.TextBox time_p33;
        private System.Windows.Forms.TextBox time_p32;
        private System.Windows.Forms.TextBox time_p31;
        private System.Windows.Forms.TextBox time_p24;
        private System.Windows.Forms.TextBox time_p23;
        private System.Windows.Forms.TextBox time_p22;
        private System.Windows.Forms.TextBox time_p21;
        private System.Windows.Forms.TextBox time_p14;
        private System.Windows.Forms.TextBox time_p13;
        private System.Windows.Forms.TextBox time_p12;
        private System.Windows.Forms.TextBox time_p11;
        private System.Windows.Forms.TextBox time_number;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.TextBox text_time2;
        private System.Windows.Forms.TextBox text_time1;
        private System.Windows.Forms.ColumnHeader columnHeader19;
        private System.Windows.Forms.ColumnHeader columnHeader20;
        private System.Windows.Forms.Button add_fp;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.TextBox fptext_01;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.Button setteam;
        private System.Windows.Forms.Button getteam;
        private System.Windows.Forms.TextBox teamid;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.TextBox select_04;
        private System.Windows.Forms.TextBox select_01;
        private System.Windows.Forms.TextBox select_02;
        private System.Windows.Forms.TextBox select_03;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Button forcedunlock;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.ColumnHeader IP;
        private System.Windows.Forms.ColumnHeader MASK;
        private System.Windows.Forms.ColumnHeader GW;
        private System.Windows.Forms.ColumnHeader MAC;
        private System.Windows.Forms.ColumnHeader ServiceIP;
        private System.Windows.Forms.ColumnHeader Port;
        private System.Windows.Forms.ColumnHeader NetMode;
        private System.Windows.Forms.ColumnHeader Machineid;
        private System.Windows.Forms.ColumnHeader Reserved;
        private System.Windows.Forms.ColumnHeader Username;
        private System.Windows.Forms.ColumnHeader Password;
        private System.Windows.Forms.ColumnHeader DNS;
        private System.Windows.Forms.ColumnHeader URL;
        private System.Windows.Forms.TextBox udp_04;
        private System.Windows.Forms.TextBox udp_03;
        private System.Windows.Forms.TextBox udp_02;
        private System.Windows.Forms.TextBox udp_01;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.TextBox udp_13;
        private System.Windows.Forms.TextBox udp_09;
        private System.Windows.Forms.TextBox udp_08;
        private System.Windows.Forms.TextBox udp_12;
        private System.Windows.Forms.TextBox udp_11;
        private System.Windows.Forms.TextBox udp_07;
        private System.Windows.Forms.TextBox udp_10;
        private System.Windows.Forms.TextBox udp_06;
        private System.Windows.Forms.TextBox udp_05;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.ColumnHeader type;
        private System.Windows.Forms.ColumnHeader listid;
        private System.Windows.Forms.TextBox addfp_person_id;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.TextBox config2_52;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.TextBox config5_02;
        private System.Windows.Forms.TextBox config5_01;
        private System.Windows.Forms.Button btn_setconfig5;
        private System.Windows.Forms.Button btn_getconfig5;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.TextBox card_01;
        private System.Windows.Forms.Button btn_getcard;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.TextBox devstatus_02;
        private System.Windows.Forms.TextBox devstatus_01;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.GroupBox groupBox13;
        private System.Windows.Forms.TextBox tgj_035;
        private System.Windows.Forms.TextBox tgj_030;
        private System.Windows.Forms.TextBox tgj_025;
        private System.Windows.Forms.TextBox tgj_020;
        private System.Windows.Forms.TextBox tgj_015;
        private System.Windows.Forms.TextBox tgj_010;
        private System.Windows.Forms.TextBox tgj_005;
        private System.Windows.Forms.Label label77;
        private System.Windows.Forms.Label label78;
        private System.Windows.Forms.Label label79;
        private System.Windows.Forms.Label label80;
        private System.Windows.Forms.Label label81;
        private System.Windows.Forms.Button setstatus02;
        private System.Windows.Forms.Button getstatus02;
        private System.Windows.Forms.TextBox tgj_034;
        private System.Windows.Forms.TextBox tgj_033;
        private System.Windows.Forms.TextBox tgj_032;
        private System.Windows.Forms.TextBox tgj_031;
        private System.Windows.Forms.TextBox tgj_029;
        private System.Windows.Forms.TextBox tgj_028;
        private System.Windows.Forms.TextBox tgj_027;
        private System.Windows.Forms.TextBox tgj_026;
        private System.Windows.Forms.TextBox tgj_024;
        private System.Windows.Forms.TextBox tgj_023;
        private System.Windows.Forms.TextBox tgj_022;
        private System.Windows.Forms.TextBox tgj_021;
        private System.Windows.Forms.TextBox tgj_019;
        private System.Windows.Forms.TextBox tgj_018;
        private System.Windows.Forms.TextBox tgj_017;
        private System.Windows.Forms.TextBox tgj_016;
        private System.Windows.Forms.TextBox tgj_014;
        private System.Windows.Forms.TextBox tgj_013;
        private System.Windows.Forms.TextBox tgj_012;
        private System.Windows.Forms.TextBox tgj_011;
        private System.Windows.Forms.TextBox tgj_009;
        private System.Windows.Forms.TextBox tgj_008;
        private System.Windows.Forms.TextBox tgj_007;
        private System.Windows.Forms.TextBox tgj_006;
        private System.Windows.Forms.TextBox tgj_004;
        private System.Windows.Forms.TextBox tgj_003;
        private System.Windows.Forms.TextBox tgj_002;
        private System.Windows.Forms.TextBox tgj_001;
        private System.Windows.Forms.TextBox flagweek_01;
        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.Label label76;
        private System.Windows.Forms.Button setstatus01;
        private System.Windows.Forms.Button getstatus01;
        private System.Windows.Forms.TextBox tg_028;
        private System.Windows.Forms.TextBox tg_027;
        private System.Windows.Forms.TextBox tg_026;
        private System.Windows.Forms.TextBox tg_025;
        private System.Windows.Forms.TextBox tg_024;
        private System.Windows.Forms.TextBox tg_023;
        private System.Windows.Forms.TextBox tg_022;
        private System.Windows.Forms.TextBox tg_021;
        private System.Windows.Forms.TextBox tg_020;
        private System.Windows.Forms.TextBox tg_019;
        private System.Windows.Forms.TextBox tg_018;
        private System.Windows.Forms.TextBox tg_017;
        private System.Windows.Forms.TextBox tg_016;
        private System.Windows.Forms.TextBox tg_015;
        private System.Windows.Forms.TextBox tg_014;
        private System.Windows.Forms.TextBox tg_013;
        private System.Windows.Forms.TextBox tg_012;
        private System.Windows.Forms.TextBox tg_011;
        private System.Windows.Forms.TextBox tg_010;
        private System.Windows.Forms.TextBox tg_009;
        private System.Windows.Forms.TextBox tg_008;
        private System.Windows.Forms.TextBox tg_007;
        private System.Windows.Forms.TextBox tg_006;
        private System.Windows.Forms.TextBox tg_005;
        private System.Windows.Forms.TextBox tg_004;
        private System.Windows.Forms.TextBox tg_003;
        private System.Windows.Forms.TextBox tg_002;
        private System.Windows.Forms.TextBox tg_001;
        private System.Windows.Forms.TextBox groupid01;
        private System.Windows.Forms.GroupBox groupBox14;
        private System.Windows.Forms.Button update_status;
        private System.Windows.Forms.Button update_file;
        private System.Windows.Forms.TextBox baifenbi;
        private System.Windows.Forms.Label label82;
        private System.Windows.Forms.TextBox status00;
        private System.Windows.Forms.TextBox tgj_040;
        private System.Windows.Forms.TextBox tgj_039;
        private System.Windows.Forms.TextBox tgj_038;
        private System.Windows.Forms.TextBox tgj_037;
        private System.Windows.Forms.TextBox tgj_036;
        private System.Windows.Forms.Button closeallalarm;
        private System.Windows.Forms.GroupBox groupBox15;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.TextBox iscloseservice;
        private System.Windows.Forms.TextBox service_port;
        private System.Windows.Forms.Label label_closesevice;
        private System.Windows.Forms.Label label_serviceport;
        private System.Windows.Forms.Button close_u;
        private System.Windows.Forms.Button open_u;
        private System.Windows.Forms.GroupBox config3;
        private System.Windows.Forms.Button SetConfig3_01;
        private System.Windows.Forms.Button GetConfig3_01;
        private System.Windows.Forms.TextBox c3_08;
        private System.Windows.Forms.TextBox c3_06;
        private System.Windows.Forms.TextBox c3_04;
        private System.Windows.Forms.TextBox c3_02;
        private System.Windows.Forms.TextBox c3_07;
        private System.Windows.Forms.TextBox c3_05;
        private System.Windows.Forms.TextBox c3_03;
        private System.Windows.Forms.TextBox c3_01;
        private System.Windows.Forms.Label label87;
        private System.Windows.Forms.Label label88;
        private System.Windows.Forms.Label label89;
        private System.Windows.Forms.Label label90;
        private System.Windows.Forms.Label label86;
        private System.Windows.Forms.Label label85;
        private System.Windows.Forms.Label label84;
        private System.Windows.Forms.Label label83;
        private System.Windows.Forms.GroupBox groupBox16;
        private System.Windows.Forms.Label label93;
        private System.Windows.Forms.Label label92;
        private System.Windows.Forms.Label label91;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.TextBox sdk_03;
        private System.Windows.Forms.TextBox sdk_01;
        private System.Windows.Forms.TextBox sdk_02;
        private System.Windows.Forms.TabPage tabPage7;
        private System.Windows.Forms.Label label100;
        private System.Windows.Forms.Label label99;
        private System.Windows.Forms.TextBox drname02;
        private System.Windows.Forms.TextBox drname01;
        private System.Windows.Forms.GroupBox groupBox17;
        private System.Windows.Forms.Button setmachi01;
        private System.Windows.Forms.Button getmachineid;
        private System.Windows.Forms.TextBox machineid_01;
        private System.Windows.Forms.Label label101;
        private System.Windows.Forms.GroupBox groupBox18;
        private System.Windows.Forms.TextBox c_password;
        private System.Windows.Forms.Label label103;
        private System.Windows.Forms.Button authentication;
        private System.Windows.Forms.TextBox c_username;
        private System.Windows.Forms.Label label102;
        private System.Windows.Forms.GroupBox groupBox19;
        private System.Windows.Forms.Button clearadmin;
        private System.Windows.Forms.Button newrecord;
        private System.Windows.Forms.GroupBox getspecial;
        private System.Windows.Forms.Label label105;
        private System.Windows.Forms.Label label104;
        private System.Windows.Forms.TextBox special_relay;
        private System.Windows.Forms.Label label98;
        private System.Windows.Forms.TextBox Special_07;
        private System.Windows.Forms.Label label97;
        private System.Windows.Forms.TextBox Special_06;
        private System.Windows.Forms.Label label96;
        private System.Windows.Forms.TextBox Special_05;
        private System.Windows.Forms.Label label95;
        private System.Windows.Forms.TextBox Special_01;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.Label label94;
        private System.Windows.Forms.TextBox url_dns;
        private System.Windows.Forms.Button seturl;
        private System.Windows.Forms.Button geturl;
        private System.Windows.Forms.TextBox url_01;
        private System.Windows.Forms.GroupBox groupBox20;
        private System.Windows.Forms.TextBox devidx_z;
        private System.Windows.Forms.Label label106;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.TextBox machine_z;
        private System.Windows.Forms.Label label107;
        private System.Windows.Forms.Label label110;
        private System.Windows.Forms.TextBox a_password;
        private System.Windows.Forms.TextBox a_name;
        private System.Windows.Forms.Label label108;
        private System.Windows.Forms.GroupBox groupBox21;
        private System.Windows.Forms.CheckBox choose;
        private System.Windows.Forms.GroupBox groupBox22;
        private System.Windows.Forms.Button set_a;
        private System.Windows.Forms.Label label109;
        private System.Windows.Forms.CheckBox choose02;
        private System.Windows.Forms.TextBox a_name_02;
        private System.Windows.Forms.TextBox a_password_02;
        private System.Windows.Forms.Label label111;
        private System.Windows.Forms.TabPage tabPage8;
        private System.Windows.Forms.GroupBox groupBox23;
        private System.Windows.Forms.Label label116;
        private System.Windows.Forms.Label label115;
        private System.Windows.Forms.Label label114;
        private System.Windows.Forms.Label label113;
        private System.Windows.Forms.Label label112;
        private System.Windows.Forms.Button upload_record;
        private System.Windows.Forms.TextBox upload_005;
        private System.Windows.Forms.TextBox upload_004;
        private System.Windows.Forms.TextBox upload_003;
        private System.Windows.Forms.TextBox upload_002;
        private System.Windows.Forms.TextBox upload_001;
        private System.Windows.Forms.GroupBox groupBox24;
        private System.Windows.Forms.Label label119;
        private System.Windows.Forms.Label label120;
        private System.Windows.Forms.Label label121;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.TextBox p_record_003;
        private System.Windows.Forms.TextBox p_record_002;
        private System.Windows.Forms.TextBox p_record_001;
        private System.Windows.Forms.Label label117;
        private System.Windows.Forms.TextBox p_record_004;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Label label118;
        private System.Windows.Forms.TextBox msg_p_id;
        private System.Windows.Forms.ColumnHeader columnHeader21;
        private System.Windows.Forms.Label label122;
        private System.Windows.Forms.TextBox get_p_001;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Button button_del_flag_count;
        private System.Windows.Forms.TextBox textBox_del_flag_count;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Button button_del_all_record;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.TabPage tabPage9;
        private System.Windows.Forms.ListView listsac_employee;
        private System.Windows.Forms.ColumnHeader columnHeader22;
        private System.Windows.Forms.ColumnHeader columnHeader23;
        private System.Windows.Forms.ColumnHeader columnHeader24;
        private System.Windows.Forms.ColumnHeader columnHeader25;
        private System.Windows.Forms.ColumnHeader columnHeader26;
        private System.Windows.Forms.ColumnHeader columnHeader27;
        private System.Windows.Forms.ColumnHeader columnHeader28;
        private System.Windows.Forms.ColumnHeader columnHeader29;
        private System.Windows.Forms.ColumnHeader columnHeader30;
        private System.Windows.Forms.ColumnHeader columnHeader31;
        private System.Windows.Forms.ColumnHeader columnHeader34;
        private System.Windows.Forms.Button sac_get_employee;
        private System.Windows.Forms.TabPage Bolid_Log;
        private System.Windows.Forms.GroupBox groupBox25;
        private System.Windows.Forms.Button log_manage_03;
        private System.Windows.Forms.Button log_manage_02;
        private System.Windows.Forms.Button log_manage_01;
        private System.Windows.Forms.Label label123;
        private System.Windows.Forms.TextBox log_number;
        private System.Windows.Forms.Label label124;
        private System.Windows.Forms.Label label125;
        private System.Windows.Forms.TextBox log_endtime;
        private System.Windows.Forms.TextBox log_begintime;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.TextBox sac_e_09;
        private System.Windows.Forms.Label label135;
        private System.Windows.Forms.TextBox sac_e_10;
        private System.Windows.Forms.TextBox sac_e_08;
        private System.Windows.Forms.TextBox sac_e_07;
        private System.Windows.Forms.TextBox sac_e_06;
        private System.Windows.Forms.TextBox sac_e_05;
        private System.Windows.Forms.TextBox sac_e_04;
        private System.Windows.Forms.TextBox sac_e_03;
        private System.Windows.Forms.TextBox sac_e_02;
        private System.Windows.Forms.TextBox sac_e_01;
        private System.Windows.Forms.Label label126;
        private System.Windows.Forms.Label label127;
        private System.Windows.Forms.Label label128;
        private System.Windows.Forms.Label label129;
        private System.Windows.Forms.Label label130;
        private System.Windows.Forms.Label label131;
        private System.Windows.Forms.Label label132;
        private System.Windows.Forms.Label label133;
        private System.Windows.Forms.Label label134;
        private System.Windows.Forms.Button sac_get_group;
        private System.Windows.Forms.Label label137;
        private System.Windows.Forms.Label label136;
        private System.Windows.Forms.TextBox sac_up_02;
        private System.Windows.Forms.TextBox sac_up_01;
        private System.Windows.Forms.Button sac_upload_group;
        private System.Windows.Forms.Label label138;
        private System.Windows.Forms.Label label139;
        private System.Windows.Forms.TextBox p_g_02;
        private System.Windows.Forms.TextBox p_g_01;
        private System.Windows.Forms.Button p_g_btn2;
        private System.Windows.Forms.Button p_g_btn1;
        private System.Windows.Forms.TabPage tabPage10;
        private System.Windows.Forms.Button sac_door;
        private System.Windows.Forms.TextBox sac_1006;
        private System.Windows.Forms.Label label146;
        private System.Windows.Forms.TextBox sac_1007;
        private System.Windows.Forms.Label label145;
        private System.Windows.Forms.TextBox sac_1005;
        private System.Windows.Forms.Label label144;
        private System.Windows.Forms.TextBox sac_1004;
        private System.Windows.Forms.Label label143;
        private System.Windows.Forms.TextBox sac_1003;
        private System.Windows.Forms.Label label142;
        private System.Windows.Forms.TextBox sac_1002;
        private System.Windows.Forms.Label label141;
        private System.Windows.Forms.TextBox sac_1001;
        private System.Windows.Forms.Label label140;
        private System.Windows.Forms.Button settimeframe;
        private System.Windows.Forms.Label label147;
        private System.Windows.Forms.TextBox sac_time01;
        private System.Windows.Forms.TextBox sac_time00;
        private System.Windows.Forms.Button button25;
        private System.Windows.Forms.Button updoor_group;
        private System.Windows.Forms.Button button23;
        private System.Windows.Forms.Button door_group;
        private System.Windows.Forms.TextBox time03;
        private System.Windows.Forms.Label label153;
        private System.Windows.Forms.TextBox time02;
        private System.Windows.Forms.Label label152;
        private System.Windows.Forms.TextBox time01;
        private System.Windows.Forms.Label label151;
        private System.Windows.Forms.TextBox door03;
        private System.Windows.Forms.Label label150;
        private System.Windows.Forms.TextBox door02;
        private System.Windows.Forms.Label label149;
        private System.Windows.Forms.TextBox door01;
        private System.Windows.Forms.Label label148;
        private System.Windows.Forms.Button button26;
        private System.Windows.Forms.Label label156;
        private System.Windows.Forms.Label label157;
        private System.Windows.Forms.TextBox time_g_02;
        private System.Windows.Forms.TextBox time_g_01;
        private System.Windows.Forms.Button uptimegroup;
        private System.Windows.Forms.Button downtimegroup;
        private System.Windows.Forms.Button updoorgroup;
        private System.Windows.Forms.Button downdoorgroup;
        private System.Windows.Forms.Label label154;
        private System.Windows.Forms.Label label155;
        private System.Windows.Forms.TextBox door_g_02;
        private System.Windows.Forms.TextBox door_g_01;
        private System.Windows.Forms.Button sac_set;
        private System.Windows.Forms.Button sac_get;
        private System.Windows.Forms.TextBox sac_sac05;
        private System.Windows.Forms.Label label162;
        private System.Windows.Forms.TextBox sac_sac04;
        private System.Windows.Forms.Label label161;
        private System.Windows.Forms.TextBox sac_sac03;
        private System.Windows.Forms.Label label160;
        private System.Windows.Forms.TextBox sac_sac02;
        private System.Windows.Forms.Label label159;
        private System.Windows.Forms.TextBox sac_sac01;
        private System.Windows.Forms.Label label158;
        private System.Windows.Forms.Button gettimeframe;
        private System.Windows.Forms.Label label163;
        private System.Windows.Forms.TextBox log_auto_01;
        private System.Windows.Forms.Button log_auto_btn1;
        private System.Windows.Forms.Button log_auto_btn3;
        private System.Windows.Forms.Button log_auto_btn2;
        private System.Windows.Forms.TabPage tabPage11;
        private System.Windows.Forms.Label label164;
        private System.Windows.Forms.TextBox pic_num;
        private System.Windows.Forms.Button pic_getnum;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label166;
        private System.Windows.Forms.Label label165;
        private System.Windows.Forms.Button pic_delpic;
        private System.Windows.Forms.Button pic_getpic;
        private System.Windows.Forms.TextBox pic_time;
        private System.Windows.Forms.TextBox pic_eid;
        private System.Windows.Forms.Button pic_gethead;
        private System.Windows.Forms.Label label167;
        private System.Windows.Forms.TabPage Test_page12;
        private System.Windows.Forms.Button Test_Bell;
        private System.Windows.Forms.Label label171;
        private System.Windows.Forms.Label label170;
        private System.Windows.Forms.Label label169;
        private System.Windows.Forms.Label label168;
        private System.Windows.Forms.TextBox bell3;
        private System.Windows.Forms.TextBox bell2;
        private System.Windows.Forms.TextBox bell1;
        private System.Windows.Forms.TextBox bell0;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.TextBox textBox_reserved2;
        private System.Windows.Forms.Label label172;
        private System.Windows.Forms.ColumnHeader columnHeader32;
        private System.Windows.Forms.Button sac_init_people;
        private System.Windows.Forms.Button sac_delete_people;
        private System.Windows.Forms.TextBox sac_delete01;
        private System.Windows.Forms.TextBox sac_delete02;
        private System.Windows.Forms.Label label173;
        private System.Windows.Forms.Button sac_getevent;
        private System.Windows.Forms.TabPage FACE7TM;
        private System.Windows.Forms.Button button28;
        private System.Windows.Forms.Button button27;
        private System.Windows.Forms.Button button24;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.Button button32;
        private System.Windows.Forms.Button button31;
        private System.Windows.Forms.Button button30;
        private System.Windows.Forms.Button t_p_n01;
        private System.Windows.Forms.TextBox t_p_04;
        private System.Windows.Forms.TextBox t_p_03;
        private System.Windows.Forms.TextBox t_p_02;
        private System.Windows.Forms.TextBox t_p_01;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button pic_face_btn_ul;
        private System.Windows.Forms.Button pic_face_btn_dl;
        private System.Windows.Forms.Label employee_face_lab;
        private System.Windows.Forms.TextBox employee_face_PId;
        private System.Windows.Forms.Button pic_face_fp_btn_ul;
        private System.Windows.Forms.TextBox e_add_fp_pic;
        private System.Windows.Forms.Label label174;
        private System.Windows.Forms.Button button29;
        private System.Windows.Forms.Label label175;
        private System.Windows.Forms.TextBox upload_face_PId;
        private System.Windows.Forms.Label label176;
        private System.Windows.Forms.Label label177;
        private System.Windows.Forms.Label label178;
        private System.Windows.Forms.TextBox tm_stop_time;
        private System.Windows.Forms.TextBox tm_start_time;
        private System.Windows.Forms.TextBox tm_employee_id;
        private System.Windows.Forms.GroupBox groupBox26;
        private System.Windows.Forms.Button button_verifGet;
        private System.Windows.Forms.Button button_verifSet;
        private System.Windows.Forms.ListBox listBox_verifs;
        private System.Windows.Forms.Label label180;
        private System.Windows.Forms.Label label179;
        private System.Windows.Forms.TextBox textBox_verfVer;
        private System.Windows.Forms.TextBox textBox_verifmode;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.ColumnHeader columnHeader33;
        private System.Windows.Forms.Label label181;
        private System.Windows.Forms.TextBox textBox2;
    }
}

